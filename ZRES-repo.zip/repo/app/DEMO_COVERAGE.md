# Demo coverage

Every module has an explorable sample workflow. This is demonstration coverage, not production completion. The 255-row scope register preserves outstanding requirements. Several modules use staged fictional records; integrations and real-world outcomes are simulated.

| Module | Area | Demo |
|---|---|---|
| M01 | Organisation & properties | Set up a fictional operator, property and plan. |
| M02 | Rooms & beds | Add a room and track whether a bed can be allocated. |
| M03 | People & access | Invite a fictional member and follow account activation. |
| M04 | Resident home | Try the resident app, room identity and service shortcuts. |
| M05 | Notices & communications | Publish a message and distinguish a read from an acknowledgement. |
| M06 | Visitor invitations | Invite a visitor and follow reception approval. |
| M07 | Visitor reception | Verify arrivals, record presence and revoke a pass after checkout. |
| M08 | Incident reports | Submit a report and follow a human response. |
| M09 | Confidential support | Request help, assign a care contact and record a follow-up. |
| M10 | Repairs & work orders | Report a fault, assign work and confirm the repair. |
| M11 | Shifts & handovers | Prepare a handover and explicitly accept outstanding work. |
| M12 | Residence performance | Build an operational report from this sandbox’s records. |
| M13 | Find accommodation | Review a fictional listing and record an enquiry. |
| M14 | Applications & documents | Submit a sample application and follow its review. |
| M15 | Room selection | Hold a bed and progress through a sample allocation. |
| M16 | Agreements & move-in | Walk through an agreement, room inspection and key return. |
| M17 | Utilities & outages | Publish a disruption and update its restoration status. |
| M18 | Facilities, parcels & lost property | Book a facility slot or follow parcel and lost-property handling. |
| M19 | Roommates & transfers | Request mediation or a room transfer with a review trail. |
| M20 | Student wellbeing | Private journal, weekly check-in, confidential support and monitored-mode explanation. |
| M21 | Events & community | Create an event, record attendance and capture a poll response. |
| M22 | Finance & reconciliation | Follow a fictional invoice and payment reconciliation. |
| M23 | Compliance evidence | Track an inspection, certificate metadata and a remedial task. |
| M24 | Transport & shuttles | Check a sample timetable and publish a service delay. |
| M25 | SOS & emergency response | Send a demo SOS, acknowledge it and rehearse escalation. |
| M26 | Doors & access adapters | Rehearse a controller decision and revocation without hardware. |
| M27 | Portfolio intelligence | Review cross-property sample evidence and publication approval. |
| M28 | Platform support | Request time-limited support access and review revocation. |
| M29 | Integrations & webhooks | Test a sample delivery failure, retry and final acknowledgement. |
| M30 | Partner marketplace | Submit a fictional partner listing for moderation and handoff. |
| M31 | Mobile & low-data access | Explore responsive screens and rehearse an offline queue. |
| M32 | Feedback & service pulse | Rate a fictional completed service and review privacy-safe reporting. |
