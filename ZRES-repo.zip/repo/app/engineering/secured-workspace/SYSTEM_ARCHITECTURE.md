# System architecture
13 November 2026 · Development milestone

## Audit and decision
Original: Node HTTP server, JSON-file persistence, browser-supplied role, synthetic shared resident and static marketing/phone/admin screens. Existing smoke tests passed but did not prove authentication, tenant separation or concurrent safety. The hosted static demo uses browser simulation and is not a backend deployment. Original source is preserved.

New default: workspace/index.html + workspace.js + workspace.css → secure-server.js /api/v1 → lib/auth.js and lib/service.js → lib/store.js → migrations/001.sql → local SQLite WAL. No framework or third-party runtime package was introduced. This is an isolated development foundation; SQLite is not presented as the managed production database required by the scope.

Authenticated users carry server-owned tenant/property/role/room. Request tenant or role parameters cannot change membership. Reads filter scope and then record permissions. Mutations reauthenticate inside BEGIN IMMEDIATE, validate transitions and record an audit event before commit. Reservations and allocations additionally enforce interval conflicts in database triggers. Idempotency caches successful mutation results; journal deletion removes its cached create result.

## Production target — not implemented
Managed PostgreSQL with tenant/property keys, row-level policies, composite foreign keys, exclusion constraints for occupied intervals and transactional row locking for visitor transitions. Separate API and worker services; transactional outbox; managed private object storage with quarantine/scanning; OIDC/WebAuthn or reviewed account enrollment/recovery; TLS ingress; key vault; encrypted database/backups; immutable external audit sink; monitoring/alerts; deployment and restore rehearsal.

Migrate explicitly with a validated importer and reconciliation counts. Do not silently import the unauthenticated legacy demo JSON into production. Rehearse migrations and rollback on synthetic staging data first. A manager may eventually span properties through explicit memberships; the local model currently binds one account to one property.

## API inventory
POST /api/v1/login; GET /api/v1/me; POST /api/v1/logout.
GET /api/v1/records?kind=…; POST /api/v1/records/:kind.
POST /api/v1/records/:id/:action, including journal delete.
GET /api/v1/metrics?days=7|30|90; GET staff, allocations, audit.
POST allocate; POST deactivate. See secure-server.js for exact validation and roles.
POST monitored-reflection always returns unavailable.

## Metrics
Occupancy: allocations active at request time; vacancy = bed records minus active allocations.
Open/overdue repairs: current unresolved snapshot, overdue when dueAt is in the past.
Resolved count and median resolution hours: records with closedAt within the selected rolling 7/30/90 days; median uses sorted created-to-closed durations, null without samples.
Notice acknowledgements: sum of distinct explicit acknowledgements divided by summed recipient snapshots on acknowledgement-required notices created in the selected period.
Visitors inside: physical presence INSIDE, including expired visits. Overstays: INSIDE and endAt at/before now.
Wellbeing aggregates are suppressed. No inferred wellbeing score exists.
Current snapshots and selected-period measures must not be compared as if both were historical snapshots. Prior-period, portfolio, workload and many required indicators remain missing.

## Boundaries
No notification adapter is live. A received case is a database receipt, not a human acknowledgement or dispatched responder. No scanner/device credential is issued. Visitor reference is a registry identifier; staff must verify identity separately. Physical exits are outside application control.

