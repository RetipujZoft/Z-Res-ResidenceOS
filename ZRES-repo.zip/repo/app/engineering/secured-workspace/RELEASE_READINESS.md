# Release readiness
13 November 2026 · Decision: development demonstration only.

| Environment / capability | Decision |
|---|---|
| Local fictional-data evaluation | Available through authenticated workspace |
| Controlled live-resident pilot | Blocked |
| Commercial production | Blocked; NODE_ENV=production deliberately refuses startup |
| Existing hosted sales demo | Remains a separate simulated presentation |
| Door unlocking / emergency dispatch / monitored reflection | Disabled |
| Payments, live GPS, real notifications | Not implemented |

Exit criteria for P0: managed database and enforced scope policies; encrypted hosting/secrets/backups; approved authentication lifecycle; private uploads; outbox/retry/escalation; complete operational role workflows; documented responder ownership; full acceptance matrix evidence; restore rehearsal; load/accessibility/mobile testing; independent penetration test and remediation; operator and privacy/safety sign-off.

These are substantive missing implementation and acceptance steps. Removing the startup guard is not a deployment procedure. The repository contains no evidence authorising its removal.

Completed milestone: isolated transactional local foundation plus selected service workflows and 19 passing backend regression tests. Desktop student browser smoke verification identified and fixed an empty-MFA sign-in bug. See TEST_RESULTS.md for precise evidence and gaps. All requirement statuses remain conservative.

