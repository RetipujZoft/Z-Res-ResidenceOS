'use strict';
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const { Store }=require('./lib/store');
const auth=require('./lib/auth');
const service=require('./lib/service');
const ROOT=path.join(__dirname,'workspace');
function createServer({filename=process.env.ZRES_DB || path.join(__dirname,'data/local-v22.sqlite'),origin=process.env.ZRES_ORIGIN}={}) {
  if(process.env.NODE_ENV==='production') throw new Error('Production release blocked. See RELEASE_READINESS.md.');
  const store=new Store(filename);
  const attempts=new Map();
  function rate(key,limit) {
    const time=Date.now();
    for(const [k,v] of attempts) if(v.reset<time) attempts.delete(k);
    const bucket=attempts.get(key)||{count:0,reset:time+60000};
    bucket.count++;attempts.set(key,bucket);
    if(bucket.count>limit)service.fail('Too many requests. Try again in a minute.',429);
  }
  function send(res,status,value,headers={}) {
    res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers});
    res.end(JSON.stringify(value));
  }
  async function read(req) {
    if(!String(req.headers['content-type']).startsWith('application/json')) service.fail('Use application/json.',415);
    let size=0,body='';
    for await(const chunk of req) {
      size+=chunk.length;
      if(size>48000)service.fail('Request is too large.',413);
      body+=chunk;
    }
    try{return JSON.parse(body||'{}');}catch{service.fail('Invalid JSON.');}
  }
  const server=http.createServer(async(req,res)=>{
    res.setHeader('X-Content-Type-Options','nosniff');
    res.setHeader('Referrer-Policy','no-referrer');
    res.setHeader('X-Frame-Options','DENY');
    res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
    let user;
    const url=new URL(req.url,'http://localhost');
    const token=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('zres_session='))?.slice(13);
    try {
      const expected=origin || 'http://'+req.headers.host;
      const validHosts=['127.0.0.1','localhost','[::1]'];
      if(!validHosts.includes(new URL(expected).hostname) && !origin)service.fail('Unrecognised host.',403);
      if(url.pathname==='/health' && req.method==='GET')return send(res,200,{ok:true,environment:'local-synthetic',hardware:false,dispatch:false});
      if(url.pathname.startsWith('/api/')) {
        rate('ip:'+req.socket.remoteAddress,240);
        if(req.method!=='GET' && req.headers.origin!==expected)service.fail('Origin check failed.',403);
        if(url.pathname==='/api/v1/login' && req.method==='POST') {
          rate('login:'+req.socket.remoteAddress,10);
          const body=await read(req);
          service.validate(body,{email:{max:254},password:{max:256},otp:{max:6,optional:true}});
          const session=auth.login(store,body.email,body.password,body.otp);
          if(token)store.run('DELETE FROM sessions WHERE token_hash=?',auth.hash(token));
          return send(res,200,{csrf:session.csrf},{'Set-Cookie':'zres_session='+session.token+'; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800'+(expected.startsWith('https:')?'; Secure':'')});
        }
        user=auth.authenticate(store,token);
        if(req.method==='GET') {
          if(url.pathname==='/api/v1/me')return send(res,200,{id:user.id,name:user.name,role:user.role,room:user.room,csrf:user.csrf,property:store.get('SELECT name FROM properties WHERE tenant=? AND id=?',user.tenant,user.property).name,environment:'local-synthetic'});
          if(url.pathname==='/api/v1/metrics') {
            const result=service.metrics(store,user,Number(url.searchParams.get('days')||30));
            store.audit(user,'metrics.read');
            return send(res,200,result);
          }
          if(url.pathname==='/api/v1/staff') {
            service.allow(user,['manager','owner','reception','security','houseparent']);
            return send(res,200,store.all("SELECT id,name,role FROM users WHERE tenant=? AND property=? AND active=1 AND role NOT IN ('student','applicant')",user.tenant,user.property));
          }
          if(url.pathname==='/api/v1/allocations') {
            service.allow(user,['manager','owner']);
            return send(res,200,store.all('SELECT bed,resident,begins,ends FROM allocations WHERE tenant=? AND property=?',user.tenant,user.property));
          }
          if(url.pathname==='/api/v1/audit') {
            service.allow(user,['owner','securityadmin']);
            store.audit(user,'audit.read');
            return send(res,200,store.all('SELECT sequence,event,digest FROM audit WHERE tenant=? AND property=? ORDER BY sequence DESC LIMIT 200',user.tenant,user.property));
          }
          if(url.pathname==='/api/v1/records') {
            const kind=url.searchParams.get('kind');
            if(!/^[a-z]{3,20}$/.test(kind))service.fail('Choose a record type.');
            const result=service.list(store,user,kind);
            if(['support','incident','journal','checkin'].includes(kind))store.audit(user,'read.'+kind);
            return send(res,200,result);
          }
          service.fail('Endpoint not found.',404);
        }
        if(req.method!=='POST')service.fail('Method not allowed.',405);
        if(req.headers['x-csrf-token']!==user.csrf)service.fail('Refresh your session and try again.',403);
        const body=await read(req);
        const key=req.headers['idempotency-key'];
        if(!key||!/^[-a-zA-Z0-9]{16,100}$/.test(key))service.fail('A valid idempotency key is required.');
        const fingerprint=auth.hash(url.pathname+JSON.stringify(body));
        const result=store.transaction(()=>{
          // Recheck session inside the transaction so offboarding cannot race a write.
          user=auth.authenticate(store,token);
          const prior=store.get('SELECT * FROM idempotency WHERE user_id=? AND key=?',user.id,key);
          if(prior) {
            if(prior.fingerprint!==fingerprint)service.fail('This request key was used for another action.',409);
            return JSON.parse(prior.response);
          }
          let value;
          const route=url.pathname.match(/^\/api\/v1\/records\/([a-z]+)$/);
          const operation=url.pathname.match(/^\/api\/v1\/records\/([a-f0-9-]{36})\/([a-z]+)$/);
          if(route)value=service.exposed(user,service.create(store,user,route[1],body));
          else if(operation) {
            if(operation[2]==='delete') {
              service.validate(body,{});
              const record=service.getRecord(store,user,operation[1],'journal');
              store.run('DELETE FROM records WHERE tenant=? AND property=? AND id=? AND owner=?',user.tenant,user.property,record.id,user.id);
              store.run("DELETE FROM idempotency WHERE user_id=? AND json_extract(response,'$.id')=?",user.id,record.id);
              value={deleted:true};
            } else value=service.exposed(user,service.action(store,user,operation[1],operation[2],body));
          } else if(url.pathname==='/api/v1/allocate') {
            service.allow(user,['manager','owner']);
            service.validate(body,{bed:{max:100},resident:{max:100},start:{type:'number'},end:{type:'number'}});
            if(body.end<=body.start||!service.list(store,user,'bed').some(r=>r.id===body.bed))service.fail('Choose a valid bed and period.');
            if(!store.get("SELECT id FROM users WHERE id=? AND tenant=? AND property=? AND role='student' AND active=1",body.resident,user.tenant,user.property))service.fail('Active resident not found.');
            try {store.run('INSERT INTO allocations VALUES (?,?,?,?,?,?)',user.tenant,user.property,body.bed,body.resident,body.start,body.end);}
            catch(error){if(String(error.message).includes('conflict'))service.fail('This bed or resident already has an overlapping allocation.',409);throw error;}
            value={allocated:true};
          } else if(url.pathname==='/api/v1/deactivate') {
            service.allow(user,['owner']);
            service.validate(body,{id:{max:100}});
            const target=store.get('SELECT id,role FROM users WHERE id=? AND tenant=? AND property=?',body.id,user.tenant,user.property);
            if(!target||target.id===user.id||target.role==='owner')service.fail('Account cannot be deactivated.',403);
            store.run('UPDATE users SET active=0 WHERE id=?',target.id);
            store.run('DELETE FROM sessions WHERE user_id=?',target.id);
            value={deactivated:true};
          } else if(url.pathname==='/api/v1/logout') {
            store.run('DELETE FROM sessions WHERE token_hash=?',auth.hash(token));
            value={signedOut:true};
          } else if(url.pathname==='/api/v1/monitored-reflection') {
            service.fail('Safety-monitored reflections are disabled pending safeguarding approval and verified duty coverage.',503);
          } else service.fail('Endpoint unavailable.',404);
          store.audit(user,url.pathname,value?.id || '');
          store.run('INSERT INTO idempotency VALUES (?,?,?,?)',user.id,key,fingerprint,JSON.stringify(value));
          return value;
        });
        return send(res,200,result);
      }
      if(!['GET','HEAD'].includes(req.method))service.fail('Method not allowed.',405);
      const requested=url.pathname==='/'?'/index.html':decodeURIComponent(url.pathname);
      const file=path.resolve(ROOT,'.'+requested);
      if(!file.startsWith(ROOT+path.sep))service.fail('Not found.',404);
      const extension=path.extname(file);
      const mime={'.html':'text/html; charset=utf-8','.css':'text/css','.js':'text/javascript','.woff2':'font/woff2'};
      if(!mime[extension]||!fs.existsSync(file)||!fs.statSync(file).isFile())service.fail('Not found.',404);
      res.writeHead(200,{'Content-Type':mime[extension],'Cache-Control':'no-cache'});
      res.end(req.method==='HEAD'?undefined:fs.readFileSync(file));
    }catch(error) {
      const status=error.status||500;
      if(user)store.audit(user,url.pathname,'',status===500?'server-error':'denied-'+status);
      if(status===500)console.error(JSON.stringify({event:'request.failed',path:url.pathname,status}));
      if(!res.headersSent)send(res,status,{error:status===500?'The request could not be completed. Please try again.':error.message});
    }
  });
  server.requestTimeout=15000;
  server.headersTimeout=10000;
  server.on('close',()=>store.close());
  return {server,store};
}
if(require.main===module) {
  const {server}=createServer();
  server.listen(Number(process.env.PORT||4180),'127.0.0.1',()=>{
    console.log('Z’RES local development workspace: http://127.0.0.1:'+server.address().port);
  });
}
module.exports={createServer};

