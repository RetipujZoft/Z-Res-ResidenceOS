# Changelog
## 13 November 2026 — v2.2 development milestone
Audited the original JSON-backed sales demo and ran its existing smoke suite. Extracted 255 module, security, wellbeing, role, workflow and prose requirement records before implementation; no AGENTS.md was found in the checked project/parent locations.

Added a separate default authenticated workspace; kept the original presentation sources. Implemented local transactional storage, repeatable schema DDL, scoped access, scrypt passwords, staff TOTP, session revocation, CSRF/origin validation, audit and API idempotency.

Added atomic visitor registry, interval-safe bed allocations and bookings, repair/case acknowledgement histories, targeted notices, student service submissions, private encrypted journal, optional check-ins and limited canonical reporting. Disabled monitored reflection, hardware and dispatch. Added an explicit production startup block.

Added 19 backend regression tests. Fixed cached-journal-envelope deletion, home reminder postponement and browser sign-in sending blank optional MFA. Documented incomplete scope and deployment gates rather than marking a whole module complete on the strength of a page.


## Simplified demo experience
Grouped role-aware navigation, phone bottom bar, category hubs, search, progressive forms, clearer privacy copy and simpler launcher. See DEMO_EXPERIENCE.md for verification.

## Reference-style update
Adopted the supplied prototype's Plex typography, white top tabs, blue room identity panel and compact role-scoped staff desk. See REFERENCE_UPDATE.md.
