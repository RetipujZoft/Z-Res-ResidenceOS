const crypto = require('crypto');
const uid = (prefix) => `${prefix}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
const t = (mins) => new Date(Date.now() + mins * 60000).toISOString();
function seed() {
 const rooms=[]; let i=0;
 for(const block of ['A','B','C']) for(let floor=1;floor<=4;floor++) for(let r=1;r<=10;r++) {
   const number=`${block}-${floor}${String(r).padStart(2,'0')}`;
   const type=r%5===0?'Studio':'Shared';
   const beds=type==='Studio'?['A']:['A','B'];
   rooms.push({id:number,block,floor,number,type,price:type==='Studio'?4650:3550,beds:beds.map((name,j)=>({id:`${number}-${name}`,name,occupied:(i++%7!==0)}))});
 }
 const own=rooms.find(r=>r.id==='B-204'); own.beds[0].occupied=true; own.beds[0].resident='Lerato Molefe';
 const a=[
  {id:'ANN-1001',title:'Water supply maintenance in Block C',body:'Scheduled maintenance will affect water supply in Block C tomorrow, 10:00–12:00. Please plan ahead.',scope:'Block C',level:'Important',author:'Residence Management',createdAt:t(-300),reads:[]},
  {id:'ANN-1002',title:'Community movie night this Friday',body:'Join us in the social lounge at 19:00 for a community movie evening. RSVP at reception.',scope:'All residents',level:'Community',author:'House Parents',createdAt:t(-720),reads:[]},
  {id:'ANN-1003',title:'Updated shuttle departure points',body:'The first shuttle will depart from Main Gate at 06:45. Please be at the stop at least five minutes early.',scope:'All residents',level:'Transport',author:'Transport Desk',createdAt:t(-1200),reads:[]}
 ];
 return {
  meta:{revision:1,createdAt:new Date().toISOString(),organization:'Nova Heights Student Living',fictional:true},
  resident:{id:'STD-1042',name:'Lerato Molefe',email:'lerato@example.test',room:'B-204',block:'B',bed:'A',avatar:'LM',studentNumber:'DEMO-241108'},
  rooms,
  announcements:a,
  incidents:[
   {id:'INC-2401',category:'Noise next door',priority:'Routine',location:'Block B · Room B-205',reporter:'Lerato Molefe',room:'B-204',description:'Loud music from a nearby room after quiet hours.',status:'Acknowledged',assignedTo:'House Parents',createdAt:t(-34),acknowledgedAt:t(-31),timeline:[{label:'Reported',at:t(-34)},{label:'Acknowledged by House Parents',at:t(-31)}]},
   {id:'INC-2398',category:'Suspicious person',priority:'High',location:'Block A · Main lobby',reporter:'Palesa T.',room:'A-111',description:'An unknown person repeatedly tried to enter behind residents.',status:'In progress',assignedTo:'Reception',createdAt:t(-67),acknowledgedAt:t(-64),timeline:[{label:'Reported',at:t(-67)},{label:'Reception acknowledged',at:t(-64)}]},
   {id:'INC-2389',category:'Harassment',priority:'High',sensitive:true,location:'Block C · Floor 2',reporter:'Confidential resident',room:'Restricted',description:'Sensitive safeguarding concern — visible to designated House Parents only.',status:'Awaiting acknowledgement',assignedTo:'House Parents',createdAt:t(-15),timeline:[{label:'Confidential report received',at:t(-15)}]}
  ],
  maintenance:[
   {id:'MT-3101',title:'Air conditioner not cooling',category:'Electrical',location:'B-204',reporter:'Lerato Molefe',description:'Air conditioner only blows warm air.',priority:'Medium',status:'In progress',assignee:'Maintenance Team',createdAt:t(-60),updates:[{text:'Technician assigned',at:t(-30)}]},
   {id:'MT-3098',title:'Leaking bathroom tap',category:'Plumbing',location:'A-203',reporter:'Mpho K.',description:'Tap keeps dripping even when closed.',priority:'Medium',status:'Open',assignee:'Unassigned',createdAt:t(-400),updates:[]},
   {id:'MT-3082',title:'Wi-Fi weak in study zone',category:'Connectivity',location:'Block C · Study hub',reporter:'Naledi S.',description:'Intermittent connectivity after 17:00.',priority:'Low',status:'Resolved',assignee:'IT Support',createdAt:t(-2800),updates:[{text:'Network point reset',at:t(-2000)}]}
  ],
  visitors:[
   {id:'VIS-4201',ref:'VIS-4201',hostId:'STD-1042',host:'Lerato Molefe',room:'B-204',name:'Kabelo Dlamini',idSuffix:'7812',photo:'',purpose:'Study group',startAt:t(-60),endAt:t(100),state:'inside',approvedAt:t(-90),enteredAt:t(-50),exitedAt:null,credential:uid('PASS')},
   {id:'VIS-4202',ref:'VIS-4202',hostId:'STD-1042',host:'Lerato Molefe',room:'B-204',name:'Anele Khumalo',idSuffix:'6124',photo:'',purpose:'Visit',startAt:t(-5),endAt:t(180),state:'approved',approvedAt:t(-40),enteredAt:null,exitedAt:null,credential:uid('PASS')},
   {id:'VIS-4197',ref:'VIS-4197',hostId:'STD-1042',host:'Lerato Molefe',room:'B-204',name:'Sibusiso N.',idSuffix:'1134',photo:'',purpose:'Study group',startAt:t(-300),endAt:t(45),state:'checkedout',approvedAt:t(-340),enteredAt:t(-270),exitedAt:t(-100),credential:uid('PASS')},
   {id:'VIS-4190',ref:'VIS-4190',hostId:'STD-1042',host:'Lerato Molefe',room:'B-204',name:'Naledi M.',idSuffix:'4110',photo:'',purpose:'Visit',startAt:t(-350),endAt:t(-20),state:'approved',approvedAt:t(-400),enteredAt:null,exitedAt:null,credential:uid('PASS')}
  ],
  applications:[
   {id:'APP-2013',name:'Keabetswe Mokoena',email:'keabetswe@example.test',property:'Nova Heights',roomType:'Shared',bedId:null,status:'Pending review',submittedAt:t(-900),funding:'Private'},
   {id:'APP-2012',name:'Lindokuhle Nkosi',email:'lindi@example.test',property:'Nova Heights',roomType:'Studio',bedId:'A-105-A',status:'Approved',submittedAt:t(-1200),funding:'Private'},
   {id:'APP-2010',name:'Thabo Ndlovu',email:'thabo@example.test',property:'Nova Heights',roomType:'Shared',bedId:null,status:'Documents required',submittedAt:t(-3600),funding:'NSFAS — referral only'}
  ],
  facilities:[{id:'FAC-1',name:'Study Room 1',type:'Study',capacity:8,icon:'book-open'},{id:'FAC-2',name:'Laundry Bay A',type:'Laundry',capacity:1,icon:'shirt'},{id:'FAC-3',name:'Community Lounge',type:'Social',capacity:25,icon:'sofa'},{id:'FAC-4',name:'Gym Studio',type:'Fitness',capacity:8,icon:'activity'}],
  facilityBookings:[{id:'FB-101',facilityId:'FAC-1',date:new Date().toISOString().slice(0,10),slot:'16:00',residentId:'STD-1042'}],
  supportRequests:[], transfers:[], messages:[],
  shuttles:[{id:'BUS-1',name:'Campus Express',route:'Nova Heights → Main Campus',stop:'Main Gate',eta:8,progress:62,status:'On route',driver:'Demo Driver A'},{id:'BUS-2',name:'Evening Connector',route:'Nova Heights → City Campus',stop:'Main Gate',eta:24,progress:28,status:'Scheduled',driver:'Demo Driver B'}],
  audit:[{id:uid('LOG'),label:'Demo workspace created',actor:'System',at:t(-1440)}]
 };
}
module.exports={seed,uid};
