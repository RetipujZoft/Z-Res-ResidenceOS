@echo off
title ZRES Demo
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Install Node.js 24.22.1 or newer, then open this file again.
  pause
  exit /b 1
)
node tools/launch-local.js
if errorlevel 1 pause
