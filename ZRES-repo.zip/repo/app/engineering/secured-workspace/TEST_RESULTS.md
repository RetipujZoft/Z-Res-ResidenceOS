# Test results
13 November 2026 · Windows · Node.js 24.22.1

## Automated evidence
Original baseline: node tests/smoke.js passed before implementation. That suite exercises the unauthenticated sales demo only; some assertions reflect the original broad case exposure and are not security acceptance criteria.

Final new suite: node --test --test-isolation=none tests/secure.test.js → 19 passed, 0 failed, 0 skipped; 9.764 seconds. Standard child-process test mode previously passed 18 tests, but a later Windows spawn EPERM required the documented in-process runner. No test was removed to obtain a pass.

Passing tests:
1. Unauthenticated API and forged role header cannot impersonate staff.
2. Password login requires staff MFA; OTP replay denied; cookie flags checked.
3. Invalid schemas, CSRF, origin and oversized payload reject writes.
4. Foreign tenant/property identifiers cannot read or mutate tested records.
5. Same idempotency key replays the result; different body conflicts.
6. Concurrent entry across gates admits exactly once and logs denial.
7. Reference alone cannot verify identity; expiry preserves physical presence.
8. Medical/support narratives denied to manager, reception and finance.
9. Journal ciphertext is owner-only; deletion clears record and cached envelope.
10. All check-in decisions leave essential APIs available; monitored mode unavailable.
11. Notice audience, reads and explicit acknowledgement stay distinct.
12. Concurrent facility booking conflicts; cancellation releases the interval.
13. Atomic allocations reject bed and resident overlaps; occupancy reconciles.
14. Maintenance requires valid human stages and resolution evidence; resident can reopen.
15. Handover requires recipient acceptance and retains outstanding work.
16. Audit update/delete denied; reopened database has records and integrity_check=ok.
17. Applicant tracks own application; all 12 provisioned roles have basic me/metrics/journal boundaries.
18. Offboarding, inactive account and expired session denied.
19. Login rate limiting and production startup block enforced.

Role fixtures inject sessions for authorization tests; they do not stand in for end-to-end staff login. MFA has its own login test. Multi-gate tests use simultaneous HTTP requests to the same local process/database; distributed production concurrency is not certified. Reopening the database is not a disaster-recovery/backup restore test.

## Browser evidence
In-app browser initially timed out, then attached successfully. Desktop student sign-in verified after fixing optional empty MFA field. Home rendered canonical zero counts in fresh seed. Remind me later saved, removed the prompt and left essential actions available. A fictional repair was submitted and visibly saved with status Open and activity history.
Student navigation was exercised through visitor, incident, notices, utility, support, journal, applications, booking, transfer, complaints, parcels, lost property, events, transport and resources. Some immediate snapshots captured loading states; this is not evidence of every completed workflow.
At 390×844, maintenance layout was visually inspected: responsive horizontal navigation, readable controls and no document-width overflow (scrollWidth 375, viewport 390). Viewport reset afterward.
Journal disclosure and disabled monitored-reflection notice were inspected. Browser encrypt/decrypt/export was not fully exercised.

## Found and corrected
Blank staff OTP submitted by student login; applicant could submit but could not list its own application; deleted journal envelopes remained in idempotency cache; postponed weekly prompt remained visible. A new role test initially collided with the dedicated MFA replay test's consumed OTP; fixtures were separated and the full suite rerun successfully.

## Not yet verified
Every staff screen/end-to-end workflow; full original UI browser audit; complete same-tenant multi-property and same-role peer matrix; keyboard/screen-reader WCAG audit; Android/iOS/low-data; connectivity retry and crash recovery; load/soak; durable backup/restore; managed PostgreSQL migrations; crypto review; independent penetration testing; live provider/hardware safety tests. No 100% completion or production-readiness claim follows from these tests.

