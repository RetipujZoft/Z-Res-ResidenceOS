# Reference-style demo
13 November 2026

Reference: supplied Retipuj_Residence_OS_Blue_Prototype (8)/Retipuj_Residence_OS_Sales_Prototype.

App styling now uses the supplied IBM Plex fonts, white top navigation, compact bordered service rows, blue student room identity panel and a staff desk with role-scoped pending queues. Grouped services, Student wellbeing and fixed phone navigation remain. All new desk counts derive from the authenticated record lists. No new role-switch bypass or legacy unauthenticated API was introduced.

Browser verified: student sign-in, desktop home, 390px phone home/wellbeing, manager MFA sign-in, real pending repair queue and queue-to-maintenance navigation. Room number wrapping found on phone and corrected with a non-shrinking nowrap plate. The original folder was only read.

This update matches the reference's application styling. It does not turn the legacy marketing split-view simulator into a secure multi-session production integration. Full product release gaps remain in KNOWN_LIMITATIONS.md.
