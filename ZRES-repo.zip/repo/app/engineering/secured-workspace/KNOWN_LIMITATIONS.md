# Known limitations
The full v2.2 request is unfinished. The coverage matrix intentionally retains partial, missing and blocked work.

P0 blockers: managed production DB and database-level scope controls; full account lifecycle and phishing-resistant MFA/step-up; TLS/at-rest encryption/secret manager; secure document storage; durable notifications and escalation; backup/restore evidence; production logging/alerts; complete role and property test matrix; independent penetration test; named responder procedures and pilot approval.

P1 gaps: profile editing, accommodation discovery, private documents, full admissions, room/bed selection and agreements, move-in/out, approved transfers and roommate mediation, utility detail, parcel/lost-property completion, polls, finance/compliance, referral scheduling, comprehensive management/portfolio intelligence, wellbeing privacy review, accessibility and low-data acceptance. Current application/transfer/event records are partial workflows.

P2 gates: payment reconciliation, GPS, emergency dispatch, door controllers, integrations and monitored safeguarding cannot be presented as operational. They require contracts, providers, consent/safety design and site acceptance.
P3: marketplace and ecosystem remain unimplemented.

Current model: one property per user, limited immutable role vocabulary, synthetic provisioner only, generic records, no durable background worker. Finance/platform accounts intentionally have only resource access, not simulated functional dashboards. Reporting is a limited snapshot and selected-period report, not the full management specification.

Journal deletion does not erase encrypted remnants from SQLite storage/WAL or historical backups. No lifecycle/retention engine. Browser journal passphrases cannot be recovered. Journal crypto is not independently audited.
Check-in week boundaries currently use UTC seven-day epochs, not configurable residence calendars. Reminder postponement is local-app prompting, not a scheduled message.
Visitor registry has atomic staff transitions but no secure physical-access credential. Local verification digits are not sufficient production identity checks.
Client retry does not yet persist idempotency keys across a lost response. API idempotency is tested, but an uncertain client retry can create another request. Connectivity/recovery UX remains incomplete.
Original sales demo remains unauthenticated and fictional. It is excluded from the new default server but can still be explicitly run as a legacy demo.

No claim of complete commercial readiness, full scope coverage, WCAG conformance, load readiness or independent security testing is made.

