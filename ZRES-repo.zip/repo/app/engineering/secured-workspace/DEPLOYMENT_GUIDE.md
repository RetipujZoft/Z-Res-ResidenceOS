# Deployment guide
## Local evaluation
Use Node 24.22.1+ with built-in SQLite. No npm install is needed. Run npm run setup once, then npm start. Browse http://127.0.0.1:4180. Generated synthetic credentials are in data/LOCAL-ACCOUNTS.json. Use tools/local-code.js for staff test codes. Do not commit or distribute data/ or these credentials.

The server binds 127.0.0.1. PORT defaults to 4180. ZRES_DB can specify an absolute development database path. ZRES_ORIGIN, if set, must match the exact browser origin. Production startup is blocked. Do not expose the local test account helper or database through hosting.

To create a fresh demo without deleting existing data, stop the app and set ZRES_DB to a new empty absolute path before running setup and start. The existing database is preserved. Setup refuses to populate an already populated database.

## Backup and restore — local procedure only
Stop the server cleanly, preserve a copy of the complete data directory including any SQLite sidecar files, and record its checksum. Restore into a separate new directory, set ZRES_DB to its local-v22.sqlite path, and start a separate loopback instance. Reconcile users, records, allocations, reservations and audit chain before using it. This is a manual local procedure, not an encrypted, tested production recovery service; a live backup tool and restore drill remain outstanding.

## Production prerequisites
Provision managed PostgreSQL, isolated staging/production, TLS ingress and managed secrets. Implement and rehearse migration/rollback, row policies, outbox workers, private scanned object storage, audit sink, monitoring, encrypted backups and recovery. Replace synthetic account setup with approved identity enrollment/recovery. Establish DPA/retention and responder procedures. Run the full matrix and independent testing. The release owner must attach evidence and approve a new deployment configuration; none is provided here.

