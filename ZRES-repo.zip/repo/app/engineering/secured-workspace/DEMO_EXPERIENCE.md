# Demo experience update
13 November 2026

Student navigation now has five destinations: Home, My accommodation, Residence services, Student wellbeing, Community & safety. Staff see only the sections permitted by their existing role.

Wellbeing groups confidential support, optional weekly check-in, private journal and support resources, with clear visibility explanations. Accommodation groups applications, transfer requests and official/service updates. Services groups visitors, repairs, facilities, parcels, lost property and transport. Community and safety groups events, incidents and complaints; relevant staff also see handovers. Management holds operational reports and audits where authorised.

Desktop uses a compact sidebar. Phones use fixed bottom navigation with safe-area padding. Section pages explain choices; forms open on demand. Search finds services across the user's permitted areas. Browser history, deep links and back-to-section controls are supported. Existing API authentication and privacy boundaries are unchanged.

Verified in browser: desktop home and wellbeing grouping; service search for repair; opening the repair form and saving a fictional repair; service/category navigation at 390 and 320 pixels; facility page and back-to-section control. No horizontal page overflow observed at 390px. Reduced-motion support is included. This is not a complete WCAG or every-device certification.

Backend regression rerun: 19 passed, 0 failed, 0 skipped in 29.617 seconds. Launcher --verify passed for automatic free-port selection, workspace response and clean shutdown. JavaScript syntax checks passed.

Windows launcher prepares an empty fictional database, opens the browser using the OS URL handler, and shows synthetic student credentials in its own terminal. Type a staff role there for its synthetic sign-in details/current OTP. Actual browser auto-opening is dependent on the user's OS association; the URL is also printed. Authentication is not bypassed.

The full v2.2 production gaps and disabled integrations in KNOWN_LIMITATIONS.md still apply. This milestone improves the working demo experience; it does not implement every missing product module.
