/* Illustrative stages explain the scenario independently of its working records. */
const handoffStages = {
  visitors: ['Resident invites', 'Reception approves', 'Guest checks in'],
  repairs: ['Resident reports', 'Maintenance starts', 'Repair confirmed'],
  incidents: ['Resident reports', 'Staff acknowledge', 'Case resolved']
};
function showHandoff(key) {
  const path = document.querySelector('.record-path');
  path.replaceChildren(...handoffStages[key].map(label => {
    const step = document.createElement('li');
    step.textContent = label;
    return step;
  }));
  if (!matchMedia('(prefers-reduced-motion: reduce)').matches) {
    Array.from(path.children).forEach((step,index) => {
      step.animate([{opacity:.22, transform:'translateX(-5px)'},{opacity:1,transform:'translateX(0)'}],
        {duration:310,delay:index*160,fill:'backwards',easing:'ease-out'});
    });
  }
}

