(()=>{
const fit=()=>document.querySelectorAll('[data-fit]').forEach(c=>{const f=c.querySelector('iframe');if(!f)return;const w=+c.dataset.fit,s=c.clientWidth/w;f.style.width=w+'px';f.style.height=(c.clientHeight/s)+'px';f.style.transform=`scale(${s})`});
addEventListener('resize',fit);addEventListener('load',fit);fit();
const b=document.querySelector('.burger'),n=document.querySelector('.nav');if(b)b.onclick=()=>b.setAttribute('aria-expanded',String(n.classList.toggle('open')));
const L=document.getElementById('lap'),P=document.getElementById('pho');
if(L&&P&&document.querySelector('.scr .txt')){const set=s=>{const l=`/app?role=${s.dataset.role||'reception'}&embed=1&page=${s.dataset.lp}`,p=`/phone?embed=1&tab=${s.dataset.pp}`;if(L.getAttribute('src')!==l)L.src=l;if(P.getAttribute('src')!==p)P.src=p};
 const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)set(e.target)}),{rootMargin:'-45% 0px -45% 0px'});document.querySelectorAll('.scr .txt section').forEach(s=>io.observe(s))}
const f=document.querySelector('form.ct');if(f)f.onsubmit=e=>{e.preventDefault();const d=Object.fromEntries(new FormData(f));location.href='mailto:info@retipujzoft.co.za?subject='+encodeURIComponent("Z'Res enquiry from "+d.name)+'&body='+encodeURIComponent(`Name: ${d.name}\nOrganisation: ${d.org}\nEmail: ${d.email}\nResidences: ${d.size}\n\n${d.msg}`)};
})();
