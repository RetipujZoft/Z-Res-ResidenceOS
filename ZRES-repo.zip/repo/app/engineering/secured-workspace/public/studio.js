const scenarios = {
  visitors: ['visitors', 'visitors', 'reception', 'Invite a visitor on the resident app. Use the sample photo, then approve the invitation at reception.'],
  repairs: ['repairs', 'repairs', 'maintenance', 'Report a repair from the resident app. Start work at the maintenance desk, then mark the repair as fixed.'],
  incidents: ['safety', 'incidents', 'reception', 'Report a problem from the resident app. Acknowledge the new incident at the staff desk and follow its progress.']
};
const byId = id => document.getElementById(id);
const roleSelect = byId('role');
let scenario = new URLSearchParams(location.search).get('scenario');
if (!Object.hasOwn(scenarios, scenario)) scenario = 'visitors';
function setDesk() {
  const role = roleSelect.value;
  const page = role === 'manager' ? 'desk' : role === 'maintenance' ? 'repairs' : scenarios[scenario][1];
  const url = '/app?role=' + role + '&page=' + page;
  byId('desk-link').href = url;
  byId('lap').src = url + '&embed=1';
}
function showScenario() {
  const [tab, , role, instruction] = scenarios[scenario];
  roleSelect.value = role;
  byId('scenario-title').textContent = document.querySelector('[data-s="' + scenario + '"]').textContent;
  showHandoff(scenario);
  const url = '/phone?tab=' + tab;
  byId('phone-link').href = url;
  byId('pho').src = url + '&embed=1';
  byId('direction').textContent = instruction;
  for (const button of document.querySelectorAll('[data-s]')) button.setAttribute('aria-pressed', String(button.dataset.s === scenario));
  setDesk();
}
for (const button of document.querySelectorAll('[data-s]')) button.onclick = () => {
  scenario = button.dataset.s;
  history.replaceState(null, '', '?scenario=' + scenario);
  showScenario();
};
roleSelect.onchange = setDesk;
byId('reset').onclick = async () => {
  try {
    const response = await fetch('/api/reset', {method:'POST', headers:{'Content-Type':'application/json','x-demo-role':'manager'}, body:'{}'});
    if (!response.ok) throw Error();
    showScenario();
    byId('demo-status').textContent = 'The sample residence has been reset.';
  } catch { byId('demo-status').textContent = 'Reset failed. Please try again.'; }
};
showScenario();
