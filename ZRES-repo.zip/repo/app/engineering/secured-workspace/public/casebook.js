const notes = {
  visitors:['Reception','Someone’s here for Lerato.','Lerato sends a visitor invitation from her phone. At reception, staff review the pass, check the guest’s ID and record their arrival.','Try the visitor desk'],
  repairs:['Maintenance','The tap in B-204 is leaking.','Lerato describes the leak from her room. Maintenance picks up the ticket and marks it fixed. She can check the outcome on her phone.','Try a room repair'],
  incidents:['Reception and house parents','There’s a disturbance next door.','A resident reports the noise. The house parent sees the room and time, acknowledges the report and records how it was resolved.','Try an incident report']
};
for (const button of document.querySelectorAll('[data-case]')) button.onclick = () => {
  const key = button.dataset.case;
  showHandoff(key);
  const [owner,title,body,link] = notes[key];
  document.getElementById('case-owner').textContent = owner;
  document.getElementById('case-title').textContent = title;
  document.getElementById('case-body').textContent = body;
  const anchor = document.getElementById('case-link');
  anchor.firstChild.textContent = link + ' ';
  anchor.href = '/demo?scenario=' + key;
  for (const choice of document.querySelectorAll('[data-case]')) choice.setAttribute('aria-pressed', String(choice === button));
};
