/** Z'RES · RESIDENCE OS — SALES DEMO SERVER
 * No external packages. Demo-role switching is NOT authentication.
 * Never connect this code directly to real emergency dispatch or access hardware.
 */
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const {seed,uid}=require('./seed');
const PORT=Number(process.env.PORT||4173);
const DATA=path.join(__dirname,'data','demo-db.json');
const PUBLIC=path.join(__dirname,'public');
fs.mkdirSync(path.dirname(DATA),{recursive:true});
if(!fs.existsSync(DATA))fs.writeFileSync(DATA,JSON.stringify(seed(),null,2));
let db=JSON.parse(fs.readFileSync(DATA,'utf8'));
const listeners=new Set();
const roles=['student','reception','houseparent','manager','maintenance'];
const normRole=r=>r==='security'?'reception':r;
const staff=['reception','houseparent','manager','maintenance'];
const responders=['reception','houseparent','manager'];
const escape=s=>String(s||'').trim().slice(0,2500);
const now=()=>new Date().toISOString();
function save(label,role){db.meta.revision++;db.audit.unshift({id:uid('LOG'),label,actor:role,at:now()});db.audit=db.audit.slice(0,60);fs.writeFileSync(DATA,JSON.stringify(db,null,2));for(const r of [...listeners])try{r.write(`event: change\ndata: ${JSON.stringify({revision:db.meta.revision,label})}\n\n`)}catch(e){listeners.delete(r)}}
function respond(res,code,obj){res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(obj))}
function err(res,code,message){respond(res,code,{error:message})}
const stamp=(v)=>{const d=new Date(v);return Number.isFinite(d.getTime())?d.getTime():NaN};
function effective(v){if(v.state==='checkedout')return 'checkedout';if(v.state==='rejected')return 'rejected';if(v.state==='pending')return 'pending';if(Date.now()>stamp(v.endAt))return v.state==='inside'?'overstay':'expired';return v.state}
const sensitive=(i)=>Boolean(i.sensitive||['Harassment','Sexual misconduct','Wellbeing crisis'].includes(i.category));
function incidentPublic(i,role){if(sensitive(i)&&!['houseparent','manager'].includes(role))return {...i,reporter:'Restricted',room:'Restricted',description:'Confidential details — visible only to the designated safeguarding team.',location:'Confidential location'};return i}
function overview(role){
 let obj=JSON.parse(JSON.stringify(db));
 obj.incidents=obj.incidents.map(i=>incidentPublic(i,role));
 obj.visitors=obj.visitors.filter(v=>role!=='student'||v.hostId===db.resident.id).map(v=>({...v,effectiveStatus:effective(v)}));
 if(role==='maintenance'){obj.incidents=[];obj.visitors=[];obj.messages=[];obj.supportRequests=[];obj.transfers=[];obj.applications=[];}
 if(role==='student'){obj.incidents=obj.incidents.filter(x=>x.reporter===db.resident.name);obj.audit=[];obj.applications=obj.applications.filter(x=>x.name===db.resident.name);obj.maintenance=obj.maintenance.filter(x=>x.reporter===db.resident.name||x.location===db.resident.room);obj.supportRequests=obj.supportRequests.filter(x=>x.residentId===db.resident.id);obj.transfers=obj.transfers.filter(x=>x.residentId===db.resident.id);obj.messages=obj.messages.filter(x=>x.residentId===db.resident.id);}
 obj.rooms=obj.rooms.map(r=>({...r,beds:r.beds.map(b=>({id:b.id,name:b.name,occupied:b.occupied}))}));
 obj.meta={...obj.meta,mode:'DEMONSTRATION',readOnlySafety:true};
 return obj;
}
function requiredRole(role,allowed){if(!allowed.includes(role))throw Object.assign(new Error('This action is not available to the selected demo role.'),{code:403})}
function assert(cond,msg,code=400){if(!cond)throw Object.assign(new Error(msg),{code})}
function field(x,min=1,max=250){return typeof x==='string'&&x.trim().length>=min&&x.trim().length<=max}
async function body(req){return new Promise((resolve,reject)=>{let size=0,str='';req.on('data',b=>{size+=b.length;if(size>2_800_000){reject(Object.assign(new Error('Upload exceeds the demo size limit.'),{code:413}));req.destroy();return;}str+=b});req.on('end',()=>{try{resolve(str?JSON.parse(str):{})}catch{reject(Object.assign(new Error('Invalid JSON'),{code:400}))}});req.on('error',reject)})}
const userName=role=>({student:db.resident.name,reception:'Reception',houseparent:'House Parent',manager:'Management',maintenance:'Maintenance Team'}[role]);
function processAction(url,role,b){let m,item;
 if(url==='/api/incidents'&&role==='student'){
  assert(field(b.category), 'Choose an incident category.');
  const allowed=['SOS / Immediate danger','Medical','Fire / smoke','Assault / threat','Harassment','Suspicious person','Noise next door','Corridor noise','Roommate conflict','Electrical danger','Other'];
  assert(allowed.includes(b.category),'Invalid incident category.');
  const critical=['SOS / Immediate danger','Medical','Fire / smoke','Assault / threat'].includes(b.category);
  const high=['Harassment','Suspicious person','Electrical danger'].includes(b.category);
  const assigned=['Harassment','Roommate conflict','Noise next door','Corridor noise'].includes(b.category)?'House Parents':'Reception';
  const incident={id:uid('INC'),category:b.category,priority:critical?'Critical':high?'High':'Routine',sensitive:b.category==='Harassment',location:escape(b.location||`Block ${db.resident.block} · Room ${db.resident.room}`),reporter:db.resident.name,room:db.resident.room,description:escape(b.description|| (critical?'Urgent assistance requested.':'Incident submitted by resident.')),status:'Awaiting acknowledgement',assignedTo:assigned,createdAt:now(),timeline:[{label:'Report received by residence system — awaiting staff acknowledgement',at:now()}]};
  db.incidents.unshift(incident);save(`${incident.category} incident submitted`,role);return {ok:true,id:incident.id};
 }
 if((m=url.match(/^\/api\/incidents\/([^/]+)\/status$/))){requiredRole(role,responders);item=db.incidents.find(x=>x.id===m[1]);assert(item,'Incident not found.',404);if(sensitive(item)&&!['houseparent','manager'].includes(role))throw Object.assign(new Error('Restricted incident. Only designated House Parents can manage this record in the demo.'),{code:403});const allowed=['Acknowledged','In progress','Resolved'];assert(allowed.includes(b.status),'Invalid incident status.');assert(item.status!=='Resolved','This incident has already been resolved.');item.status=b.status;item.assignedTo=userName(role);if(b.status==='Acknowledged')item.acknowledgedAt=now();item.timeline.push({label:`${b.status} by ${userName(role)}`,at:now()});save(`Incident ${item.id}: ${b.status}`,role);return {ok:true};}
 if(url==='/api/visitors'&&role==='student'){
  assert(field(b.name,2,100),'Enter the visitor’s full name.');assert(/^\d{4}$/.test(String(b.idSuffix||'')),'Enter only the last four digits of the ID/passport for demo verification.');
  assert(typeof b.photo==='string'&&/^data:image\/(png|jpeg|webp);base64,/.test(b.photo)&&b.photo.length>100,'Visitor photograph is required (JPG, PNG or WebP).');
  assert(field(b.purpose,1,120),'Specify the reason for the visit.');
  const a=stamp(b.startAt),z=stamp(b.endAt);assert(Number.isFinite(a)&&Number.isFinite(z)&&z>a,'End time must be after start time.');assert(z>Date.now(),'Visit must end in the future.');assert(z-a<=24*3600*1000,'A visit cannot exceed 24 hours in this demo.');
  const v={id:uid('VIS'),ref:'VIS-'+Math.floor(100000+Math.random()*900000),hostId:db.resident.id,host:db.resident.name,room:db.resident.room,name:escape(b.name),idSuffix:b.idSuffix,photo:b.photo,purpose:escape(b.purpose),startAt:new Date(a).toISOString(),endAt:new Date(z).toISOString(),state:'pending',createdAt:now(),approvedAt:null,enteredAt:null,exitedAt:null,credential:null};
  db.visitors.unshift(v);save(`Visitor request submitted: ${v.name}`,role);return{ok:true,visitor:v.ref};
 }
 if((m=url.match(/^\/api\/visitors\/([^/]+)\/approve$/))){requiredRole(role,['reception','manager']);item=db.visitors.find(v=>v.id===m[1]);assert(item,'Visitor not found.',404);assert(item.state==='pending','Only pending visitors can be approved.');assert(Date.now()<stamp(item.endAt),'This visit has already expired.');item.state='approved';item.credential=uid('GATE')+'-'+crypto.randomBytes(6).toString('hex').toUpperCase();item.approvedAt=now();save(`Approved visitor: ${item.name}`,role);return{ok:true};}
 if((m=url.match(/^\/api\/visitors\/([^/]+)\/reject$/))){requiredRole(role,['reception','manager']);item=db.visitors.find(v=>v.id===m[1]);assert(item,'Visitor not found.',404);assert(item.state==='pending','Only pending requests can be declined.');item.state='rejected';save(`Visitor request declined: ${item.name}`,role);return{ok:true};}
 if((m=url.match(/^\/api\/visitors\/([^/]+)\/entry$/))){requiredRole(role,['reception','manager']);item=db.visitors.find(v=>v.id===m[1]);assert(item,'Visitor not found.',404);
  assert(String(b.idSuffix||'')===String(item.idSuffix),'ID verification does not match. Entry denied.',403);
  assert(item.state==='approved',item.state==='inside'?'DUPLICATE ENTRY DENIED — visitor already recorded inside.':'Credential revoked or not approved. New booking required.',409);
  assert(Date.now()>=stamp(item.startAt),'Visit has not yet started.',409);assert(Date.now()<stamp(item.endAt),'ACCESS EXPIRED — visit time ended.',409);
  item.state='inside';item.enteredAt=now();save(`Verified entry: ${item.name}`,role);return{ok:true,decision:'ENTRY GRANTED'};}
 if((m=url.match(/^\/api\/visitors\/([^/]+)\/checkout$/))){requiredRole(role,['reception','manager']);item=db.visitors.find(v=>v.id===m[1]);assert(item,'Visitor not found.',404);assert(item.state==='inside','Only a visitor recorded as inside can be signed out.',409);assert(String(b.idSuffix||'')===String(item.idSuffix),'ID verification does not match.',403);item.state='checkedout';item.exitedAt=now();item.credential=null;save(`Visitor signed out; credential permanently revoked: ${item.name}`,role);return{ok:true,decision:'CHECKOUT RECORDED — CREDENTIAL PERMANENTLY REVOKED'};}
 if(url==='/api/maintenance'&&role==='student'){
  assert(field(b.title,5,140),'Provide a maintenance issue title.');assert(field(b.description,8,1000),'Describe the issue.');
  const x={id:uid('MT'),title:escape(b.title),category:escape(b.category||'General'),location:db.resident.room,reporter:db.resident.name,description:escape(b.description),priority:escape(b.priority||'Medium'),status:'Open',assignee:'Unassigned',createdAt:now(),updates:[]};db.maintenance.unshift(x);save(`Maintenance submitted: ${x.title}`,role);return {ok:true,id:x.id};
 }
 if((m=url.match(/^\/api\/maintenance\/([^/]+)\/status$/))){requiredRole(role,['maintenance','manager','reception']);item=db.maintenance.find(x=>x.id===m[1]);assert(item,'Ticket not found.',404);assert(['Open','In progress','Resolved'].includes(b.status),'Invalid status.');item.status=b.status;item.assignee=userName(role);item.updates.push({text:`Status updated to ${b.status}${b.note?' — '+escape(b.note):''}`,at:now()});save(`Maintenance ${item.id}: ${b.status}`,role);return{ok:true};}
 if(url==='/api/announcements'){requiredRole(role,['manager','reception','houseparent']);assert(field(b.title,4,120),'Enter an announcement title.');assert(field(b.body,8,1200),'Enter the announcement message.');db.announcements.unshift({id:uid('ANN'),title:escape(b.title),body:escape(b.body),scope:escape(b.scope||'All residents'),level:escape(b.level||'General'),author:userName(role),createdAt:now(),reads:[]});save(`Announcement published: ${b.title}`,role);return {ok:true};}
 if((m=url.match(/^\/api\/announcements\/([^/]+)\/read$/))){requiredRole(role,['student']);item=db.announcements.find(x=>x.id===m[1]);assert(item,'Announcement not found.',404);if(!item.reads.includes(db.resident.id))item.reads.push(db.resident.id);save('Resident acknowledged notice',role);return{ok:true};}
 if(url==='/api/applications'&&role==='student'){
   assert(field(b.name,2,100),'Applicant name required.');assert(field(b.email,6,200)&&b.email.includes('@'),'Valid email required.');
   const selected=b.bedId?db.rooms.flatMap(x=>x.beds).find(z=>z.id===b.bedId):null;assert(!selected||!selected.occupied,'Selected bed is no longer available.',409);
   db.applications.unshift({id:uid('APP'),name:escape(b.name),email:escape(b.email),property:'Nova Heights',roomType:escape(b.roomType||'Shared'),bedId:b.bedId||null,status:'Pending review',funding:escape(b.funding||'Private'),submittedAt:now()});save(`New residence application: ${b.name}`,role);return{ok:true};
 }
 if((m=url.match(/^\/api\/applications\/([^/]+)\/status$/))){requiredRole(role,['manager','reception']);item=db.applications.find(x=>x.id===m[1]);assert(item,'Application not found.',404);assert(['Approved','Documents required','Declined'].includes(b.status),'Invalid application status.');if(b.status==='Approved'&&item.bedId){const bed=db.rooms.flatMap(r=>r.beds).find(x=>x.id===item.bedId);assert(bed&&!bed.occupied,'Requested bed has already been allocated.',409);bed.occupied=true;}item.status=b.status;save(`Application ${item.id}: ${b.status}`,role);return{ok:true};}
 if(url==='/api/facilities/book'&&role==='student'){
  assert(db.facilities.some(x=>x.id===b.facilityId),'Unknown facility.');assert(/^\d{4}-\d\d-\d\d$/.test(b.date),'Choose a date.');assert(['08:00','10:00','12:00','14:00','16:00','18:00','20:00'].includes(b.slot),'Invalid slot.');assert(!db.facilityBookings.some(x=>x.facilityId===b.facilityId&&x.date===b.date&&x.slot===b.slot),'This slot is already reserved.',409);db.facilityBookings.push({id:uid('FB'),facilityId:b.facilityId,date:b.date,slot:b.slot,residentId:db.resident.id});save('Facility booking created',role);return{ok:true};}
 if(url==='/api/transfers'&&role==='student'){assert(field(b.reason,8,1000),'Explain your transfer request.');db.transfers.unshift({id:uid('TR'),residentId:db.resident.id,room:db.resident.room,reason:escape(b.reason),preferredBlock:escape(b.preferredBlock||'Any'),status:'Pending review',createdAt:now()});save('Room transfer request submitted',role);return{ok:true};}
 if(url==='/api/support'&&role==='student'){assert(field(b.subject,4,120)&&field(b.message,8,1000),'Complete your confidential support request.');db.supportRequests.unshift({id:uid('SUP'),residentId:db.resident.id,subject:escape(b.subject),message:escape(b.message),status:'New',createdAt:now()});save('Confidential support request submitted',role);return{ok:true};}
 if(url==='/api/messages'){assert(field(b.message,1,1000),'Write a message.');db.messages.unshift({id:uid('MSG'),residentId:db.resident.id,sender:userName(role),senderRole:role,message:escape(b.message),createdAt:now()});save('Message sent to residence inbox',role);return{ok:true};}
 if((m=url.match(/^\/api\/shuttles\/([^/]+)\/update$/))){requiredRole(role,['manager','reception']);item=db.shuttles.find(x=>x.id===m[1]);assert(item,'Shuttle not found.',404);assert(['On route','Delayed','Scheduled','Arrived'].includes(b.status),'Invalid shuttle status');item.status=b.status;item.eta=Math.max(0,Math.min(120,Number(b.eta)||0));save('Shuttle status updated',role);return{ok:true};}
 if(url==='/api/reset'){requiredRole(role,['manager']);db=seed();save('Demo data reset',role);return{ok:true};}
 throw Object.assign(new Error('Action not found or unavailable to this role.'),{code:404});
}
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.jpg':'image/jpeg','.woff2':'font/woff2','.png':'image/png','.webp':'image/webp','.ico':'image/x-icon','.json':'application/json; charset=utf-8'};
const server=http.createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,'http://localhost');
  if(url.pathname==='/api/health')return respond(res,200,{ok:true,revision:db.meta.revision,mode:'demo',timestamp:now()});
  if(url.pathname==='/api/events'){
   res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive','X-Accel-Buffering':'no'});
   res.write('event: connected\ndata: {}\n\n');listeners.add(res);req.on('close',()=>listeners.delete(res));return;
  }
  if(url.pathname==='/api/state'&&req.method==='GET'){
    const rq=normRole(url.searchParams.get('role'));const role=roles.includes(rq)?rq:'student';return respond(res,200,overview(role));
  }
  if(url.pathname.startsWith('/api/')&&req.method==='POST'){
   const rh=normRole(req.headers['x-demo-role']);const role=roles.includes(rh)?rh:'student';let payload=await body(req);return respond(res,200,processAction(url.pathname,role,payload));
  }
  if(req.method!=='GET'&&req.method!=='HEAD')return err(res,405,'Method not allowed');
  let requested=url.pathname==='/'?'/showcase.html':url.pathname==='/app'?'/app.html':url.pathname==='/split'?'/demo.html':url.pathname==='/phone'?'/phone.html':url.pathname;
  if(!path.extname(requested)&&requested!=='/'&&fs.existsSync(path.join(PUBLIC,requested+'.html')))requested+='.html';
  const full=path.resolve(PUBLIC,'.'+decodeURIComponent(requested));
  if(!full.startsWith(PUBLIC+path.sep))return err(res,403,'Forbidden');
  fs.readFile(full,(e,buf)=>{
   if(e)return err(res,404,'Page not found');res.writeHead(200,{'Content-Type':mime[path.extname(full)]||'application/octet-stream','X-Content-Type-Options':'nosniff','Cache-Control':'no-cache'});res.end(buf);
  });
 }catch(e){if(!res.headersSent)err(res,e.code||500,e.message||'Unexpected server error');}
});
server.listen(PORT,'0.0.0.0',()=>{
  const url='http://localhost:'+server.address().port+'/';
  console.log("Z’RES · Residence OS\n"+url+"\nKeep this window open during the demo.");
  if(process.platform==='win32' && process.env.ZRES_OPEN==='1'){
    require('node:child_process').execFile('rundll32.exe',['url.dll,FileProtocolHandler',url]);
  }
});
