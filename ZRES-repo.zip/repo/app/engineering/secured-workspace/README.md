# Open the demo

Double-click START-WINDOWS.bat. It opens your browser and displays the fictional student login in the terminal. Keep that window open. Type manager or another staff role in the terminal to display its sign-in details. Node.js 24.22.1+ is required. No manual file editing is needed.

See DEMO_EXPERIENCE.md for the latest navigation and phone improvements.

# Z’RES — Residence OS v2.2 development milestone

Blue-and-white operational workspace with a real local transactional backend. This is a fictional-data development build, not the completed v2.2 product or an approved live pilot.

## Run
Install Node.js 24.22.1 or newer with node:sqlite support. No npm packages are required.

```
npm run setup
npm start
```

Open http://127.0.0.1:4180. Setup generates fictional accounts in data/LOCAL-ACCOUNTS.json. Student: student@north.example.test. Use the generated password. For staff, use the appropriate email (for example manager@north.example.test) and run:
```
node tools/local-code.js manager@north.example.test
```
This local code helper is test tooling only. Never use generated credentials or fictional setup for real residents.

On Windows, START-WINDOWS.bat sets up an empty local database and starts the workspace. Run npm test for the security/workflow suite; npm run test:legacy for the preserved sales-demo suite.

Read RELEASE_READINESS.md and KNOWN_LIMITATIONS.md before any deployment. All 255 scope records remain in REQUIREMENTS_COVERAGE_MATRIX.md. The original marketing website/demo remains in public/ with server.js and seed.js; npm run demo:legacy starts that unauthenticated fictional demo separately. It is never served by the new default server.

The new app implements sessions, staff TOTP, scoped data access, atomic visitor registry, allocations and bookings, repair and confidential case stages, notices, optional check-ins, browser-encrypted private journal, and a limited operational report. Partial modules are explicitly tracked. No hardware unlocking, dispatch, monitored reflection, payment processing or live messages are enabled.

