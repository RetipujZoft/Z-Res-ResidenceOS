# Security and privacy
This build has security regression tests, not security certification or independent penetration-test evidence.

## Implemented controls
Scrypt salted password hashing (N=131072,r=8,p=1), minimum 15 characters; staff TOTP with time-window and replay checks; hashed opaque server sessions; HttpOnly/SameSite=Strict cookies; idle 30-minute and absolute 8-hour expiry; session rotation on login; deactivation revokes sessions. HTTPS origins set Secure cookies; local loopback HTTP does not provide transport encryption.

Tenant and property come from the authenticated account. Client role forgery is ignored. All record operations check access, with private journal/check-ins limited to their student owner and confidential support/sensitive incidents limited to the owner or assigned house parent. General management and security have no confidential-case access.

Strict input schemas, parameterized SQL, output escaping, restrictive self-only CSP, same-origin checks, CSRF tokens, body limits and in-memory rate limits protect the local API. Secrets and narrative fields are not intentionally included in structured request/error audit events.

## Journal
The browser derives an AES-GCM 256-bit key with PBKDF2-SHA256, 600,000 iterations and fresh 16-byte salt, then encrypts using a random 12-byte IV. A separate passphrase stays in the form and is not sent to the server. Only the encrypted envelope is accepted. This is non-monitored: no scanning, scoring, diagnosis or staff reading route. Export is encrypted; loss of passphrase means loss of decryptability. The browser crypto flow needs independent review; compromised served JavaScript or a compromised endpoint can defeat browser-side secrecy. Metadata remains visible to database operators.

Confidential support is a separate explicitly consented case. Monitored reflection is disabled. Check-in postponement/decline never changes essential-service authorization. Check-in answers are currently owner-only and not included in reports. Privacy-safe aggregates remain suppressed pending cohort/differencing review.

## Threats and unresolved controls
TOTP seeds are plaintext in the local database; the entire database is not encrypted. Synthetic setup uses one generated local password across its fictional accounts. The helper prints local staff OTPs. Neither mechanism is suitable for production.
No verified invitation, breached-password screening, password reset, WebAuthn, step-up or recovery workflow. Synchronous password hashing can block the event loop; distributed abuse controls and capacity/load testing are required.
Four visitor verification digits are a local demonstration check, not strong identity proof; their SHA-256 hash has low entropy. No access token/device unlock is implemented.
No private document uploads, virus scanning, retention engine, external immutable audit storage, key manager, encrypted recovery, lawful holds or approved POPIA operational processes.
App-level authorization is tested on selected paths, not proof of database-level tenant isolation. Audit triggers cannot stop a database administrator.
No real residents, medical narratives or identity documents should be used before release gates are closed.

## Verification references
[OWASP ASVS](https://asvs.owasp.org/) is the baseline for the outstanding security verification programme; this is not a complete ASVS assessment.
[OWASP Password Storage Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html) informs the scrypt configuration.
[Node SQLite documentation](https://nodejs.org/api/sqlite.html) describes the local driver; this project was exercised on Node 24.22.1.

## Operational response draft
On suspected compromise: stop exposed access, preserve encrypted evidence and logs with restricted access, revoke affected sessions, appoint an incident lead, determine scope, and route statutory/customer notifications through the operator's appointed privacy/legal personnel. Named responders, severity SLAs, notification contacts and a rehearsed procedure are not yet supplied or approved.

