CREATE TABLE IF NOT EXISTS schema_version (version INTEGER PRIMARY KEY);
INSERT OR IGNORE INTO schema_version VALUES (1);
CREATE TABLE IF NOT EXISTS properties (
 tenant TEXT NOT NULL, id TEXT NOT NULL, name TEXT NOT NULL,
 policy TEXT NOT NULL CHECK(json_valid(policy)), PRIMARY KEY(tenant,id)
);
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, tenant TEXT NOT NULL, property TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE, name TEXT NOT NULL, role TEXT NOT NULL,
 room TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1,
 password TEXT NOT NULL, totp TEXT, last_totp INTEGER NOT NULL DEFAULT -1,
 FOREIGN KEY(tenant,property) REFERENCES properties(tenant,id)
);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
 csrf TEXT NOT NULL, created INTEGER NOT NULL, seen INTEGER NOT NULL, expires INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS records (
 tenant TEXT NOT NULL, property TEXT NOT NULL, id TEXT NOT NULL,
 kind TEXT NOT NULL, owner TEXT NOT NULL REFERENCES users(id),
 created TEXT NOT NULL, updated TEXT NOT NULL, version INTEGER NOT NULL,
 data TEXT NOT NULL CHECK(json_valid(data)),
 PRIMARY KEY(tenant,property,id),
 FOREIGN KEY(tenant,property) REFERENCES properties(tenant,id)
);
CREATE INDEX IF NOT EXISTS records_scope ON records(tenant,property,kind,owner);
CREATE TABLE IF NOT EXISTS allocations (
 tenant TEXT NOT NULL, property TEXT NOT NULL, bed TEXT NOT NULL,
 resident TEXT NOT NULL REFERENCES users(id), begins INTEGER NOT NULL, ends INTEGER NOT NULL,
 CHECK(ends>begins), PRIMARY KEY(tenant,property,bed,begins),
 FOREIGN KEY(tenant,property) REFERENCES properties(tenant,id)
);
CREATE TRIGGER IF NOT EXISTS allocations_no_overlap BEFORE INSERT ON allocations
BEGIN
 SELECT RAISE(ABORT,'Allocation conflict') WHERE EXISTS (
 SELECT 1 FROM allocations WHERE tenant=NEW.tenant AND property=NEW.property
 AND (bed=NEW.bed OR resident=NEW.resident) AND begins<NEW.ends AND ends>NEW.begins);
END;
CREATE TABLE IF NOT EXISTS reservations (
 tenant TEXT NOT NULL, property TEXT NOT NULL, resource TEXT NOT NULL,
 begins INTEGER NOT NULL, ends INTEGER NOT NULL, owner TEXT NOT NULL REFERENCES users(id),
 id TEXT NOT NULL UNIQUE, CHECK(ends>begins),
 PRIMARY KEY(tenant,property,resource,begins),
 FOREIGN KEY(tenant,property) REFERENCES properties(tenant,id)
);
CREATE TRIGGER IF NOT EXISTS reservations_no_overlap BEFORE INSERT ON reservations
BEGIN
 SELECT RAISE(ABORT,'Booking conflict') WHERE EXISTS (
 SELECT 1 FROM reservations WHERE tenant=NEW.tenant AND property=NEW.property
 AND resource=NEW.resource AND begins<NEW.ends AND ends>NEW.begins);
END;
CREATE TABLE IF NOT EXISTS audit (
 sequence INTEGER PRIMARY KEY AUTOINCREMENT, tenant TEXT NOT NULL, property TEXT NOT NULL,
 event TEXT NOT NULL, previous TEXT NOT NULL, digest TEXT NOT NULL
);
CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit BEGIN SELECT RAISE(ABORT,'Append only audit'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit BEGIN SELECT RAISE(ABORT,'Append only audit'); END;
CREATE TABLE IF NOT EXISTS idempotency (
 user_id TEXT NOT NULL, key TEXT NOT NULL, fingerprint TEXT NOT NULL, response TEXT NOT NULL,
 PRIMARY KEY(user_id,key)
);

