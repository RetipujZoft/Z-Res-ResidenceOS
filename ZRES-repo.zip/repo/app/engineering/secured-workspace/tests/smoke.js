const {spawn}=require('child_process'),fs=require('fs'),os=require('os'),path=require('path'),assert=require('assert');
(async()=>{
 const original=path.resolve(__dirname,'..');const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'resos-test-'));
 fs.copyFileSync(path.join(original,'server.js'),path.join(tmp,'server.js'));fs.copyFileSync(path.join(original,'seed.js'),path.join(tmp,'seed.js'));fs.cpSync(path.join(original,'public'),path.join(tmp,'public'),{recursive:true});
 const port=43000+Math.floor(Math.random()*10000);const server=spawn(process.execPath,['server.js'],{cwd:tmp,env:{...process.env,PORT:String(port)},stdio:'ignore'});const base=`http://127.0.0.1:${port}`;
 const get=async p=>{let r=await fetch(base+p);assert.equal(r.status,200,p);return r.json()};
 const post=async(p,role,body)=>{let r=await fetch(base+p,{method:'POST',headers:{'content-type':'application/json','x-demo-role':role},body:JSON.stringify(body)});return {status:r.status,data:await r.json()}};
 try{
   let ready=false;for(let i=0;i<45;i++){try{await get('/api/health');ready=true;break}catch{await new Promise(r=>setTimeout(r,100))}}assert(ready,'Server failed to start');
   assert((await fetch(base+'/')).ok);assert((await fetch(base+'/app')).ok);
   let a=await post('/api/incidents','student',{category:'Medical',description:'Fictional test emergency',location:'Block B lobby'});assert.equal(a.status,200);
   let id=a.data.id;let staff=await get('/api/state?role=reception');assert(staff.incidents.some(x=>x.id===id));
   assert.equal((await post(`/api/incidents/${id}/status`,'reception',{status:'Acknowledged'})).status,200);
   let v=await post('/api/visitors','student',{name:'Test Visitor',idSuffix:'5678',photo:'data:image/png;base64,'+'a'.repeat(150),purpose:'Study',startAt:new Date(Date.now()-60000).toISOString(),endAt:new Date(Date.now()+3600000).toISOString()});assert.equal(v.status,200);
   const resident=await get('/api/state?role=student');let visitor=resident.visitors.find(x=>x.ref===v.data.visitor);assert(visitor);
   assert.equal((await post(`/api/visitors/${visitor.id}/approve`,'reception',{})).status,200);
   assert.equal((await post(`/api/visitors/${visitor.id}/entry`,'reception',{idSuffix:'5678'})).status,200);
   assert.equal((await post(`/api/visitors/${visitor.id}/entry`,'reception',{idSuffix:'5678'})).status,409);
   assert.equal((await post(`/api/visitors/${visitor.id}/checkout`,'reception',{idSuffix:'5678'})).status,200);
   assert.equal((await post(`/api/visitors/${visitor.id}/entry`,'reception',{idSuffix:'5678'})).status,409);
   let all=await get('/api/state?role=reception');assert.equal(all.visitors.find(x=>x.id===visitor.id).credential,null);
   let maintenance=await post('/api/maintenance','student',{title:'Broken tap',description:'Tap dripping continuously'});assert.equal(maintenance.status,200);
   assert.equal((await post(`/api/maintenance/${maintenance.data.id}/status`,'maintenance',{status:'In progress'})).status,200);
   const sv=await post('/api/incidents','student',{category:'Harassment',description:'x'});assert.equal((await post(`/api/incidents/${sv.data.id}/status`,'reception',{status:'Acknowledged'})).status,403);assert.equal((await post(`/api/incidents/${sv.data.id}/status`,'manager',{status:'Acknowledged'})).status,200);
   let v2=await post('/api/visitors','student',{name:'Mgr Visitor',idSuffix:'4321',photo:'data:image/png;base64,'+'a'.repeat(150),purpose:'Study',startAt:new Date(Date.now()-60000).toISOString(),endAt:new Date(Date.now()+3600000).toISOString()});const vv=(await get('/api/state?role=manager')).visitors.find(x=>x.ref===v2.data.visitor);
   assert.equal((await post(`/api/visitors/${vv.id}/approve`,'manager',{})).status,200);assert.equal((await post(`/api/visitors/${vv.id}/entry`,'manager',{idSuffix:'4321'})).status,200);assert.equal((await post(`/api/visitors/${vv.id}/checkout`,'manager',{idSuffix:'4321'})).status,200);
   assert.equal((await get('/api/state?role=security')).meta.mode,'DEMONSTRATION');
   console.log('PASS: routes, incident handoff, visitor approval, entry anti-passback, permanent checkout revocation, maintenance updates');
 }catch(e){console.error('FAIL:',e);process.exitCode=1}finally{const exited=new Promise(resolve=>server.once('exit',resolve));server.kill();await exited;fs.rmSync(tmp,{recursive:true,force:true})}
})();
