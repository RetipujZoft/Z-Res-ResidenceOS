'use strict';
const {test,before,after}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const {randomUUID}=require('node:crypto');
const {createServer}=require('../secure-server');
const {Store}=require('../lib/store');
const {setup}=require('../tools/setup-local');
const {totp,hash}=require('../lib/auth');
let app,base,directory,accounts;
const clients={};
const password='Fictional-test-password-22!';
async function client(role,tenant='north') {
 const id=role+'-'+tenant;
 if(clients[id])return clients[id];
 const account=accounts.find(a=>a.email===role+'@'+tenant+'.example.test');
 const response=await fetch(base+'/api/v1/login',{method:'POST',headers:{Origin:base,'Content-Type':'application/json'},body:JSON.stringify({email:account.email,password,...(account.totp?{otp:totp(account.totp)}:{})})});
 assert.equal(response.status,200,await response.clone().text());
 const {csrf}=await response.json();
 const cookie=response.headers.get('set-cookie').split(';')[0];
 const call=async(endpoint,body,headers={})=>{
  const options={headers:{Cookie:cookie,Origin:base,...headers}};
  if(body!==undefined){options.method='POST';Object.assign(options.headers,{'Content-Type':'application/json','X-CSRF-Token':csrf,'Idempotency-Key':randomUUID()},headers);options.body=JSON.stringify(body);}
  const r=await fetch(base+'/api/v1/'+endpoint,options);
  return {status:r.status,data:await r.json(),headers:r.headers};
 };
 return clients[id]={call,account,cookie,csrf};
}
before(async()=>{
 directory=fs.mkdtempSync(path.join(os.tmpdir(),'zres-v22-test-'));
 app=createServer({filename:path.join(directory,'test.sqlite')});
 accounts=setup(app.store,password);
 await new Promise(resolve=>app.server.listen(0,'127.0.0.1',resolve));
 base='http://127.0.0.1:'+app.server.address().port;
 // Create sessions before the per-IP login limit is exercised.
 for(const role of ['student','applicant','security','platform','reception','manager','houseparent','maintenance','owner','facilities','finance','securityadmin']) {
  // Test setup bypasses only the rate counter between distinct legitimate users.
  const account=accounts.find(a=>a.email===role+'@north.example.test');
  const token=randomUUID(),csrf=randomUUID();
  app.store.run('INSERT INTO sessions VALUES (?,?,?,?,?,?)',hash(token),account.id,csrf,Date.now(),Date.now(),Date.now()+3600000);
  const cookie='zres_session='+token;
  clients[role+'-north']={account,cookie,csrf,call:async(endpoint,body,headers={})=>{
   const options={headers:{Cookie:cookie,Origin:base,...headers}};
   if(body!==undefined){options.method='POST';Object.assign(options.headers,{'Content-Type':'application/json','X-CSRF-Token':csrf,'Idempotency-Key':randomUUID()},headers);options.body=JSON.stringify(body);}
   const r=await fetch(base+'/api/v1/'+endpoint,options);return {status:r.status,data:await r.json(),headers:r.headers};
  }};
 }
});
after(async()=>{
 await new Promise(resolve=>app.server.close(resolve));
 fs.rmSync(directory,{recursive:true,force:true,maxRetries:5,retryDelay:100});
});
test('unauthenticated access and role header cannot impersonate staff',async()=>{
 const r=await fetch(base+'/api/v1/records?kind=support',{headers:{'x-demo-role':'manager'}});
 assert.equal(r.status,401);
 const c=await client('student');
 assert.equal((await c.call('metrics',undefined,{'x-demo-role':'manager'})).status,403);
});
test('password login enforces staff MFA, TOTP replay and HttpOnly cookies',async()=>{
 const account=accounts.find(a=>a.email==='platform@north.example.test');
 const send=body=>fetch(base+'/api/v1/login',{method:'POST',headers:{Origin:base,'Content-Type':'application/json'},body:JSON.stringify(body)});
 assert.equal((await send({email:account.email,password})).status,401);
 const body={email:account.email,password,otp:totp(account.totp)};
 const valid=await send(body);assert.equal(valid.status,200);
 assert.match(valid.headers.get('set-cookie'),/HttpOnly/);assert.match(valid.headers.get('set-cookie'),/SameSite=Strict/);
 assert.equal((await send(body)).status,401);
});
test('malformed schema, CSRF, origin and payload ceiling reject writes',async()=>{
 const c=await client('student');
 const body={title:'Test fault',description:'Test description',category:'General'};
 assert.equal((await c.call('records/maintenance',body,{'X-CSRF-Token':'wrong'})).status,403);
 assert.equal((await c.call('records/maintenance',body,{Origin:'https://outside.invalid'})).status,403);
 assert.equal((await c.call('records/maintenance',{...body,tenant:'south'})).status,400);
 assert.equal((await c.call('records/maintenance',{...body,description:'x'.repeat(49000)})).status,413);
});
test('tenant and property IDs cannot reveal or mutate foreign records',async()=>{
 const north=await client('student');
 const south=await client('student','south');
 const result=await north.call('records/maintenance',{title:'North only',description:'Private fixture content',category:'General'});
 assert.equal(result.status,200);
 assert.ok(!(await south.call('records?kind=maintenance')).data.some(r=>r.id===result.data.id));
 assert.equal((await south.call('records/'+result.data.id+'/status',{status:'Reopened'})).status,404);
});
test('idempotency repeats return same record; changed body conflicts',async()=>{
 const c=await client('student'),key=randomUUID();
 const body={title:'Idempotent repair',description:'Repeated submission fixture',category:'General'};
 const a=await c.call('records/maintenance',body,{'Idempotency-Key':key});
 const b=await c.call('records/maintenance',body,{'Idempotency-Key':key});
 assert.equal(a.data.id,b.data.id);
 assert.equal((await c.call('records/maintenance',{...body,title:'Different'}, {'Idempotency-Key':key})).status,409);
});
async function visit() {
 const resident=await client('student'),staff=await client('reception');
 const result=await resident.call('records/visit',{name:'Fictional Guest',identity:'1234',startAt:new Date(Date.now()-1000).toISOString(),endAt:new Date(Date.now()+3600000).toISOString(),policyAccepted:true});
 assert.equal(result.status,200,JSON.stringify(result.data));
 assert.equal((await staff.call('records/'+result.data.id+'/approve',{})).status,200);
 return result.data.id;
}
test('visitor concurrency across gates grants exactly one admission and logs denial',async()=>{
 const id=await visit(),staff=await client('reception');
 const responses=await Promise.all(['Main gate','Side gate'].map(gate=>staff.call('records/'+id+'/entry',{identity:'1234',gate})));
 assert.deepEqual(responses.map(r=>r.status).sort(),[200,409]);
 const row=app.store.record(app.store.get('SELECT * FROM users WHERE id=?',staff.account.id),id);
 assert.equal(row.data.presence,'INSIDE');
 assert.ok(app.store.all("SELECT event FROM audit WHERE event LIKE '%denied-409%'").length);
 assert.equal((await staff.call('records/'+id+'/checkout',{identity:'1234',gate:'Main gate'})).status,200);
 assert.equal((await staff.call('records/'+id+'/entry',{identity:'1234',gate:'Side gate'})).status,409);
});
test('reference cannot verify identity; expired presence remains inside until supervised exit',async()=>{
 const id=await visit(),staff=await client('reception');
 assert.equal((await staff.call('records/'+id+'/entry',{identity:id,gate:'Main gate'})).status,400);
 assert.equal((await staff.call('records/'+id+'/entry',{identity:'9999',gate:'Main gate'})).status,403);
 assert.equal((await staff.call('records/'+id+'/entry',{identity:'1234',gate:'Other gate'})).status,403);
 assert.equal((await staff.call('records/'+id+'/entry',{identity:'1234',gate:'Main gate'})).status,200);
 const user=app.store.get('SELECT * FROM users WHERE id=?',staff.account.id);
 const row=app.store.record(user,id);
 app.store.update(user,row,{...row.data,endAt:new Date(Date.now()-1000).toISOString()});
 const visible=(await staff.call('records?kind=visit')).data.find(r=>r.id===id);
 assert.equal(visible.data.presence,'INSIDE');assert.equal(visible.data.overstay,true);assert.equal(visible.data.credentialState,'EXPIRED');
 assert.equal((await staff.call('records/'+id+'/entry',{identity:'1234',gate:'Side gate'})).status,409);
 assert.equal((await staff.call('records/'+id+'/checkout',{identity:'1234',gate:'Main gate'})).status,200);
});
test('medical and support narratives are unavailable to manager, reception and finance',async()=>{
 const student=await client('student'),care=await client('houseparent');
 const incident=await student.call('records/incident',{category:'Medical',description:'SENSITIVE MEDICAL FIXTURE',location:'Room B-204'});
 const support=await student.call('records/support',{subject:'Support fixture',message:'SENSITIVE SUPPORT FIXTURE',contact:'Residence inbox',consent:true});
 for(const role of ['manager','reception','finance']){
  const c=await client(role);
  assert.ok(!(await c.call('records?kind=incident')).data.some(r=>r.id===incident.data.id));
  assert.ok(!(await c.call('records?kind=support')).data.some(r=>r.id===support.data.id));
  assert.equal((await c.call('records/'+incident.data.id+'/status',{status:'Acknowledged'})).status,404);
 }
 assert.equal((await care.call('records/'+support.data.id+'/status',{status:'Acknowledged'})).status,200);
 assert.equal((await care.call('records/'+support.data.id+'/status',{status:'In progress',note:'Contact recorded'})).status,200);
 const resolved=await care.call('records/'+support.data.id+'/status',{status:'Resolved',note:'Follow-up completed by staff'});
 assert.equal(resolved.status,200);assert.ok(resolved.data.data.acknowledgedAt);assert.ok(resolved.data.data.closedAt);
 assert.ok(!JSON.stringify(app.store.all('SELECT event FROM audit')).includes('SENSITIVE'));
});
test('private notes contain ciphertext only, are excluded from staff reads and delete',async()=>{
 const student=await client('student');
 const result=await student.call('records/journal',{ciphertext:'YQ==',iv:'AAAAAAAAAAAAAAAA',salt:'AAAAAAAAAAAAAAAAAAAAAA==',format:'AES-GCM/PBKDF2-SHA256-v1'});
 assert.equal(result.status,200);
 for(const role of ['manager','houseparent','owner','securityadmin']){
  const c=await client(role);
  assert.equal((await c.call('records?kind=journal')).data.length,0);
  assert.equal((await c.call('records/'+result.data.id+'/delete',{})).status,404);
 }
 assert.equal((await student.call('records/'+result.data.id+'/delete',{})).status,200);
 assert.equal((await student.call('records?kind=journal')).data.length,0);
 assert.equal(app.store.get("SELECT count(*) AS n FROM idempotency WHERE json_extract(response,'$.id')=?",result.data.id).n,0);
});
test('all check-in choices leave visitor, incident, repair and support APIs available',async()=>{
 const c=await client('student');
 for(const decision of ['answered','declined','later']){
  assert.equal((await c.call('records/checkin',{decision})).status,200);
  assert.equal((await c.call('records/maintenance',{title:'Essential repair',description:'Unrestricted maintenance',category:'General'})).status,200);
  assert.equal((await c.call('records/incident',{category:'Noise',description:'Unrestricted routine report',location:'Corridor'})).status,200);
  assert.equal((await c.call('records/support',{subject:'Direct support',message:'Unrestricted support request',contact:'Email',consent:true})).status,200);
  assert.equal((await c.call('records?kind=visit')).status,200);
  assert.equal((await c.call('records?kind=resource')).status,200);
 }
 assert.equal((await c.call('monitored-reflection',{message:'test'})).status,503);
});
test('notice audience and explicit acknowledgement stay separate',async()=>{
 const manager=await client('manager'),student=await client('student');
 const invisible=await manager.call('records/notice',{title:'Other room',body:'Private room notice',audience:'B-206',requiresAck:true});
 assert.ok(!(await student.call('records?kind=notice')).data.some(r=>r.id===invisible.data.id));
 const visible=await manager.call('records/notice',{title:'Own room',body:'Notice fixture',audience:'B-204',requiresAck:true});
 const read=await student.call('records/'+visible.data.id+'/read',{});
 assert.equal(read.data.data.reads.length,1);assert.equal(read.data.data.acknowledgements.length,0);
 await student.call('records/'+visible.data.id+'/acknowledge',{});
 const duplicate=await student.call('records/'+visible.data.id+'/acknowledge',{});
 assert.equal(duplicate.data.data.acknowledgements.length,1);
});
test('concurrent facility bookings conflict; cancel releases space',async()=>{
 const student=await client('student');
 const facility=(await student.call('records?kind=facility')).data[0];
 const body={resource:facility.id,startAt:new Date(Date.now()+60000).toISOString(),endAt:new Date(Date.now()+3600000).toISOString()};
 const results=await Promise.all([student.call('records/booking',body),student.call('records/booking',body)]);
 assert.deepEqual(results.map(r=>r.status).sort(),[200,409]);
 assert.equal((await student.call('records/'+results.find(r=>r.status===200).data.id+'/cancel',{})).status,200);
 assert.equal((await student.call('records/booking',body)).status,200);
});
test('atomic bed allocations enforce both bed and resident interval exclusivity',async()=>{
 const manager=await client('manager'),student=await client('student');
 const beds=(await manager.call('records?kind=bed')).data;
 const body={bed:beds[0].id,resident:student.account.id,start:Date.now(),end:Date.now()+86400000};
 const results=await Promise.all([manager.call('allocate',body),manager.call('allocate',body)]);
 assert.deepEqual(results.map(r=>r.status).sort(),[200,409]);
 assert.equal((await manager.call('allocate',{...body,bed:beds[1].id})).status,409);
 const metrics=await manager.call('metrics?days=30');assert.equal(metrics.data.occupiedBeds,1);
 assert.equal(metrics.data.bedCount,3);assert.equal(metrics.data.wellbeingParticipation,null);
});
test('maintenance requires human stages and resolution evidence; own resident can reopen',async()=>{
 const student=await client('student'),tech=await client('maintenance');
 const ticket=await student.call('records/maintenance',{title:'Resolution fixture',description:'Track human actions',category:'General'});
 const id=ticket.data.id;
 assert.equal((await tech.call('records/'+id+'/status',{status:'Resolved',note:'Premature'})).status,409);
 await tech.call('records/'+id+'/status',{status:'In progress'});
 assert.equal((await tech.call('records/'+id+'/status',{status:'Resolved'})).status,400);
 assert.equal((await tech.call('records/'+id+'/status',{status:'Resolved',note:'Replaced fixture and tested'})).status,200);
 const report=await (await client('manager')).call('metrics?days=30');
 assert.equal(report.data.resolvedCount,1);assert.ok(report.data.medianResolutionHours>=0);
 assert.equal((await student.call('records/'+id+'/status',{status:'Reopened'})).status,200);
});
test('handover requires recipient acceptance and retains open work',async()=>{
 const reception=await client('reception'),manager=await client('manager');
 const result=await reception.call('records/handover',{to:manager.account.id,note:'Outstanding maintenance is still assigned.'});
 assert.equal(result.status,200);
 assert.equal((await reception.call('records/'+result.data.id+'/accept',{})).status,403);
 assert.equal((await manager.call('records/'+result.data.id+'/accept',{})).status,200);
 assert.ok((await manager.call('records?kind=maintenance')).data.length>0);
});
test('database audit forbids normal update/delete and durable records reopen correctly',()=>{
 assert.throws(()=>app.store.run("UPDATE audit SET digest='changed'"));
 assert.throws(()=>app.store.run('DELETE FROM audit'));
 const second=new Store(path.join(directory,'test.sqlite'));
 assert.ok(second.get('SELECT count(*) AS n FROM records').n>0);
 assert.equal(second.get('PRAGMA integrity_check').integrity_check,'ok');
 second.close();
});
test('applicant tracks own application and all provisioned roles have bounded access',async()=>{
 const applicant=await client('applicant');
 const result=await applicant.call('records/application',{roomType:'Shared',message:'Fictional application'});
 assert.equal(result.status,200);
 assert.ok((await applicant.call('records?kind=application')).data.some(r=>r.id===result.data.id));
 for(const role of ['student','applicant','reception','security','houseparent','maintenance','facilities','manager','owner','finance','platform','securityadmin']){
  const actor=await client(role);
  assert.equal((await actor.call('me')).status,200);
  assert.equal((await actor.call('metrics?days=7')).status,['manager','owner'].includes(role)?200:403);
  if(role!=='student')assert.equal((await actor.call('records?kind=journal')).data.length,0);
 }
});
test('offboarding revokes sessions; expired sessions and inactive membership rejected',async()=>{
 const owner=await client('owner'),finance=await client('finance');
 assert.equal((await owner.call('deactivate',{id:finance.account.id})).status,200);
 assert.equal((await finance.call('me')).status,401);
 const facilities=await client('facilities');
 app.store.run('UPDATE sessions SET expires=0 WHERE user_id=?',facilities.account.id);
 assert.equal((await facilities.call('me')).status,401);
});
test('login rate limiting is enforced and production startup is gated',async()=>{
 for(let i=0;i<12;i++)await fetch(base+'/api/v1/login',{method:'POST',headers:{Origin:base,'Content-Type':'application/json'},body:JSON.stringify({email:'unknown@example.test',password:'wrong-password-fixture'})});
 const r=await fetch(base+'/api/v1/login',{method:'POST',headers:{Origin:base,'Content-Type':'application/json'},body:'{}'});
 assert.equal(r.status,429);
 process.env.NODE_ENV='production';
 try{assert.throws(()=>createServer(),/Production release blocked/);}finally{delete process.env.NODE_ENV;}
});

