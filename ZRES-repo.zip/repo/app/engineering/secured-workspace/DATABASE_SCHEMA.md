# Database schema
Local schema: migrations/001.sql. Driver: Node built-in node:sqlite; WAL enabled, foreign keys enabled, busy timeout 5 seconds.

| Table | Purpose and principal constraints |
|---|---|
| schema_version | Current version 1; startup DDL is repeatable, not a complete migration runner |
| properties | Composite tenant/id primary key; JSON policy |
| users | Unique identity and email; property foreign key; role, room, active flag; password hash and local TOTP secret |
| sessions | Hashed opaque token primary key; user FK; CSRF, creation, last-seen and expiry |
| records | Composite tenant/property/id key; indexed scope/kind/owner; valid JSON payload and optimistic version |
| allocations | Effective-dated bed/resident assignment; insert trigger rejects intersecting bed or resident periods in a property |
| reservations | Effective-dated resource booking; insert trigger rejects overlapping bookings |
| audit | Append-only update/delete triggers; sequence and SHA-256 chain |
| idempotency | User/key composite key, request fingerprint and cached successful response |

Transactions encompass state mutation, audit append and idempotency storage. Concurrent requests run through an immediate write transaction. Database constraints are a second guard for interval conflicts.

Known schema gaps: no database RLS; owner FKs do not independently enforce same-tenant ownership; no interval-update trigger because no edit API exists; a direct SQL administrator can bypass the application controls or remove triggers; no external audit anchor; no payment ledger, document model, multi-property membership, outbox or lawful-retention model. Generic JSON records are suitable for this development milestone but domain-specific production tables and migrations are still required.

Deleted journal records and cached response envelopes are removed from active tables. SQLite WAL, freed pages and older backups may retain encrypted material; secure erasure and backup retention are not implemented.

