'use strict';
const fs=require('node:fs');
const path=require('node:path');
const {randomUUID,randomBytes}=require('node:crypto');
const {Store}=require('../lib/store');
const {passwordHash}=require('../lib/auth');
const roles=['student','applicant','reception','security','houseparent','maintenance','facilities','manager','owner','finance','platform','securityadmin'];
function setup(store, password) {
  if(store.get('SELECT count(*) AS n FROM users').n)throw new Error('The database already contains users. Use a fresh database path for a reset.');
  const accounts=[];
  const encoded=passwordHash(password);
  store.transaction(()=>{
    for(const tenant of ['north','south']) {
      const property='residence';
      store.run('INSERT INTO properties VALUES (?,?,?,?)',tenant,property,tenant==='north'?'Nova Heights':'Cedar House',JSON.stringify({version:1,maxVisitHours:24,maxVisits:3,gates:['Main gate','Side gate']}));
      for(const role of roles) {
        const id=randomUUID();
        const email=role+'@'+tenant+'.example.test';
        const totp=role==='student'||role==='applicant'?null:randomBytes(20).toString('hex');
        store.run('INSERT INTO users (id,tenant,property,email,name,role,room,password,totp) VALUES (?,?,?,?,?,?,?,?,?)',
          id,tenant,property,email,role==='student'?'Lerato Molefe':role,role,role==='student'?'B-204':'',encoded,totp);
        accounts.push({id,email,role,totp});
      }
      const owner=store.get("SELECT * FROM users WHERE tenant=? AND role='owner'",tenant);
      for(const room of ['B-204','B-205','B-206'])store.insert(owner,'bed',{name:room+' A',room,type:'Shared'});
      store.insert(owner,'facility',{name:'Study room',maxHours:4});
      store.insert(owner,'facility',{name:'Laundry bay',maxHours:2});
      store.insert(owner,'resource',{title:'How to request support',body:'Use the confidential support form to contact the assigned house parent. For urgent help, contact the on-site team or local emergency services directly. This local workspace does not dispatch responders.'});
      store.insert(owner,'transport',{title:'Transport timetable',body:'Ask residence staff for the approved timetable. GPS and live arrival predictions are unavailable.'});
    }
  });
  return accounts;
}
if(require.main===module) {
  const database=process.env.ZRES_DB||path.join(__dirname,'../data/local-v22.sqlite');
  const store=new Store(database);
  try {
    const password=randomBytes(18).toString('base64url');
    const accounts=setup(store,password);
    const destination=path.join(path.dirname(database),'LOCAL-ACCOUNTS.json');
    fs.writeFileSync(destination,JSON.stringify({environment:'FICTIONAL LOCAL DEVELOPMENT ONLY',password,accounts},null,2),{mode:0o600});
    console.log('Created fictional accounts. Credentials are in '+destination);
    console.log('Staff codes: node tools/local-code.js staff@north.example.test');
  } finally {store.close();}
}
module.exports={setup};

