'use strict';
const fs=require('node:fs'),path=require('node:path'),{randomBytes}=require('node:crypto'),{execFile}=require('node:child_process'),readline=require('node:readline');
const {createServer}=require('../secure-server'),{Store}=require('../lib/store'),{setup}=require('./setup-local'),{totp}=require('../lib/auth');
async function launch(){
 if(Number(process.versions.node.split('.')[0])<24)throw Error('Install Node.js 24.22.1 or newer, then try again.');
 const filename=process.env.ZRES_DB||path.join(__dirname,'../data/local-v22.sqlite');
 const accountFile=path.join(path.dirname(filename),'LOCAL-ACCOUNTS.json');
 if(!fs.existsSync(filename)){
  const store=new Store(filename);
  try{const password=randomBytes(18).toString('base64url');const accounts=setup(store,password);fs.writeFileSync(accountFile,JSON.stringify({environment:'FICTIONAL LOCAL DEVELOPMENT ONLY',password,accounts},null,2),{mode:0o600});}finally{store.close();}
 }
 const credentials=fs.existsSync(accountFile)?JSON.parse(fs.readFileSync(accountFile,'utf8')):null;
 const {server}=createServer({filename});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(Number(process.env.PORT||0),'127.0.0.1',resolve);});
 const url='http://127.0.0.1:'+server.address().port;
 if(process.argv.includes('--verify')){
  const response=await fetch(url);
  if(response.status!==200||!(await response.text()).includes('navigation.js'))throw Error('Launcher verification failed.');
  await new Promise(resolve=>server.close(resolve));console.log('Launcher verified: free port, workspace response, clean shutdown.');return;
 }
 console.log('\nZRES - YOUR DEMO IS READY\n\nOpen: '+url);
 if(credentials){
  console.log('\nSTUDENT SIGN-IN\nEmail: student@north.example.test\nPassword: '+credentials.password+'\nAuthenticator code: leave blank');
  console.log('\nFor staff sign-in details, type a role and press Enter:\nreception, security, houseparent, maintenance, facilities, manager, owner');
 }else console.log('\nUse your existing account. Local demo credentials were not found.');
 console.log('\nKeep this window open. Press Ctrl+C to stop. Fictional records only.\n');
 if(!process.argv.includes('--no-open')){
  const command=process.platform==='win32'?'rundll32':process.platform==='darwin'?'open':'xdg-open';
  execFile(command,process.platform==='win32'?['url.dll,FileProtocolHandler',url]:[url],error=>{if(error)console.log('Open the browser address above to continue.');});
 }
 const input=readline.createInterface({input:process.stdin,output:process.stdout});
 input.on('line',line=>{
  const account=credentials?.accounts.find(a=>a.role===line.trim().toLowerCase() && a.email.endsWith('@north.example.test'));
  if(!account){console.log('Choose a role listed above, or student.');return;}
  console.log('\nEmail: '+account.email+'\nPassword: '+credentials.password);
  console.log(account.totp?'Authenticator code: '+totp(account.totp)+' (changes every 30 seconds; type the role again for a fresh code)':'Authenticator code: leave blank');
 });
 process.once('SIGINT',()=>{input.close();server.close(()=>process.exit(0));});
}
launch().catch(error=>{console.error('Could not start the demo: '+error.message);process.exitCode=1;});

