'use strict';
const fs=require('node:fs');
const path=require('node:path');
const {totp}=require('../lib/auth');
const directory=path.dirname(process.env.ZRES_DB||path.join(__dirname,'../data/local-v22.sqlite'));
const credentials=JSON.parse(fs.readFileSync(path.join(directory,'LOCAL-ACCOUNTS.json')));
const account=credentials.accounts.find(a=>a.email===process.argv[2]);
if(!account?.totp)throw new Error('Choose a fictional staff account with an authenticator secret.');
console.log('Local test authenticator code: '+totp(account.totp));

