const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const rows=JSON.parse(fs.readFileSync(path.join(root,'requirements.json'),'utf8'));
const moduleNotes={
M01:'Tenant/property scoped accounts and records. Missing subscription lifecycle, tenant provisioning and multi-property membership.',
M02:'Atomic effective-date allocations and occupancy counts. Missing hierarchy administration, blocks, bed history UI and transfers.',
M03:'Password sessions, staff TOTP and offboarding. Missing invitations, verification, recovery, profile editing and membership dates.',
M04:'Saved student home and service links; desktop smoke checked. Missing complete self-service and low-data acceptance.',
M05:'Room/all audience, recipient snapshots, read versus human acknowledgement. Missing scheduler, cohort/floor targeting, delivery adapters and retries.',
M06:'Server-owned host/room, quotas, policy acceptance and date checks. Missing production identity proof and access-credential issuance.',
M07:'Transactional staff registry, anti-passback and permanent closure. Missing device tokens, reviewed overrides and real site validation.',
M08:'Routine/restricted routing and human status history. Missing escalation worker, coverage/backup and emergency drills.',
M09:'Consented assigned house-parent cases. Missing referrals, duty roster and backup escalation.',
M10:'Assigned repair stages, due dates and resolution evidence/reopen. Missing inventory, configurable SLA and procurement.',
M11:'Handover recipient acceptance and open work retention. Missing complete shifts, attendance and coverage.',
M12:'Limited canonical metrics. Missing full operational reporting and comparisons.',
M14:'Application submission, own tracking and manager decisions. Missing documents, admissions scoring/review and notifications.',
M15:'Atomic bed allocation. Missing complete placement offers and acceptance workflow.',
M17:'Targeted utility updates only. Missing metering, provider workflows and detailed outages.',
M18:'Transactional bookings, parcel intake/collection and lost reports. Missing capacity/policy administration and full lost-property workflow.',
M19:'Requests recorded; transfer approval blocked until atomic move workflow exists. Missing mediation and actual moves.',
M20:'Browser-encrypted private journal, optional weekly choices and separate support. Monitored mode disabled; full retention/privacy/referral acceptance missing.',
M21:'Event records and attendance. Missing polls and broader engagement.',
M24:'Approved-timetable placeholder only; no live GPS or route operations.',
M27:'Single-property selected-period report and JSON export. Missing portfolio comparisons and approvals.',
M31:'Responsive web workspace. Missing installable/offline PWA and low-data/device acceptance.',
M32:'Feedback API for resolved own repair. Missing complete UI/survey/quality reporting.'
};
const sec={
'SEC-001':'Scrypt and controlled synthetic provisioning; verified invitation, breached-password checks and recovery missing.',
'SEC-002':'Staff TOTP with replay check; phishing-resistant authentication and approved enrollment missing.',
'SEC-003':'Session rotation, HttpOnly/Strict, expiry and revocation tested; production TLS and privilege-change lifecycle outstanding.',
'SEC-005':'In-memory login/request rate limiting tested; distributed abuse controls and recovery endpoints missing.',
'SEC-006':'API role/case checks implemented; complete queue/file/export paths and full acceptance matrix absent.',
'SEC-007':'Server-owned tenant/property scopes tested on selected cross-tenant records; multi-property memberships missing.',
'SEC-008':'Scoped store queries and negative tests; database RLS/equivalent not complete.',
'SEC-009':'Assigned case restriction and manager/reception/finance denials tested; full case-role matrix pending.',
'SEC-013':'Passwords and sessions hashed, request logs redacted; local TOTP seeds remain plaintext.',
'SEC-014':'Registry reference cannot authorise physical access; secure device credential not implemented.',
'SEC-016':'Journal active-record/cache deletion and encrypted export; retention, lawful hold and secure physical deletion missing.',
'SEC-017':'Strict schemas, SQL parameters, escaping and CSP; exhaustive injection/XSS assessment pending.',
'SEC-018':'CSRF, exact origins and headers tested locally; production configuration review pending.',
'SEC-019':'Body and local rate ceilings; no WAF, distributed limits or monitoring.',
'SEC-021':'Mutation idempotency tested; no signed live webhooks or external integrations.',
'SEC-022':'Versioned local API inventory and generic errors; complete OpenAPI specification missing.',
'SEC-023':'Concurrent gate requests yield one entry in local transactional test; no hardware integration.',
'SEC-024':'Closed/expired registry entry denied in tests; no device credentials.',
'SEC-025':'Expired presence stays INSIDE and counts as overstay until staff checkout; tested.',
'SEC-026':'Hardware unlocking absent and release-gated; vendor/site approval unavailable.',
'SEC-027':'Dispatch disabled and clearly disclosed; responder contract/drill unavailable.',
'SEC-028':'Local append-only chained audit; external anchor, full coverage and independent review missing.',
'SEC-029':'Audit records identifiers/outcomes without narratives; exhaustive log review pending.',
'SEC-034':'Threat notes and regression criteria documented; independent review outstanding.',
'SEC-036':'Automated API/role/concurrency tests; load tests and ongoing vulnerability programme missing.',
'SEC-040':'Dated test and architecture evidence; independent findings, restore and client sign-off absent.'
};
const zw={
'ZW-001':'Ciphertext-only storage, owner-only reads and staff denial tested; browser crypto review pending.',
'ZW-002':'Separate journal/support disclosures rendered; user comprehension study missing.',
'ZW-003':'Later/decline/answer persist; postponement verified in browser. Residence-calendar scheduling incomplete.',
'ZW-004':'Backend tests preserve essential endpoints for every choice; browser later-to-repair passed. Complete E2E matrix pending.',
'ZW-005':'Assigned receipt, human acknowledgement and resolution; backup escalation missing.',
'ZW-006':'Disabled; trained reviewers, approved safeguarding and outage procedures unavailable.',
'ZW-007':'Houseparent assignment differs from managers/security; selected cross-role tests pass; independent penetration test missing.',
'ZW-008':'Active ciphertext and cached response deletion, encrypted export; retention/legal hold and backup lifecycle missing.',
'ZW-009':'Documented limited canonical measures; broader indicators and independent reconciliation missing.',
'ZW-010':'All wellbeing aggregates suppressed; privacy-safe aggregation/differencing implementation pending.',
'ZW-011':'No public operational metrics publisher; approval workflow missing.',
'ZW-012':'Student desktop and 390px smoke check; formal accessibility, devices and low-data tests pending.'
};
fs.copyFileSync(path.join(root,'REQUIREMENTS_COVERAGE_MATRIX.md'),path.join(root,'AUDIT_BASELINE_MATRIX.md'));
let out='# Requirements coverage matrix\n\n13 November 2026 · Master Scope v2.2 · 255 traceability records.\n\nBaseline is preserved in AUDIT_BASELINE_MATRIX.md. IDs M, SEC, R and ZW come from the supplied scope; SCOPE-B, ROLE and FLOW are local traceability IDs for prose. Status describes the WHOLE row, not merely a passing subtest. No whole module is marked complete. Prose rows remain acceptance work even where related code exists. No AGENTS.md was found in checked project/parent locations. See TEST_RESULTS.md for test names and precise evidence.\n\n| ID | Requirement | Priority | Existing implementation and remaining work | Source files | Required tests | Evidence | Status |\n|---|---|---|---|---|---|---|---|\n';
for(const row of rows){
 let note=moduleNotes[row.id]||sec[row.id]||zw[row.id];
 let status=note?'Partial':'Missing';
 if(['M25','M26','M29','ZW-006','SEC-026','SEC-027','SEC-037','SEC-039'].includes(row.id)){status='Blocked';note=note||'No live integration or approved independent/provider evidence. Release remains blocked.';}
 if(row.id.startsWith('ROLE-')){status=row.id==='ROLE-guardian'?'Missing':'Partial';note='Role retained in scope. Provisioned application roles have basic API permission coverage; complete role workflows and browser acceptance remain outstanding. Guardian access not implemented.';}
 if(!note)note='Original demo is not acceptance evidence. No independently completed implementation for this full requirement; see related module rows for partial shared functionality.';
 const files=status==='Missing'?'Master scope; KNOWN_LIMITATIONS.md':'secure-server.js; lib/auth.js; lib/service.js; lib/store.js; workspace/; tests/secure.test.js';
 const evidence=status==='Missing'||status==='Blocked'?'No full acceptance evidence':'Selected implementation/regression evidence in TEST_RESULTS.md; full acceptance outstanding';
 const cells=[row.id,row.description,row.priority,note,files,'Positive/negative roles, tenant/property, persistence, invalid input; concurrency and E2E where relevant',evidence,status];
 out+='| '+cells.map(x=>String(x||'P1').replaceAll('|','/').replaceAll('\n',' ')).join(' | ')+' |\n';
 row.status=status;row.implementation=note;
}
fs.writeFileSync(path.join(root,'REQUIREMENTS_COVERAGE_MATRIX.md'),out);
fs.writeFileSync(path.join(root,'requirements.json'),JSON.stringify(rows,null,2));
console.log('Updated '+rows.length+' scope records');

