/** Z'RES · RESIDENCE OS — SALES DEMO SERVER
 * No external packages. Demo-role switching is NOT authentication.
 * Never connect this code directly to real emergency dispatch or access hardware.
 */
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const {seed,uid}=require('./seed');
const PORT=Number(process.env.PORT||4173);
const DATA=path.join(__dirname,'data','demo-db.json');
const PUBLIC=path.join(__dirname,'public');
const {AsyncLocalStorage}=require('node:async_hooks');
const {explorer}=require('./explorer');
const tenancy=require('./tenancy');
const storage=new AsyncLocalStorage();
const sessions=new Map();
const current=()=>storage.getStore();
function session(req,res){
 const cookie=String(req.headers.cookie||'').match(/(?:^|; )zres_demo=([a-f0-9]{48})(?:;|$)/)?.[1];
 let entry=cookie&&sessions.get(cookie);
 if(!entry){
  for(const [key,value] of sessions)if(Date.now()-value.touched>8*3600000&&![...(value.spaces?.values()||[])].some(s=>s.listeners.size))sessions.delete(key);
  if(sessions.size>=100)throw Object.assign(new Error('Demo capacity reached. Try again later.'),{code:503});
  const token=crypto.randomBytes(24).toString('hex');entry={db:seed(),listeners:new Set(),touched:Date.now()};
  sessions.set(token,entry);res.setHeader('Set-Cookie','zres_demo='+token+'; HttpOnly; SameSite=Strict; Path=/');
 }
 entry.touched=Date.now();return tenancy.context(entry);
}
const roles=['student','reception','houseparent','manager','maintenance'];
const normRole=r=>r==='security'?'reception':r;
const staff=['reception','houseparent','manager','maintenance'];
const responders=['reception','houseparent','manager'];
const escape=s=>String(s||'').trim().slice(0,2500);
const now=()=>new Date().toISOString();
function save(label,role){current().db.meta.revision++;current().db.audit.unshift({id:uid('LOG'),label,actor:role,at:now()});current().db.audit=current().db.audit.slice(0,60);for(const r of [...current().listeners])try{r.write(`event: change\ndata: ${JSON.stringify({revision:current().db.meta.revision,label})}\n\n`)}catch(e){current().listeners.delete(r)}}
function respond(res,code,obj){res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(obj))}
function err(res,code,message){respond(res,code,{error:message})}
const stamp=(v)=>{const d=new Date(v);return Number.isFinite(d.getTime())?d.getTime():NaN};
function effective(v){if(v.state==='checkedout')return 'checkedout';if(v.state==='rejected')return 'rejected';if(v.state==='pending')return 'pending';if(Date.now()>stamp(v.endAt))return v.state==='inside'?'overstay':'expired';return v.state}
const sensitive=(i)=>Boolean(i.sensitive||['Harassment','Sexual misconduct','Wellbeing crisis','Medical','Roommate conflict'].includes(i.category));
function incidentPublic(i,role){if(sensitive(i)&&role!=='houseparent')return {...i,reporter:'Restricted',room:'Restricted',description:'Confidential details — visible only to the designated safeguarding team.',location:'Confidential location'};return i}
function overview(role){
 let obj=JSON.parse(JSON.stringify(current().db));
 obj.incidents=obj.incidents.map(i=>role==='student'&&i.reporter===current().db.resident.name?i:incidentPublic(i,role));
 if(!['student','houseparent'].includes(role))obj.supportRequests=[];
 obj.visitors=obj.visitors.filter(v=>role!=='student'||v.hostId===current().db.resident.id).map(v=>({...v,effectiveStatus:effective(v)}));
 if(role==='maintenance'){obj.incidents=[];obj.visitors=[];obj.messages=[];obj.supportRequests=[];obj.transfers=[];obj.applications=[];}
 if(role==='student'){obj.incidents=obj.incidents.filter(x=>x.reporter===current().db.resident.name);obj.audit=[];obj.applications=obj.applications.filter(x=>x.name===current().db.resident.name);obj.maintenance=obj.maintenance.filter(x=>x.reporter===current().db.resident.name||x.location===current().db.resident.room);obj.supportRequests=obj.supportRequests.filter(x=>x.residentId===current().db.resident.id);obj.transfers=obj.transfers.filter(x=>x.residentId===current().db.resident.id);obj.messages=obj.messages.filter(x=>x.residentId===current().db.resident.id);}
 obj.rooms=obj.rooms.map(r=>({...r,beds:r.beds.map(b=>({id:b.id,name:b.name,occupied:b.occupied}))}));
 obj.meta={...obj.meta,mode:'DEMONSTRATION',readOnlySafety:true};
 return obj;
}
function requiredRole(role,allowed){if(!allowed.includes(role))throw Object.assign(new Error('This action is not available to the selected demo role.'),{code:403})}
function assert(cond,msg,code=400){if(!cond)throw Object.assign(new Error(msg),{code})}
function field(x,min=1,max=250){return typeof x==='string'&&x.trim().length>=min&&x.trim().length<=max}
async function body(req){return new Promise((resolve,reject)=>{let size=0,str='';req.on('data',b=>{size+=b.length;if(size>2_800_000){reject(Object.assign(new Error('Upload exceeds the demo size limit.'),{code:413}));req.destroy();return;}str+=b});req.on('end',()=>{try{resolve(str?JSON.parse(str):{})}catch{reject(Object.assign(new Error('Invalid JSON'),{code:400}))}});req.on('error',reject)})}
const userName=role=>({student:current().db.resident.name,reception:'Reception',houseparent:'House Parent',manager:'Management',maintenance:'Maintenance Team'}[role]);
function processAction(url,role,b){let m,item;
 if(url==='/api/incidents'&&role==='student'){
  assert(field(b.category), 'Choose an incident category.');
  const allowed=['SOS / Immediate danger','Medical','Fire / smoke','Assault / threat','Harassment','Suspicious person','Noise next door','Corridor noise','Roommate conflict','Electrical danger','Other'];
  assert(allowed.includes(b.category),'Invalid incident category.');
  const critical=['SOS / Immediate danger','Medical','Fire / smoke','Assault / threat'].includes(b.category);
  const high=['Harassment','Suspicious person','Electrical danger'].includes(b.category);
  const assigned=['Harassment','Roommate conflict','Noise next door','Corridor noise'].includes(b.category)?'House Parents':'Reception';
  const incident={id:uid('INC'),category:b.category,priority:critical?'Critical':high?'High':'Routine',sensitive:b.category==='Harassment',location:escape(b.location||`Block ${current().db.resident.block} · Room ${current().db.resident.room}`),reporter:current().db.resident.name,room:current().db.resident.room,description:escape(b.description|| (critical?'Urgent assistance requested.':'Incident submitted by resident.')),status:'Awaiting acknowledgement',assignedTo:assigned,createdAt:now(),timeline:[{label:'Report received by residence system — awaiting staff acknowledgement',at:now()}]};
  current().db.incidents.unshift(incident);save(`${incident.category} incident submitted`,role);return {ok:true,id:incident.id};
 }
 if((m=url.match(/^\/api\/incidents\/([^/]+)\/status$/))){requiredRole(role,responders);item=current().db.incidents.find(x=>x.id===m[1]);assert(item,'Incident not found.',404);if(sensitive(item)&&role!=='houseparent')throw Object.assign(new Error('Restricted incident. Only designated House Parents can manage this record in the demo.'),{code:403});const allowed=['Acknowledged','In progress','Resolved'];assert(allowed.includes(b.status),'Invalid incident status.');assert(item.status!=='Resolved','This incident has already been resolved.');item.status=b.status;item.assignedTo=userName(role);if(b.status==='Acknowledged')item.acknowledgedAt=now();item.timeline.push({label:`${b.status} by ${userName(role)}`,at:now()});save(`Incident ${item.id}: ${b.status}`,role);return {ok:true};}
 if(url==='/api/visitors'&&role==='student'){
  assert(field(b.name,2,100),'Enter the visitor’s full name.');assert(/^\d{4}$/.test(String(b.idSuffix||'')),'Enter only the last four digits of the ID/passport for demo verification.');
  assert(typeof b.photo==='string'&&/^data:image\/(png|jpeg|webp);base64,/.test(b.photo)&&b.photo.length>100,'Visitor photograph is required (JPG, PNG or WebP).');
  assert(field(b.purpose,1,120),'Specify the reason for the visit.');
  const a=stamp(b.startAt),z=stamp(b.endAt);assert(Number.isFinite(a)&&Number.isFinite(z)&&z>a,'End time must be after start time.');assert(z>Date.now(),'Visit must end in the future.');assert(z-a<=24*3600*1000,'A visit cannot exceed 24 hours in this demo.');
  const v={id:uid('VIS'),ref:'VIS-'+Math.floor(100000+Math.random()*900000),hostId:current().db.resident.id,host:current().db.resident.name,room:current().db.resident.room,name:escape(b.name),idSuffix:b.idSuffix,photo:b.photo,purpose:escape(b.purpose),startAt:new Date(a).toISOString(),endAt:new Date(z).toISOString(),state:'pending',createdAt:now(),approvedAt:null,enteredAt:null,exitedAt:null,credential:null};
  current().db.visitors.unshift(v);save(`Visitor request submitted: ${v.name}`,role);return{ok:true,visitor:v.ref};
 }
 if((m=url.match(/^\/api\/visitors\/([^/]+)\/approve$/))){requiredRole(role,['reception','manager']);item=current().db.visitors.find(v=>v.id===m[1]);assert(item,'Visitor not found.',404);assert(item.state==='pending','Only pending visitors can be approved.');assert(Date.now()<stamp(item.endAt),'This visit has already expired.');item.state='approved';item.credential=uid('GATE')+'-'+crypto.randomBytes(6).toString('hex').toUpperCase();item.approvedAt=now();save(`Approved visitor: ${item.name}`,role);return{ok:true};}
 if((m=url.match(/^\/api\/visitors\/([^/]+)\/reject$/))){requiredRole(role,['reception','manager']);item=current().db.visitors.find(v=>v.id===m[1]);assert(item,'Visitor not found.',404);assert(item.state==='pending','Only pending requests can be declined.');item.state='rejected';save(`Visitor request declined: ${item.name}`,role);return{ok:true};}
 if((m=url.match(/^\/api\/visitors\/([^/]+)\/entry$/))){requiredRole(role,['reception','manager']);item=current().db.visitors.find(v=>v.id===m[1]);assert(item,'Visitor not found.',404);
  assert(String(b.idSuffix||'')===String(item.idSuffix),'ID verification does not match. Entry denied.',403);
  assert(item.state==='approved',item.state==='inside'?'DUPLICATE ENTRY DENIED — visitor already recorded inside.':'Credential revoked or not approved. New booking required.',409);
  assert(Date.now()>=stamp(item.startAt),'Visit has not yet started.',409);assert(Date.now()<stamp(item.endAt),'ACCESS EXPIRED — visit time ended.',409);
  item.state='inside';item.enteredAt=now();save(`Verified entry: ${item.name}`,role);return{ok:true,decision:'ENTRY GRANTED'};}
 if((m=url.match(/^\/api\/visitors\/([^/]+)\/checkout$/))){requiredRole(role,['reception','manager']);item=current().db.visitors.find(v=>v.id===m[1]);assert(item,'Visitor not found.',404);assert(item.state==='inside','Only a visitor recorded as inside can be signed out.',409);assert(String(b.idSuffix||'')===String(item.idSuffix),'ID verification does not match.',403);item.state='checkedout';item.exitedAt=now();item.credential=null;save(`Visitor signed out; credential permanently revoked: ${item.name}`,role);return{ok:true,decision:'CHECKOUT RECORDED — CREDENTIAL PERMANENTLY REVOKED'};}
 if(url==='/api/maintenance'&&role==='student'){
  assert(field(b.title,5,140),'Provide a maintenance issue title.');assert(field(b.description,8,1000),'Describe the issue.');
  const x={id:uid('MT'),title:escape(b.title),category:escape(b.category||'General'),location:current().db.resident.room,reporter:current().db.resident.name,description:escape(b.description),priority:escape(b.priority||'Medium'),status:'Open',assignee:'Unassigned',createdAt:now(),updates:[]};current().db.maintenance.unshift(x);save(`Maintenance submitted: ${x.title}`,role);return {ok:true,id:x.id};
 }
 if((m=url.match(/^\/api\/maintenance\/([^/]+)\/status$/))){requiredRole(role,['maintenance','manager','reception']);item=current().db.maintenance.find(x=>x.id===m[1]);assert(item,'Ticket not found.',404);assert(['Open','In progress','Resolved'].includes(b.status),'Invalid status.');item.status=b.status;item.assignee=userName(role);item.updates.push({text:`Status updated to ${b.status}${b.note?' — '+escape(b.note):''}`,at:now()});save(`Maintenance ${item.id}: ${b.status}`,role);return{ok:true};}
 if(url==='/api/announcements'){requiredRole(role,['manager','reception','houseparent']);assert(field(b.title,4,120),'Enter an announcement title.');assert(field(b.body,8,1200),'Enter the announcement message.');current().db.announcements.unshift({id:uid('ANN'),title:escape(b.title),body:escape(b.body),scope:escape(b.scope||'All residents'),level:escape(b.level||'General'),author:userName(role),createdAt:now(),reads:[]});save(`Announcement published: ${b.title}`,role);return {ok:true};}
 if((m=url.match(/^\/api\/announcements\/([^/]+)\/read$/))){requiredRole(role,['student']);item=current().db.announcements.find(x=>x.id===m[1]);assert(item,'Announcement not found.',404);if(!item.reads.includes(current().db.resident.id))item.reads.push(current().db.resident.id);save('Resident acknowledged notice',role);return{ok:true};}
 if(url==='/api/applications'&&role==='student'){
   assert(field(b.name,2,100),'Applicant name required.');assert(field(b.email,6,200)&&b.email.includes('@'),'Valid email required.');
   const selected=b.bedId?current().db.rooms.flatMap(x=>x.beds).find(z=>z.id===b.bedId):null;assert(!selected||!selected.occupied,'Selected bed is no longer available.',409);
   current().db.applications.unshift({id:uid('APP'),name:escape(b.name),email:escape(b.email),property:'Retipuj Residence',roomType:escape(b.roomType||'Shared'),bedId:b.bedId||null,status:'Pending review',funding:escape(b.funding||'Private'),submittedAt:now()});save(`New residence application: ${b.name}`,role);return{ok:true};
 }
 if((m=url.match(/^\/api\/applications\/([^/]+)\/status$/))){requiredRole(role,['manager','reception']);item=current().db.applications.find(x=>x.id===m[1]);assert(item,'Application not found.',404);assert(['Approved','Documents required','Declined'].includes(b.status),'Invalid application status.');if(b.status==='Approved'&&item.bedId){const bed=current().db.rooms.flatMap(r=>r.beds).find(x=>x.id===item.bedId);assert(bed&&!bed.occupied,'Requested bed has already been allocated.',409);bed.occupied=true;}item.status=b.status;save(`Application ${item.id}: ${b.status}`,role);return{ok:true};}
 if(url==='/api/facilities/book'&&role==='student'){
  assert(current().db.facilities.some(x=>x.id===b.facilityId),'Unknown facility.');assert(/^\d{4}-\d\d-\d\d$/.test(b.date),'Choose a date.');assert(['08:00','10:00','12:00','14:00','16:00','18:00','20:00'].includes(b.slot),'Invalid slot.');assert(!current().db.facilityBookings.some(x=>x.facilityId===b.facilityId&&x.date===b.date&&x.slot===b.slot),'This slot is already reserved.',409);current().db.facilityBookings.push({id:uid('FB'),facilityId:b.facilityId,date:b.date,slot:b.slot,residentId:current().db.resident.id});save('Facility booking created',role);return{ok:true};}
 if(url==='/api/transfers'&&role==='student'){assert(field(b.reason,8,1000),'Explain your transfer request.');current().db.transfers.unshift({id:uid('TR'),residentId:current().db.resident.id,room:current().db.resident.room,reason:escape(b.reason),preferredBlock:escape(b.preferredBlock||'Any'),status:'Pending review',createdAt:now()});save('Room transfer request submitted',role);return{ok:true};}
 if(url==='/api/support'&&role==='student'){assert(field(b.subject,4,120)&&field(b.message,8,1000),'Complete your confidential support request.');current().db.supportRequests.unshift({id:uid('SUP'),residentId:current().db.resident.id,subject:escape(b.subject),message:escape(b.message),status:'New',createdAt:now()});const care=explorer(current(),'POST',{module:'M09',action:'create',fields:{title:b.subject,note:b.message,appointment:'To arrange'}});care.linkedSupport=current().db.supportRequests[0].id;save('Confidential support request submitted',role);return{ok:true};}
 if(url==='/api/messages'){assert(field(b.message,1,1000),'Write a message.');current().db.messages.unshift({id:uid('MSG'),residentId:current().db.resident.id,sender:userName(role),senderRole:role,message:escape(b.message),createdAt:now()});save('Message sent to residence inbox',role);return{ok:true};}
 if((m=url.match(/^\/api\/shuttles\/([^/]+)\/update$/))){requiredRole(role,['manager','reception']);item=current().db.shuttles.find(x=>x.id===m[1]);assert(item,'Shuttle not found.',404);assert(['On route','Delayed','Scheduled','Arrived'].includes(b.status),'Invalid shuttle status');item.status=b.status;item.eta=Math.max(0,Math.min(120,Number(b.eta)||0));save('Shuttle status updated',role);return{ok:true};}
 if(url==='/api/reset'){requiredRole(role,['manager']);current().db=seed();current().explorer=null;save('Demo data reset',role);return{ok:true};}
 throw Object.assign(new Error('Action not found or unavailable to this role.'),{code:404});
}
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp','.ico':'image/x-icon','.json':'application/json; charset=utf-8','.webmanifest':'application/manifest+json','.jpg':'image/jpeg','.woff2':'font/woff2'};
const server=http.createServer((req,res)=>{
 let context;try{context=session(req,res)}catch(e){return err(res,e.code||500,e.message)}
 return storage.run(context,async()=>{
 try{
  const url=new URL(req.url,'http://localhost');
  const host=req.headers.host||'';
  if(!/^(localhost|127\.0\.0\.1)(:\d+)?$/.test(host))return err(res,403,'Local demo host required.');
  if(req.method==='POST'&&req.headers.origin&&req.headers.origin!=='http://'+host)return err(res,403,'Origin not allowed.');
  if(req.headers['x-residence-id']&&req.headers['x-residence-id']!==current().residenceId)return err(res,409,'Residence changed in another screen. Reload before continuing.');
  if(url.pathname.startsWith('/api/tenant')||url.pathname.startsWith('/api/owner')){
   const result=tenancy.handle(current(),url.pathname,req.method,req.method==='POST'?await body(req):{},req.headers['x-demo-role']||'student');
   if(result===undefined)return err(res,404,'Route not found.');return respond(res,200,result);
  }
  if(url.pathname==='/api/explorer'&&['GET','POST'].includes(req.method)){
   tenancy.studentGate(current());
   const data=explorer(current(),req.method,req.method==='POST'?await body(req):null);
   if(req.method==='POST')save('Feature explorer action','demo');
   return respond(res,200,data);
  }
  if(url.pathname==='/api/health')return respond(res,200,{ok:true,revision:current().db.meta.revision,mode:'demo',timestamp:now()});
  if(url.pathname==='/api/events'){
   res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive','X-Accel-Buffering':'no'});
   const streamContext=current();res.write('event: connected\ndata: {}\n\n');streamContext.listeners.add(res);req.on('close',()=>streamContext.listeners.delete(res));return;
  }
  if(url.pathname==='/api/state'&&req.method==='GET'){
    const rq=normRole(url.searchParams.get('role'));const role=roles.includes(rq)?rq:'student';if(role==='student')tenancy.studentGate(current());return respond(res,200,overview(role));
  }
  if(url.pathname.startsWith('/api/')&&req.method==='POST'){
   const rh=normRole(req.headers['x-demo-role']);const role=roles.includes(rh)?rh:'student';if(role==='student')tenancy.studentGate(current());let payload=await body(req);return respond(res,200,processAction(url.pathname,role,payload));
  }
  if(req.method!=='GET'&&req.method!=='HEAD')return err(res,405,'Method not allowed');
  let requested=url.pathname==='/demo'||url.pathname==='/split'?'/studio.html':url.pathname==='/'?'/showcase.html':url.pathname==='/app'?'/app.html':url.pathname==='/split'?'/demo.html':url.pathname==='/phone'?'/phone.html':url.pathname;
  if(!path.extname(requested)&&requested!=='/'&&fs.existsSync(path.join(PUBLIC,requested+'.html')))requested+='.html';
  const full=path.resolve(PUBLIC,'.'+decodeURIComponent(requested));
  if(!full.startsWith(PUBLIC+path.sep))return err(res,403,'Forbidden');
  fs.readFile(full,(e,buf)=>{
   if(e)return err(res,404,'Page not found');res.writeHead(200,{'Content-Type':mime[path.extname(full)]||'application/octet-stream','X-Content-Type-Options':'nosniff','Cache-Control':'no-cache'});res.end(buf);
  });
 }catch(e){if(!res.headersSent)err(res,e.code||500,e.message||'Unexpected server error');}
});
});
if(require.main===module)server.listen(PORT,'127.0.0.1',()=>{
 const url='http://127.0.0.1:'+server.address().port;
 console.log('\nZRES WEBSITE & COMPLETE DEMO\nOpen: '+url+'\nAll records are fictional. Each browser session has its own sandbox.\nKeep this window open.\n');
 console.log('ZRES owner console: '+url+'/owner\nOwner key (keep private): '+tenancy.ownerKey()+'\n');
 if(process.env.ZRES_OPEN==='1')require('node:child_process').execFile('rundll32',['url.dll,FileProtocolHandler',url],()=>{});
});
module.exports={server};
