# Residence onboarding and branding

Open the website and choose **Choose residence**. Urban Circle, Retipuj Residence and Campus House are illustrative demo entries. Their initials and colours are placeholders, not official branding.

## Student approval walkthrough

1. Choose a residence and open Student account.
2. Submit fictional name, email and student number. The server creates a pending account.
3. Student service APIs remain blocked while pending, rejected or suspended.
4. Open Management demo for the same residence. Confirm you checked the fictional student against residence records and approve.
5. Return to Student account and refresh. Residence services are now available.

Approval is scoped to the selected residence. Changing residence does not transfer approval. Management can decline with a reason, suspend an approved account, and approve again after review. The original sample resident remains available for browsing before you create a new account.

## Your Z’RES owner console

Open `/owner` on the same local website. The terminal launched by START-WINDOWS.bat prints its URL and a private owner key. Paste that key into the console. It changes after every restart. The key is not included in the ZIP or served to visitors.

Only an owner-unlocked session can create residences or edit their name, logo, initials and colour. Management demo headers do not grant owner access. Upload an approved PNG/JPEG/WebP logo under 290 KB, or use initials. Choose a dark brand colour for legible white text. The Z’RES marketing website remains blue and white.

Residence branding is saved in `data/residences.json` and survives local server restarts. To prepare a customised local ZIP for a demonstration, retain this branding file inside the app folder. Do not include any owner key or real personal information.

## Residence rules

Management demo publishes and edits versioned rules for students, staff, management or everyone. Students see their rules; Staff rules shows staff instructions; the management screen shows all of its residence’s rules. Existing rules can be edited with version checks to avoid overwriting a newer revision.

## Demo boundary

This change implements the interactive approval workflow in the sales sandbox, not production identity verification. Role switching deliberately allows a visitor to try management. Accounts, approvals, operational data and rules are separate per browser session and residence, in memory; they are not shared across people and reset when the server stops. There are no account passwords, email verification, student-document checks or staff invitations in this sales flow. Journal ciphertext is separated by residence in browser session storage.

The person controlling a downloaded server can control that copy. A distributed source ZIP cannot guarantee that only the original Z’RES owner can administer every independent copy. Central owner-only control requires hosted identity and role management, durable tenant-scoped storage, staff provisioning and production authorisation checks. Do not use this local demo with actual students or call it a live multi-residence service.
