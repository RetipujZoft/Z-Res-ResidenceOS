# Website and demo architecture
The main Node HTTP server serves the supplied multi-page website and restored resident/staff demo. A cryptographically random HttpOnly SameSite=Strict cookie selects a per-browser in-memory sandbox. AsyncLocalStorage scopes legacy demo reads/actions and SSE listeners to that sandbox. A sandbox reset replaces its fixture records and explorer state, not other sessions. Inactive sessions without listeners expire after eight hours; capacity is limited to 100 sessions.

Core APIs remain /api/state, /api/events, /api/incidents, /api/visitors, /api/maintenance and related demo actions. /api/explorer stores sample module records, validated status progress, history and optional check-in choices. public/catalog.json defines the 32 demo entries; public/scope.json retains 255 engineering requirement records.

The demo intentionally permits role selection for fictional exploration. This is separate from the previous authenticated SQLite backend, retained under engineering/secured-workspace in the ZIP. Never expose this demo as the real resident system.

The static service worker caches only its offline page, base styles and logo. It does not cache API data or queue emergency/access decisions. Browser journal encryption uses WebCrypto AES-GCM with PBKDF2-SHA256 (600,000 iterations), a fresh 16-byte salt and 12-byte IV; only ciphertext persists in sessionStorage.

No external provider calls are made by simulated feature actions. The Contact page prepares an email in the user's mail application; it does not silently send a message.

