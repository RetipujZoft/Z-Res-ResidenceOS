# Opening and sharing the demo
Extract the whole ZIP. Double-click START-WINDOWS.bat. It starts app/server.js with PORT=0 and opens the local website. A random available port avoids clashes with earlier versions. Keep its terminal open.

Node.js 24.22.1 or newer is required; no npm install is needed.
Mac/Linux: from app, run npm start and open the printed address.
No sign-in is required in the fictional sales demo. Choose scenarios and demo staff roles freely.

To share offline, send the ZIP. Each person runs their own local copy. A localhost URL from your computer is not a public link and will not open on someone else's phone. Public hosting requires separate preparation; this build intentionally binds 127.0.0.1.

The engineering/secured-workspace directory contains the previous authenticated local backend without databases or account credentials. Follow its README for that separate developer build.

