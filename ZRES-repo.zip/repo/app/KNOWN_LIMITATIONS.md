# Known limitations and release boundary
14 November 2026

This delivery is a website and broad interactive sales demonstration. The full v2.2 commercial system is NOT complete. All 32 modules have an exploration entry, but several are intentionally staged simulations rather than complete domain implementations.

Working demo operations: original resident-to-staff incident/SOS receipt and human acknowledgement, visitor approval/verification/anti-passback/checkout, repair status changes, notices, selected application/facility functions, isolated browser sandboxes, reset and scoped core demo views. The explorer stores fictional records and validates stage progress, stale revisions and selected bed/facility conflicts.

Simulations: finance and provider reconciliation; legally valid agreements/signatures; document uploads and eligibility verification; door/biometric adapters; real dispatch/escalation; GPS; notification delivery; operator subscription billing; verified identity enrollment; production support access; marketplace publication; portfolio publication approvals. Explorer workflows are deliberately labelled. Some explorer samples are separate records rather than deeply integrated domain models.

The explorer is an open sandbox for inspecting all roles. It is not an authenticated access-control boundary. Do not enter real confidential support, identity, financial or health information. The ordinary staff demo redacts sensitive core incident details, but selecting a demo role is not production authentication.
Private journal ciphertext stays in the current browser session; the passphrase is not transmitted. Browser compromise or malicious served JavaScript remains a threat. The crypto has not been independently reviewed.

Production blockers include managed database/RLS, identity verification/recovery/privileged access, TLS and at-rest encryption, secrets management, secure uploads/scanning, durable outbox and background processing, backup/restore, monitoring, formal privacy/safety procedures, independent penetration testing, accessibility/device testing and operator sign-off.
The prior authenticated development backend and its more detailed requirement matrix remain preserved in engineering/secured-workspace. They have not been replaced with the demo-role mechanism.

The static PWA shell has an explicit offline fallback. No offline action is sent, received or acknowledged while disconnected. Installability varies by browser and has not been certified on physical devices.
Browser QA covers selected desktop paths and earlier phone layouts, not every new screen/device. Public hosting has not been performed. Opening this ZIP starts a website on the local computer only.

# Multi-residence addition

The approval journey is a fictional session-scoped demo. A management role switch is not authentication. Accounts and rules are not durable or shared across separate browsers. Branding is stored in a local JSON catalogue. The local server owner key protects catalogue mutations from demo roles, but anyone controlling a distributed copy can administer that copy. Central Z’RES owner-only provisioning and real tenant isolation require a hosted authenticated implementation. Urban Circle and the other seeded branding are illustrative placeholders, not official assets.

