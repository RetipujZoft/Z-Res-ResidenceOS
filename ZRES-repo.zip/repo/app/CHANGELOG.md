# Changelog
## 14 November 2026 — Website and full-module demonstration
Restored the supplied multi-page website and original resident/staff demo presentation.
Restored prominent SOS, accessible alternative to holding, visitor passes, photo/ID checks, repair workflows and role-based demo desks.
Added a responsive walkthrough studio with SOS, visitor, repair, incident, wellbeing and accommodation scenarios.
Added grouped sample workflows for every M01–M32 module and searchable 255-record scope coverage.
Added optional check-in choices, browser-encrypted private journal, separately consented fictional support, and a synthetic monitored-review explanation.
Isolated browser sandbox state and reset. Corrected event-stream cleanup after browser navigation.
Linked new confidential support requests to the explorer care follow-up workflow.
Preserved the authenticated engineering implementation and documented remaining production gaps.

# Multi-residence demo update — 14 November 2026

Added owner-controlled residence catalogue, raster logo upload and accessible brand colours. Added pending student registration, per-residence approval/decline/suspension, scoped rules with revisions and audience filtering, isolated residence workspaces and stale-screen protection. Private journal ciphertext now uses a residence-specific browser key. Added four regression tests covering these flows. See RESIDENCE_SETUP.md for the distinction between the local demo and production multi-tenancy.

# Website and navigation redesign

Rebuilt the seven public website pages with shorter copy, three primary navigation choices, blue and pure-white styling and consistent Segoe UI/Arial typography. Replaced the homepage’s live embedded dashboards with a lightweight illustrative product view. The service library now opens with five categories, retains all 32 modules and moves scope/export tools under Demo details. The walkthrough displays one role at a time with a task selector. Residence-selection copy and spacing have been simplified; owner controls, student approvals and SOS remain available.

# Detailed portal design restored

Restored the detailed multi-residence website and demo at the user’s request. The public Webway login page was inspected as a visual reference: fixed icon rail, slim top account bar, white panels, subtle shadows and clear forms. Adapted these patterns to Z’RES blue and white without copying Webway assets or claiming access to its private dashboard. Mobile navigation becomes a bottom rail. All module demos, owner branding controls, verification and SOS remain present.

# Unified residence dashboard

Added /dashboard as the full demo entry point. Shows the selected residence’s actual sandbox occupancy, pending student approvals, incidents, repairs, visitors and notices. All 32 catalogue modules are visible together in grouped sections with search and direct workflow links. Added shortcuts to the resident app, management desk, approval/rules screens, owner console and connected walkthrough. Counters use existing APIs; no fabricated performance metrics were added. Production and integration limitations remain unchanged.

