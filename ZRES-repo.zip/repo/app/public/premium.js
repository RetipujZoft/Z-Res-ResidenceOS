/* Z'RES premium layer — behaviour only. No content is added to or removed from
   any page; this script adds motion, a command palette and a guided journey. */
(() => {
  'use strict';
  if (window.self !== window.top) return;            // never run inside the demo's phone / desk iframes
  const D = document, root = D.documentElement;
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fine = matchMedia('(hover:hover) and (pointer:fine)').matches;
  const $ = (s, r = D) => r.querySelector(s), $$ = (s, r = D) => [...r.querySelectorAll(s)];
  const store = { get(k) { try { return sessionStorage.getItem(k); } catch { return null; } }, set(k, v) { try { sessionStorage.setItem(k, v); } catch {} } };
  const path = location.pathname.replace(/\/$/, '') || '/';
  const el = (tag, cls, html) => { const n = D.createElement(tag); if (cls) n.className = cls; if (html != null) n.innerHTML = html; return n; };
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* ------------------------------------------------ 1. scroll progress, header state, back-to-top */
  const bar = el('div', 'pr-progress'); bar.setAttribute('aria-hidden', 'true');
  const topBtn = el('button', 'pr-top', '<svg viewBox="0 0 48 48" aria-hidden="true"><circle class="tr" cx="24" cy="24" r="21"/><circle class="pg" cx="24" cy="24" r="21"/></svg><b aria-hidden="true">↑</b>');
  topBtn.type = 'button'; topBtn.setAttribute('aria-label', 'Back to top');
  topBtn.onclick = () => scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
  let ticking = false;
  const onScroll = () => {
    ticking = false;
    const y = scrollY, h = Math.max(1, root.scrollHeight - innerHeight), p = Math.min(1, y / h);
    bar.style.transform = 'scaleX(' + p + ')';
    root.classList.toggle('is-scrolled', y > 8);
    topBtn.classList.toggle('show', y > 700);
    const pg = $('.pg', topBtn); if (pg) pg.style.strokeDashoffset = 132 - 132 * p;
  };
  addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } }, { passive: true });
  addEventListener('resize', onScroll, { passive: true });

  /* ------------------------------------------------ 2. hero headline word reveal (text unchanged) */
  const splitHeadline = () => {
    if (reduce) return;
    $$('h1.display').forEach(h => {
      if (h.dataset.prSplit || [...h.childNodes].some(n => n.nodeType !== 3)) return;
      const text = h.textContent.trim(); h.dataset.prSplit = '1'; h.setAttribute('aria-label', text);
      h.innerHTML = text.split(/\s+/).map((w, i) => '<span class="pr-w" aria-hidden="true" style="--i:' + i + '"><span>' + esc(w) + '</span></span>').join(' ');
    });
  };

  /* ------------------------------------------------ 3. scroll reveal (also catches re-rendered content) */
  const REVEAL = ['.sec-h', 'section.s>.c>.title', '.strip6', '.flow4>div', '.audrow', '.benefit-story', '.q', '.feature', '.box', '.residence-card', '.residence-panel',
    '.dash-card', '.dash-kpi', '.dash-hero', '.buyer-card', '.buyer-section>*', '.role-benefit-grid article', '.demo-bench', '.two>div', '.tips', '.intro',
    '.studio-title', '.studio-controls', '.module-head', '.feature-invitation', '.residence-tabs', '.sol', '.cta-band .c', '.band .c>*', '.stp', '#groups', '.explore-tools', '.zs-card', '.zs-tile', '.zs-col', '.zs-sech', '.zs-show .zs-wrap>*', '.zs-mini', '.zs-checks li'].join(',');
  let io = null;
  const reveal = () => {
    if (reduce || !('IntersectionObserver' in window)) return;
    if (!io) io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('pr-in'); io.unobserve(e.target); } }), { rootMargin: '0px 0px -8% 0px', threshold: .08 });
    const fresh = $$(REVEAL).filter(n => !n.classList.contains('pr-rv') && !n.closest('.hero,.pr-cmd,.portal-rail,.portal-top,header.site') && !n.closest('.pr-rv'));
    fresh.forEach((n, i) => {
      const sib = n.parentElement ? [...n.parentElement.children].indexOf(n) : i;
      n.style.setProperty('--d', Math.min(sib % 6, 5) * 70 + 'ms');
      n.classList.add('pr-rv');
    });
    if (fresh.length) { void root.offsetWidth; fresh.forEach(n => io.observe(n)); }
  };

  /* ------------------------------------------------ 4. count-up for dashboard numbers */
  const countUp = () => {
    if (reduce) return;
    $$('.dash-kpi .v:not([data-pr-n])').forEach(n => {
      n.dataset.prN = '1';
      const src = n.textContent;
      if (!/\d/.test(src)) return;
      const t0 = performance.now(), dur = 1100;
      const step = t => {
        const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 4);
        n.textContent = src.replace(/\d+/g, m => String(Math.round(+m * e)));
        if (k < 1) requestAnimationFrame(step); else n.textContent = src;
      };
      requestAnimationFrame(step);
    });
  };

  /* ------------------------------------------------ 5. pointer effects: spotlight, ripple, hero tilt */
  const SPOT = '.dash-card,.dash-kpi,.feature,.box,.residence-card,.flow4>div,.buyer-card,.dashboard-shortcuts>a,.strip6 div';
  let spotRaf = 0, last = null;
  if (fine && !reduce) {
    D.addEventListener('pointermove', e => {
      last = e; if (spotRaf) return;
      spotRaf = requestAnimationFrame(() => {
        spotRaf = 0; const t = last.target.closest && last.target.closest(SPOT);
        if (t) { const r = t.getBoundingClientRect(); t.style.setProperty('--mx', last.clientX - r.left + 'px'); t.style.setProperty('--my', last.clientY - r.top + 'px'); }
        const hero = last.target.closest && last.target.closest('.hero');
        const lap = $('.hero .laptop'), ph = $('.hero .phone-sm');
        if (hero && lap) {
          const r = hero.getBoundingClientRect(), x = (last.clientX - r.left) / r.width - .5, y = (last.clientY - r.top) / r.height - .5;
          lap.style.transform = 'rotateY(' + (x * 7).toFixed(2) + 'deg) rotateX(' + (-y * 5).toFixed(2) + 'deg)';
          if (ph) ph.style.transform = 'translate3d(' + (x * -18).toFixed(1) + 'px,' + (y * -10).toFixed(1) + 'px,0)';
        }
      });
    }, { passive: true });
    D.addEventListener('pointerleave', () => { const lap = $('.hero .laptop'), ph = $('.hero .phone-sm'); if (lap) lap.style.transform = ''; if (ph) ph.style.transform = ''; });
  }
  D.addEventListener('pointerdown', e => {
    if (reduce) return;
    const b = e.target.closest && e.target.closest('.btn,.pbtn,.sos-shortcut'); if (!b) return;
    const r = b.getBoundingClientRect(), s = Math.max(r.width, r.height) * 2.2, sp = el('span', 'pr-ripple');
    sp.style.cssText = 'width:' + s + 'px;height:' + s + 'px;left:' + (e.clientX - r.left - s / 2) + 'px;top:' + (e.clientY - r.top - s / 2) + 'px';
    b.appendChild(sp); setTimeout(() => sp.remove(), 750);
  }, { passive: true });

  /* ------------------------------------------------ 6. command palette (Ctrl/⌘ + K  or  /) */
  const PAGES = [
    ['Home', 'Website overview', '/', 'Ho'], ['Resident app', 'Services, safety and requests', '/phone', 'Ph'], ['Management dashboard', 'Occupancy, workload, rules and branding', '/dashboard', 'Db'], ['Live walkthrough', 'Resident phone and staff desk, live together', '/demo', 'Lv'], ['All features', 'Browse every module', '/explore', 'Ft'],
    ['Accounts and access', 'How residence accounts work (information)', '/residences', 'Ac'],
    ['Student accounts', 'How students join (information)', '/residences?view=student', 'St'], ['Management approval', 'How approval works (information)', '/residences?view=management', 'Mg'],
    ['Resident app', 'The student phone experience', '/phone', 'Ph'], ['Staff desk', 'Reception, house parents and maintenance', '/app', 'Dk'],
    ['Product overview', 'What Z’RES does', '/product', 'Pr'], ['Solutions by role', 'Benefits for every role', '/solutions', 'So'], ['Security and privacy', 'How data is protected', '/security', 'Se'],
    ['Pilot programme', 'How a pilot works', '/pilot', 'Pi'], ['About', 'About Retipuj Zoft', '/about', 'Ab'], ['Contact and support', 'Request a pilot', '/contact', 'Ct']
  ].map(([t, s, u, ic]) => ({ t, s, u, ic, k: 'Pages' }));
  let items = PAGES.slice(), catalogLoaded = false, cmd, input, list, sel = 0, shown = [], opener = null;
  const loadCatalog = () => {
    if (catalogLoaded) return; catalogLoaded = true;
    fetch('/catalog.json').then(r => r.json()).then(c => {
      items = PAGES.concat(c.map(m => ({ t: m.title, s: m.group + ' · ' + m.description, u: '/explore#' + m.id, ic: m.id.replace('M', ''), k: 'Features' })));
      if (cmd && cmd.classList.contains('open')) render();
    }).catch(() => {});
  };
  const score = (it, q) => {
    if (!q) return 1;
    const t = it.t.toLowerCase(), s = it.s.toLowerCase(); let sc = 0;
    for (const w of q.toLowerCase().split(/\s+/).filter(Boolean)) {
      if (t.startsWith(w)) sc += 6; else if (t.includes(' ' + w)) sc += 4; else if (t.includes(w)) sc += 3; else if (s.includes(w)) sc += 1; else return 0;
    }
    return sc;
  };
  const hl = (txt, q) => { let h = esc(txt); q.split(/\s+/).filter(Boolean).forEach(w => { h = h.replace(new RegExp('(' + w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'ig'), '<mark>$1</mark>'); }); return h; };
  const render = () => {
    const q = input.value.trim();
    shown = items.map(it => [it, score(it, q)]).filter(x => x[1] > 0).sort((a, b) => b[1] - a[1]).map(x => x[0]).slice(0, q ? 24 : 30);
    if (!q) shown = shown.filter(i => i.k === 'Pages' || shown.indexOf(i) < 24);
    sel = Math.min(sel, Math.max(0, shown.length - 1));
    let html = '', cur = '';
    shown.forEach((it, i) => {
      if (it.k !== cur) { cur = it.k; html += '<div class="pr-cmd-h" role="presentation">' + cur + '</div>'; }
      html += '<a class="pr-cmd-i' + (i === sel ? ' sel' : '') + '" role="option" id="pr-o' + i + '" data-i="' + i + '" href="' + esc(it.u) + '"><span class="ic">' + esc(it.ic) + '</span><span><b>' + hl(it.t, q) + '</b><small>' + hl(it.s, q) + '</small></span><span class="go" aria-hidden="true">↵</span></a>';
    });
    list.innerHTML = html || '<div class="pr-cmd-empty">Nothing matches “' + esc(q) + '”. Try a role, a module or a page name.</div>';
    input.setAttribute('aria-activedescendant', shown.length ? 'pr-o' + sel : '');
  };
  const move = d => {
    if (!shown.length) return; sel = (sel + d + shown.length) % shown.length;
    $$('.pr-cmd-i', list).forEach((n, i) => n.classList.toggle('sel', i === sel));
    const n = $('#pr-o' + sel, list); if (n) n.scrollIntoView({ block: 'nearest' }); input.setAttribute('aria-activedescendant', 'pr-o' + sel);
  };
  const go = i => { const it = shown[i]; if (!it) return; closeCmd(true); if (it.u.startsWith('/explore#') && path === '/explore') { location.hash = it.u.split('#')[1]; } else location.href = it.u; };
  const buildCmd = () => {
    cmd = el('div', 'pr-cmd', '<div class="pr-cmd-bg"></div><div class="pr-cmd-box" role="dialog" aria-modal="true" aria-label="Jump to any page or feature"><div class="pr-cmd-in"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><input type="text" role="combobox" aria-expanded="true" aria-controls="pr-list" autocomplete="off" spellcheck="false" placeholder="Jump to a page, module or workspace…" aria-label="Search"><kbd>esc</kbd></div><div class="pr-cmd-list" id="pr-list" role="listbox"></div><div class="pr-cmd-ft"><span><kbd>↑</kbd><kbd>↓</kbd>navigate</span><span><kbd>↵</kbd>open</span><span><kbd>esc</kbd>close</span></div></div>');
    input = $('input', cmd); input.classList.add('pr-ci'); list = $('.pr-cmd-list', cmd); D.body.appendChild(cmd);
    $('.pr-cmd-bg', cmd).onclick = () => closeCmd();
    input.oninput = () => { sel = 0; render(); };
    list.onclick = e => { const a = e.target.closest('.pr-cmd-i'); if (a) { e.preventDefault(); go(+a.dataset.i); } };
    list.onpointermove = e => { const a = e.target.closest('.pr-cmd-i'); if (a && +a.dataset.i !== sel) { sel = +a.dataset.i; $$('.pr-cmd-i', list).forEach((n, i) => n.classList.toggle('sel', i === sel)); } };
    cmd.onkeydown = e => {
      if (e.key === 'ArrowDown') { e.preventDefault(); move(1); } else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1); }
      else if (e.key === 'Enter') { e.preventDefault(); go(sel); } else if (e.key === 'Escape') { e.preventDefault(); closeCmd(); }
      else if (e.key === 'Tab') { e.preventDefault(); input.focus(); }
    };
  };
  const openCmd = () => {
    if (!cmd) buildCmd(); loadCatalog(); opener = D.activeElement; input.value = ''; sel = 0; render();
    cmd.classList.add('open'); root.style.overflow = 'hidden'; input.focus();
  };
  const closeCmd = skipFocus => { if (!cmd) return; cmd.classList.remove('open'); root.style.overflow = ''; if (!skipFocus && opener && opener.focus) opener.focus(); };
  D.addEventListener('keydown', e => {
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) || e.target.isContentEditable;
    if ((e.key === 'k' || e.key === 'K') && (e.metaKey || e.ctrlKey)) { e.preventDefault(); cmd && cmd.classList.contains('open') ? closeCmd() : openCmd(); }
    else if (e.key === '/' && !typing && !e.metaKey && !e.ctrlKey) { e.preventDefault(); openCmd(); }
  });
  const injectKbd = () => {
    if ($('.pr-kbtn')) return;
    const host = $('.portal-top>div') || $('header.site .hr'); if (!host) return;
    const b = el('button', 'pr-kbtn', '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><span>Jump to…</span><kbd>' + (/Mac|iPhone|iPad/.test(navigator.platform) ? '⌘K' : 'Ctrl K') + '</kbd>');
    b.type = 'button'; b.setAttribute('aria-label', 'Open quick navigation'); b.onclick = openCmd; host.insertBefore(b, host.firstChild);
  };

  /* ------------------------------------------------ 7. guided journey (logical workflow) */
  const STEPS = [['/', 'Website', 'Meet the platform'], ['/demo', 'Live walkthrough', 'Act as resident, watch the desk'], ['/explore', 'All features', 'Try any of the 32 modules'], ['/residences', 'Accounts and access', 'How it works, for information'], ['/pilot', 'Pilot', 'How a pilot works'], ['/contact', 'Request a pilot', 'Start the conversation']];
  const MAP = { '/': 0, '/product': 0, '/solutions': 0, '/demo': 1, '/phone': 1, '/app': 1, '/studio': 1, '/explore': 2, '/residences': 3, '/security': 4, '/pilot': 4, '/about': 4, '/contact': 5 };
  const journey = () => {
    if (!(path in MAP) || store.get('pr-j-off') === '1') return;
    const i = MAP[path], last = i === STEPS.length - 1, nx = STEPS[last ? 0 : i + 1];
    const j = el('div', 'pr-journey', '<div class="pr-j-dots" aria-hidden="true">' + STEPS.map((_, k) => '<i class="' + (k < i ? 'done' : k === i ? 'cur' : '') + '"></i>').join('') + '</div><div class="pr-j-txt">' + STEPS[i][1] + '<small>Step ' + (i + 1) + ' of ' + STEPS.length + '</small></div><a class="pr-j-next" href="' + nx[0] + '">' + (last ? 'Back to start' : 'Next: ' + nx[1]) + ' <span aria-hidden="true">→</span></a><button class="pr-j-x" type="button" aria-label="Hide guided tour">×</button>');
    j.setAttribute('role', 'region'); j.setAttribute('aria-label', 'Guided tour'); D.body.appendChild(j);
    $('.pr-j-x', j).onclick = () => { j.classList.remove('show'); store.set('pr-j-off', '1'); };
    setTimeout(() => j.classList.add('show'), reduce ? 0 : 1600);
    // tuck away near the footer so it never covers closing content
    const f = $('footer'); if (f && 'IntersectionObserver' in window) new IntersectionObserver(es => es.forEach(e => j.classList.toggle('min', e.isIntersecting)), { threshold: .15 }).observe(f);
  };

  /* ------------------------------------------------ boot */
  const mo = new MutationObserver(() => { if (mo.t) return; mo.t = requestAnimationFrame(() => { mo.t = 0; reveal(); countUp(); injectKbd(); }); });
  const boot = () => {
    D.body.append(bar, topBtn);
    reveal(); countUp(); injectKbd(); onScroll();
    mo.observe(D.body, { childList: true, subtree: true });
    setTimeout(() => { injectKbd(); reveal(); }, 400);   // portal.js builds the header just after load
  };
  D.readyState === 'loading' ? D.addEventListener('DOMContentLoaded', boot) : boot();
})();
