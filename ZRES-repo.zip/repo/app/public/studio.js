'use strict';
const scenarios={
sos:{label:'SOS',phone:'/phone?embed=1&tab=safety',staff:'/app?embed=1&page=incidents',role:'reception',guide:'Hold SOS on the phone, or use the accessible tap option. Then acknowledge the alert at the reception desk. No real emergency service is contacted.'},
visitors:{label:'Visitors',phone:'/phone?embed=1&tab=visitors',staff:'/app?embed=1&page=visitors',role:'reception',guide:'Invite a visitor using the sample photo and four ID digits. Approve at reception, verify entry, sign out, then try re-entry.'},
repairs:{label:'Repairs',phone:'/phone?embed=1&tab=repairs',staff:'/app?embed=1&page=repairs',role:'maintenance',guide:'Submit a repair on the phone. Start work and mark it fixed at the maintenance desk; watch the resident status update.'},
incidents:{label:'Incidents',phone:'/phone?embed=1&tab=safety',staff:'/app?embed=1&page=incidents',role:'reception',guide:'Report a routine incident and follow acknowledgement and resolution. Confidential categories are restricted to the demo care view.'},
wellbeing:{label:'Wellbeing',phone:'/explore#M20',staff:'/explore#M09',role:'houseparent',guide:'Explore private journaling, optional check-ins and a separate confidential request. Monitored-mode review uses a fixed synthetic scenario.'},
accommodation:{label:'Accommodation',phone:'/explore#M14',staff:'/explore#M15',role:'manager',guide:'Walk through an application, sample document request and room placement. Continue to agreements and move-in in the feature explorer.'},
services:{label:'All services',phone:'/explore',staff:'/explore',role:'manager',guide:'Browse every scope module. Explore its sample workflow, record transitions and remaining production requirements.'}
};
let chosen=new URLSearchParams(location.search).get('scenario')||'sos';if(!scenarios[chosen])chosen='sos';
const $=id=>document.getElementById(id);
function show(){const s=scenarios[chosen];$('role').value=s.role;$('resident').src=s.phone;$('staff').src=s.staff+(s.staff.includes('/app')?'&role='+s.role:'');$('phone-link').href=s.phone.replace('embed=1&','');$('staff-link').href=$('staff').src;$('scenario-tag').textContent=s.label+' walkthrough';$('scenario-guide').textContent=s.guide;document.querySelectorAll('[data-scenario]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.scenario===chosen)));}
$('scenarios').innerHTML=Object.entries(scenarios).map(([k,s])=>'<button data-scenario="'+k+'" aria-pressed="false">'+s.label+'</button>').join('');
$('scenarios').onclick=e=>{const b=e.target.closest('[data-scenario]');if(b){chosen=b.dataset.scenario;show();}};
$('role').onchange=()=>{const s=scenarios[chosen];$('staff').src=s.staff.includes('/app')?s.staff+'&role='+$('role').value:'/explore';$('staff-link').href=$('staff').src;};
document.querySelector('.screen-switch').onclick=e=>{const b=e.target.closest('[data-screen]');if(!b)return;document.body.classList.toggle('show-staff',b.dataset.screen==='staff');document.querySelectorAll('[data-screen]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));};
$('reset').onclick=async()=>{if(!confirm('Reset the records in your own demo sandbox? Private browser journal notes are not affected.'))return;const r=await fetch('/api/reset',{method:'POST',headers:{'Content-Type':'application/json','x-demo-role':'manager'},body:'{}'});$('studio-status').textContent=r.ok?'Your sandbox was reset. Other browser sessions are unchanged.':'Reset failed. Please try again.';if(r.ok)show();};
show();
