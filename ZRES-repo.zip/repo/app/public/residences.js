'use strict';
const el=id=>document.getElementById(id),safe=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let state,view=new URLSearchParams(location.search).get('view')||'choose',editing=null;
async function request(url,body,role='student'){const headers={'Content-Type':'application/json','x-demo-role':role};if(state)headers['x-residence-id']=state.selected.id;const r=await fetch(url,{headers,...(body?{method:'POST',body:JSON.stringify(body)}:{})});const data=await r.json();if(!r.ok)throw Error(data.error);return data;}
function say(s){el('feedback').textContent=s;}
function mark(r){return r.logo?'<img src="'+safe(r.logo)+'" alt="'+safe(r.name)+' logo">':'<span class="residence-monogram">'+safe(r.initials)+'</span>';}
async function render(){
 state=await request('/api/tenant',null,'student');
 document.querySelectorAll('[data-view]').forEach(a=>a.setAttribute('aria-current',a.dataset.view===view?'page':'false'));
 const box=el('residence-content'),r=state.selected;
 const steps=(list)=>'<ol class="info-steps">'+list.map(([t,d],i)=>'<li><b>'+(i+1)+'</b><div><h3>'+safe(t)+'</h3><p>'+safe(d)+'</p></div></li>').join('')+'</ol>';
 if(view==='choose'){
  box.innerHTML='<div class="residence-grid"><article class="residence-card" style="--residence-color:'+safe(r.color)+'">'+mark(r)+'<h2>'+safe(r.name)+'</h2><p>Each residence has its own name, colours, services, students, staff and rules. Nothing is shared between residences.</p><a class="btn" href="/phone">Experience the resident app</a></article></div>';return;
 }
 if(view==='student'){
  box.innerHTML='<div class="residence-columns"><section class="residence-panel"><h2>Student accounts</h2><p>In the live product, a student requests an account at their residence. The account stays pending until residence management has checked it against the residence records.</p>'+steps([['Request','The student submits their name, email and student number.'],['Verify','Residence management checks the request against its own records.'],['Access','Once approved, the student opens the resident app and every service.']])+'</section><aside class="residence-panel"><h2>In this demo</h2><p>You are exploring as a verified resident of '+safe(r.name)+'. There is nothing to sign up for. Open the resident app to feel the experience.</p><div class="residence-actions"><a class="btn" href="/phone">Open the resident app</a><a class="btn ln" href="/explore">Explore services</a></div></aside></div>';return;
 }
 if(view==='management'){
  box.innerHTML='<div class="residence-columns"><section class="residence-panel"><h2>Approval by management</h2><p>Only the residence team sees and decides on requests for its own residence.</p>'+steps([['Review','Requests for this residence only appear on the management desk.'],['Decide','Approve, decline or suspend, with a note and a history.'],['Publish rules','Instructions can be published for students, staff, management or everyone.']])+'</section><aside class="residence-panel"><h2>Residence rules</h2><p>Rules are written by management and shown to the right audience at the right residence.</p><div class="residence-actions"><a class="btn ln" href="?view=rules">See student rules</a><a class="btn ln" href="?view=staff">See staff rules</a></div></aside></div>';return;
 }
 box.innerHTML='<h2>'+safe(r.name)+' rules</h2><p>Published rules for '+(view==='staff'?'staff':'students')+' and everyone at your residence.</p><div id="rule-list"></div>';rulesList(false);
}
function rulesList(manage){el('rule-list').innerHTML=state.rules.filter(r=>[view==='staff'?'staff':'students','everyone'].includes(r.audience)).map(r=>'<article class="residence-panel"><small>'+safe(r.audience)+' · Version '+r.version+'</small><h2>'+safe(r.title)+'</h2><p class="rule-body">'+safe(r.body)+'</p></article>').join('')||'<p>No rules have been published for this audience in the demo. In the live product, management publishes them here.</p>';}
async function run(fn){try{await fn();}catch(e){say(e.message);}}
window.residenceReady.then(()=>run(render));
