(()=>{
 const original=window.fetch.bind(window);
 window.residenceReady=original('/api/tenant').then(r=>r.json()).then(data=>{
  const p=data.selected;try{const b=JSON.parse(localStorage.getItem('zres-brand:'+p.id)||'null');if(b){if(b.name)p.name=b.name;if(b.color)p.color=b.color;if(b.logo)p.logo=b.logo;p.initials=(b.name||p.name).split(/\s+/).map(w=>w[0]).join('').slice(0,2).toUpperCase();}}catch{}p.illustrative=false;window.residenceContext=data;
  (()=>{const m=/^#([0-9a-f]{6})$/i.exec(p.color||'');if(!m)return;const n=parseInt(m[1],16),r=n>>16,g=n>>8&255,b=n&255,R=document.documentElement.style,al=x=>'rgba('+r+','+g+','+b+','+x+')',dk=x=>Math.round(x*.72);R.setProperty('--pr-blue',p.color);R.setProperty('--pr-blue-d','rgb('+dk(r)+','+dk(g)+','+dk(b)+')');['08','12','20','35'].forEach(k=>R.setProperty('--pr-blue-a'+k,al(+k/100)));})();document.documentElement.style.setProperty('--cobalt',p.color);document.documentElement.style.setProperty('--cobalt-d',p.color);document.documentElement.style.setProperty('--residence-color',p.color);
  const mount=()=>{
   const bar=document.createElement('aside');bar.className='residence-bar';
   const mark=document.createElement(p.logo?'img':'span');if(p.logo){mark.src=p.logo;mark.alt=p.name+' logo';}else{mark.textContent=p.initials;mark.className='residence-monogram';}
   const name=document.createElement('strong');name.textContent=p.name;
      bar.append(mark,name);document.body.prepend(bar);
   
  };if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();return data;
 });
 window.fetch=async(input,options={})=>{
  const url=typeof input==='string'?input:input.url;
  if(url.startsWith('/api/')&&!url.startsWith('/api/tenant')&&!url.startsWith('/api/owner')){
   const data=await window.residenceReady;const headers=new Headers(options.headers);headers.set('x-residence-id',data.selected.id);
   return original(input,{...options,headers});
  }return original(input,options);
 };
})();
