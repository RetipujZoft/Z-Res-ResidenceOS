(()=>{'use strict';
const $=id=>document.getElementById(id);
/* persona switch */
const W={resident:{h:'Everything about residence life, <em>in one app.</em>',p:'Ask for help, invite a visitor, report a repair, book a facility and read every notice. Reception sees each request the moment you send it.',go:['/phone','Open the resident app'],lap:'/app?role=reception&embed=1&page=desk'},
 staff:{h:'A desk that puts <em>the urgent first.</em>',p:'Reception, house parents and maintenance get a live queue, one-tap actions and a workspace for every service they handle. Every change is timed and attributed.',go:['/app','Open the staff desk'],lap:'/app?role=reception&embed=1&page=desk'},
 manager:{h:'The whole residence, <em>at a glance.</em>',p:'Occupancy, workload, finance, compliance and performance in one dashboard. Load your own logo, colours and house rules, and publish them to everyone.',go:['/dashboard','Open the dashboard'],lap:'/dashboard?embed=1'}};
let cur='resident',timer,touched=false;
function set(k,auto){if(k===cur)return;cur=k;const c=$('zs-copy');c.classList.add('out');setTimeout(()=>{const d=W[k];$('zs-h').innerHTML=d.h;$('zs-p').textContent=d.p;$('zs-go').href=d.go[0];$('zs-go').textContent=d.go[1];const f=$('zs-lap');if(f.getAttribute('src')!==d.lap)f.src=d.lap;c.classList.remove('out');},280);
 document.querySelectorAll('[data-who]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.who===k)));}
document.querySelectorAll('[data-who]').forEach(b=>b.onclick=()=>{touched=true;clearInterval(timer);set(b.dataset.who)});
const order=['resident','staff','manager'];timer=setInterval(()=>{if(touched||document.hidden)return;set(order[(order.indexOf(cur)+1)%3],true)},7000);
/* scale iframes inside cards */
function fit(){document.querySelectorAll('.zs-card .scr').forEach(s=>{const w=+s.dataset.fit,f=s.querySelector('iframe');if(!f||!s.clientWidth)return;const k=s.clientWidth/w;f.style.width=w+'px';f.style.height=(s.clientHeight/k)+'px';f.style.transform='scale('+k+')';});}
addEventListener('load',fit);addEventListener('resize',fit);setTimeout(fit,300);
/* feature map from the live catalog */
fetch('/catalog.json').then(r=>r.json()).then(cat=>{
 const P={phone:[],desk:[],dashboard:[]};
 const PLACE={M01:['d'],M02:['d'],M03:['d'],M04:['p'],M05:['k','d'],M06:['p'],M07:['k'],M08:['p','k'],M09:['p','k'],M10:['p','k'],M11:['k'],M12:['d'],M13:['p'],M14:['p'],M15:['d','k'],M16:['d'],M17:['p','k'],M18:['p'],M19:['p','k'],M20:['p'],M21:['p'],M22:['d'],M23:['d'],M24:['p','k'],M25:['p','k'],M26:['k'],M27:['d'],M28:['d'],M29:['d'],M30:['d'],M31:['p'],M32:['p','d']};
 const roleFor={M05:'reception',M07:'reception',M08:'houseparent',M09:'houseparent',M10:'maintenance',M11:'reception',M15:'manager',M17:'maintenance',M19:'houseparent',M24:'reception',M25:'reception',M26:'reception'};
 cat.forEach(m=>(PLACE[m.id]||[]).forEach(p=>{const t=p==='p'?'phone':p==='k'?'desk':'dashboard';P[t].push(m)}));
 const link=(m,t)=>'<a href="'+(t==='phone'?'/phone?module='+m.id:t==='desk'?'/app?role='+roleFor[m.id]+'&module='+m.id:'/dashboard?module='+m.id)+'">'+m.title+'</a>';
 const cols=document.querySelectorAll('#zs-map .zs-col');[['phone','Services that live in your pocket'],['desk','Work done at the desk'],['dashboard','Run and measure the residence']].forEach(([t,sub],i)=>{const c=cols[i];c.querySelector('h3').insertAdjacentHTML('beforeend','<span class="zs-count">'+P[t].length+'</span>');c.insertAdjacentHTML('beforeend','<small>'+sub+'</small>'+P[t].map(m=>link(m,t)).join(''));});
}).catch(()=>{});
})();
