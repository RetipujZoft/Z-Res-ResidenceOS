(()=>{
'use strict';
let open=document.getElementById('sos-open'),dialog=document.getElementById('sos-dialog');
if(!dialog){
 dialog=document.createElement('dialog');dialog.id='sos-dialog';
 dialog.innerHTML='<h2>SOS demonstration</h2><p>This alert goes only to your fictional reception desk. No real staff or emergency services are contacted.</p><label for="sos-location">Fictional location<input id="sos-location" value="Block B · Room B-204"></label><button id="sos-hold" class="sos-hold">Hold for 1 second</button><button id="sos-send" class="btn wide">Send demo alert instead</button><button id="sos-close" class="btn ln wide">Cancel</button><p id="sos-result" role="status"></p>';
 document.body.append(dialog);
}
if(!open){open=document.createElement('button');open.id='sos-open';open.className='sos-shortcut sos-float';open.textContent='SOS demo';document.body.append(open);}
open.onclick=()=>{document.getElementById('sos-result').textContent='';dialog.showModal();};
document.getElementById('sos-close').onclick=()=>dialog.close();
let busy=false,timer;
const hold=document.getElementById('sos-hold'),send=document.getElementById('sos-send');
function stop(){clearTimeout(timer);hold.classList.remove('holding');}
async function submit(){
 stop();if(busy)return;busy=true;hold.disabled=send.disabled=true;
 try{
  const r=await fetch('/api/incidents',{method:'POST',headers:{'Content-Type':'application/json','x-demo-role':'student'},body:JSON.stringify({category:'SOS / Immediate danger',location:document.getElementById('sos-location').value,description:'Fictional SOS demonstration. No real emergency.'})});
  const j=await r.json();if(!r.ok)throw Error(j.error);
  document.getElementById('sos-result').textContent='Demo SOS received. Awaiting a human action in the fictional reception desk. Reference '+j.id+'. No emergency services contacted.';
 }catch(e){document.getElementById('sos-result').textContent='Not received: '+e.message;}
 finally{busy=false;hold.disabled=send.disabled=false;}
}
hold.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();stop();hold.classList.add('holding');timer=setTimeout(submit,1100);});
['pointerup','pointerleave','pointercancel'].forEach(event=>hold.addEventListener(event,stop));
hold.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();submit();}});
dialog.addEventListener('close',stop);send.onclick=submit;
})();
