/* Z'RES module runtime — every one of the 32 product modules, mounted where it belongs:
   resident app, staff desk (by role) or management dashboard. */
(() => {
  'use strict';
  const esc = x => String(x ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* where each module lives */
  const PLACE = {
    M01: ['dashboard'], M02: ['dashboard'], M03: ['dashboard'], M04: ['phone'], M05: ['desk:reception', 'desk:manager', 'dashboard'], M06: ['phone'],
    M07: ['desk:reception'], M08: ['phone', 'desk:houseparent', 'desk:manager'], M09: ['phone', 'desk:houseparent'], M10: ['phone', 'desk:maintenance', 'desk:manager'],
    M11: ['desk:reception'], M12: ['dashboard'], M13: ['phone'], M14: ['phone'], M15: ['dashboard', 'desk:manager'], M16: ['dashboard'], M17: ['phone', 'desk:maintenance', 'desk:reception'],
    M18: ['phone'], M19: ['phone', 'desk:houseparent'], M20: ['phone'], M21: ['phone'], M22: ['dashboard'], M23: ['dashboard'], M24: ['phone', 'desk:reception'],
    M25: ['phone', 'desk:reception', 'desk:manager'], M26: ['desk:reception'], M27: ['dashboard'], M28: ['dashboard'], M29: ['dashboard'], M30: ['dashboard'],
    M31: ['phone'], M32: ['phone', 'dashboard']
  };
  const ICON = { M01: 'building', M02: 'bed', M03: 'user-group', M04: 'house', M05: 'bullhorn', M06: 'user-plus', M07: 'id-card', M08: 'triangle-exclamation', M09: 'heart', M10: 'wrench', M11: 'clipboard-list', M12: 'chart-line', M13: 'magnifying-glass', M14: 'file-lines', M15: 'key', M16: 'file-signature', M17: 'bolt', M18: 'calendar-check', M19: 'users', M20: 'bed-pulse', M21: 'calendar-days', M22: 'wallet', M23: 'clipboard-check', M24: 'bus-simple', M25: 'shield', M26: 'door-open', M27: 'chart-pie', M28: 'circle-question', M29: 'gears', M30: 'suitcase', M31: 'mobile-screen-button', M32: 'star' };
  const WHERE = { phone: 'Resident app', desk: 'Staff desk', dashboard: 'Management dashboard' };
  const ROLE_NAME = { reception: 'Reception', houseparent: 'House parent', maintenance: 'Maintenance', manager: 'Management' };

  let data = null, scope = null, wbTab = 'choices';
  const toastFn = { f: m => {} };
  async function api(body) {
    const r = await fetch('/api/explorer', body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {});
    const j = await r.json(); if (!r.ok) throw Error(j.error || 'Could not save.'); return j;
  }
  async function ensure() {
    if (!data) { [data, scope] = await Promise.all([api(), fetch('/scope.json').then(r => r.json()).catch(() => [])]); }
    return data;
  }
  const refresh = async () => { data = await api(); return data; };
  const list = (place, role) => (data?.catalog || []).filter(m => (PLACE[m.id] || []).includes(role ? place + ':' + role : place));
  const placesOf = id => (PLACE[id] || []).map(p => p.split(':')[0]).filter((v, i, a) => a.indexOf(v) === i);
  const ic = n => '<svg class="zm-i" aria-hidden="true"><use href="/assets/icons.svg#i-' + n + '"/></svg>';

  /* cards for a set of modules */
  function grid(host, mods, onOpen, opts = {}) {
    host.innerHTML = '<div class="zm-grid' + (opts.compact ? ' zm-compact' : '') + '">' + mods.map(m => {
      const done = data.records.filter(r => r.module === m.id).length;
      return '<button type="button" class="zm-card" data-zm="' + m.id + '"><span class="zm-ico">' + ic(ICON[m.id] || 'gear') + '</span><span class="zm-txt"><small>' + esc(m.group) + '</small><b>' + esc(m.title) + '</b>' + (opts.compact ? '' : '<em>' + esc(m.description) + '</em>') + '</span>' + (done ? '<span class="zm-count">' + done + '</span>' : '') + '<span class="zm-go" aria-hidden="true">' + ic('chevron-right') + '</span></button>';
    }).join('') + '</div>';
    host.onclick = e => { const b = e.target.closest('[data-zm]'); if (b) onOpen(b.dataset.zm); };
  }

  /* sample values: the demo runs prefilled examples, nobody has to type */
  function sample(f) { const k = f.key; return k === 'date' ? new Date().toISOString().slice(0, 10) : k === 'amount' ? '1250.00' : k === 'rating' ? '4' : k === 'capacity' ? '2' : k === 'note' ? 'Example note shown for demonstration.' : 'Example ' + String(f.label || k).toLowerCase(); }
  function field(f) {
    const type = f.key === 'date' ? 'date' : ['amount', 'rating', 'capacity'].includes(f.key) ? 'number' : 'text';
    return '<label>' + esc(f.label) + (f.key === 'note' ? '<textarea name="note" readonly>' + esc(sample(f)) + '</textarea>' : '<input name="' + f.key + '" type="' + type + '" value="' + esc(sample(f)) + '" readonly>') + '</label>';
  }
  function steps(m, cur, cancelled) {
    return '<ol class="zm-steps">' + m.stages.map((s, i) => '<li class="' + (cancelled ? '' : i < cur ? 'done' : i === cur ? 'now' : '') + '"><i>' + (i < cur && !cancelled ? ic('check') : i + 1) + '</i><span>' + esc(s) + '</span></li>').join('') + '</ol>';
  }
  function record(r, m) {
    return '<article class="zm-rec"><header><b>' + esc(r.data.title) + '</b><span class="zm-pill">' + esc(r.status) + '</span></header>' + steps(m, r.stage, r.cancelled) +
      Object.entries(r.data).filter(([k, v]) => k !== 'title' && v).map(([k, v]) => '<p><strong>' + esc(m.fields.find(f => f.key === k)?.label || k) + '</strong> ' + esc(v) + '</p>').join('') +
      (!r.cancelled && r.stage < m.stages.length - 1 ? '<div class="zm-actions"><button class="zm-btn" data-act="advance" data-id="' + r.id + '" data-stage="' + r.stage + '">' + esc(m.stages[r.stage + 1]) + ' →</button><button class="zm-btn ln" data-act="cancel" data-id="' + r.id + '">Cancel</button></div>' : '') +
      '<details><summary>History</summary><ol class="zm-time">' + r.history.map(h => '<li>' + esc(h.status) + ' · ' + esc(h.actor) + ' · ' + new Date(h.at).toLocaleString() + '</li>').join('') + '</ol></details></article>';
  }

  /* one module, rendered into host */
  async function mount(host, id, opts = {}) {
    await ensure(); const m = data.catalog.find(x => x.id === id); if (!m) { host.innerHTML = '<p class="zm-empty">Feature not found.</p>'; return; }
    const sc = scope.find(x => x.id === id);
    const where = placesOf(id).map(p => WHERE[p]).join(' · ');
    const draw = () => {
      const recs = data.records.filter(r => r.module === id);
      host.innerHTML = '<div class="zm' + (opts.compact ? ' zm-compact' : '') + '">' +
        '<header class="zm-head"><span class="zm-ico lg">' + ic(ICON[id] || 'gear') + '</span><div><small>' + esc(m.group) + ' · ' + esc(where) + '</small><h2>' + esc(m.title) + '</h2><p>' + esc(m.description) + '</p></div></header>' +
        (id === 'M20' ? '<div id="zm-wb"></div>' :
          '<section class="zm-sec"><h3>How it works</h3>' + steps(m, -1) + '</section>' +
          '<section class="zm-sec"><h3>Try it</h3><form class="zm-form">' + m.fields.map(field).join('') + '<button class="zm-btn wide" type="submit">Run this example</button></form></section>' +
          '<section class="zm-sec"><h3>Activity</h3><div class="zm-recs">' + (recs.length ? recs.map(r => record(r, m)).join('') : '<p class="zm-empty">Run the example, then move it through each step.</p>') + '</div></section>') +
        '<details class="zm-more"><summary>Scope and release notes</summary><p>' + esc(m.disclosure || '') + '</p><p>' + esc(sc?.description || '') + '</p></details></div>';
      if (id === 'M20') { wellbeing(host.querySelector('#zm-wb')); return; }
      host.querySelector('.zm-form').onsubmit = async e => {
        e.preventDefault(); const b = e.target.querySelector('button'); b.disabled = true;
        try { await api({ action: 'create', module: id, fields: Object.fromEntries(new FormData(e.target)) }); toastFn.f('Saved. Choose the next step to continue.'); await refresh(); draw(); } catch (err) { toastFn.f(err.message, true); b.disabled = false; }
      };
      host.querySelector('.zm-recs').onclick = async e => {
        const b = e.target.closest('[data-act]'); if (!b) return; b.disabled = true;
        try { await api({ action: b.dataset.act, module: id, id: b.dataset.id, expectedStage: Number(b.dataset.stage) }); toastFn.f('Recorded.'); await refresh(); draw(); } catch (err) { toastFn.f(err.message, true); b.disabled = false; }
      };
    };
    draw();
  }

  /* wellbeing: the one module with its own sub-spaces */
  function wellbeing(el) {
    el.innerHTML = '<div class="zm-tabs">' + [['choices', 'Your choices'], ['journal', 'Private journal'], ['checkin', 'Weekly check-in'], ['support', 'Confidential support'], ['monitored', 'Reflection review']].map(([k, l]) => '<button type="button" data-wb="' + k + '" aria-pressed="' + (wbTab === k) + '">' + l + '</button>').join('') + '</div><div class="zm-sub"></div>';
    el.querySelectorAll('[data-wb]').forEach(b => b.onclick = () => { wbTab = b.dataset.wb; wellbeing(el); });
    const c = el.querySelector('.zm-sub');
    if (wbTab === 'choices') { c.innerHTML = '<section class="zm-sec"><h3>Different spaces for different needs</h3><p><strong>Private journal</strong> is encrypted in this browser and never sent to staff.</p><p><strong>Weekly check-in</strong> is optional. Answer, postpone or decline.</p><p><strong>Confidential support</strong> reaches your house parent only.</p><p class="zm-fine">Every other residence service stays available whether or not you check in.</p></section>'; return; }
    if (wbTab === 'journal') { journal(c); return; }
    if (wbTab === 'checkin') {
      c.innerHTML = '<form class="zm-form"><h3>How has your week been?</h3>' + ['Academic pressure', 'Financial essentials', 'Personal wellbeing', 'Relationships', 'General coping'].map((l, i) => '<label>' + l + '<select name="a' + i + '"><option>Prefer not to say</option><option>Managing well</option><option>Some pressure</option><option>Would like support</option></select></label>').join('') + '<div class="zm-actions"><button class="zm-btn" name="d" value="answered">Save check-in</button><button class="zm-btn ln" name="d" value="later">Remind me later</button><button class="zm-btn ln" name="d" value="declined">Prefer not to answer</button></div><p class="zm-fine">' + (data.choices?.[0] ? 'Last choice: ' + esc(data.choices[0].decision) : 'No check-in is required.') + '</p></form>';
      c.querySelector('form').onsubmit = async e => { e.preventDefault(); try { await api({ module: 'M20', action: 'checkin', decision: e.submitter.value }); await refresh(); toastFn.f('Your choice was saved.'); wellbeing(el); } catch (err) { toastFn.f(err.message, true); } }; return;
    }
    if (wbTab === 'support') {
      c.innerHTML = '<form class="zm-form"><h3>Ask for confidential help</h3><label>Subject<input name="subject" required minlength="4" maxlength="120" value="Feeling overwhelmed with deadlines"></label><label>How can the team help?<textarea name="message" required minlength="8" maxlength="1000">I would like to talk to someone about managing my workload.</textarea></label><label class="zm-check"><input type="checkbox" required checked> I choose to share this with the care team</label><button class="zm-btn wide">Send request</button></form>';
      c.querySelector('form').onsubmit = async e => { e.preventDefault(); try { const r = await fetch('/api/support', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-demo-role': 'student' }, body: JSON.stringify(Object.fromEntries(new FormData(e.target))) }); const j = await r.json(); if (!r.ok) throw Error(j.error); toastFn.f('Request received by the care team.'); } catch (err) { toastFn.f(err.message, true); } }; return;
    }
    c.innerHTML = '<section class="zm-sec"><h3>Reflection review</h3><p>An approved service needs explicit consent, trained duty reviewers and backup routes. This walkthrough shows how a review would run.</p><button class="zm-btn" type="button" id="zm-rev">Next review step</button><ol class="zm-time" id="zm-revs"></ol></section>';
    let n = 0; const S = ['The student sees who may read the reflection and chooses to share.', 'A provisional item enters a restricted reviewer queue. No diagnosis is made.', 'A human reviewer acknowledges it and checks the context.', 'The reviewer records a support follow-up.'];
    c.querySelector('#zm-rev').onclick = e => { if (n >= S.length) return; c.querySelector('#zm-revs').insertAdjacentHTML('beforeend', '<li>' + S[n++] + '</li>'); if (n === S.length) { e.target.textContent = 'Walkthrough complete'; e.target.disabled = true; } };
  }
  const b64 = b => btoa(String.fromCharCode(...new Uint8Array(b))), bytes = s => Uint8Array.from(atob(s), x => x.charCodeAt(0));
  async function jkey(pass, salt) { const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(pass), 'PBKDF2', false, ['deriveKey']); return crypto.subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: 600000 }, k, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']); }
  function journal(c) {
    const K = 'zres-private:' + (window.residenceContext?.selected.id || 'r'); let notes; try { notes = JSON.parse(sessionStorage.getItem(K) || '[]'); } catch { notes = []; }
    c.innerHTML = '<section class="zm-sec"><h3>Your private journal</h3><p>Notes are encrypted with your own passphrase and kept only in this browser tab. Nothing is sent to a server.</p><form class="zm-form"><label>Passphrase (15+ characters)<input name="p" type="password" minlength="15" required autocomplete="off"></label><label>Private note<textarea name="n" maxlength="5000" required></textarea></label><button class="zm-btn wide">Encrypt and save</button></form><div class="zm-recs">' + notes.map((n, i) => '<article class="zm-rec"><header><b>Note · ' + new Date(n.at).toLocaleString() + '</b></header><div class="zm-actions"><button class="zm-btn ln" data-open="' + i + '">Unlock</button><button class="zm-btn ln" data-del="' + i + '">Delete</button></div><p class="zm-plain" id="zp' + i + '" hidden></p></article>').join('') + '</div></section>';
    const f = c.querySelector('form');
    f.onsubmit = async e => { e.preventDefault(); try { const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12)), key = await jkey(f.elements.p.value, salt), ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(f.elements.n.value)); notes.unshift({ at: new Date().toISOString(), salt: b64(salt), iv: b64(iv), ct: b64(ct) }); sessionStorage.setItem(K, JSON.stringify(notes)); journal(c); toastFn.f('Encrypted and saved.'); } catch { toastFn.f('Could not save this note.', true); } };
    c.querySelector('.zm-recs').onclick = async e => { const b = e.target.closest('button'); if (!b) return; try { if (b.dataset.del !== undefined) { notes.splice(+b.dataset.del, 1); sessionStorage.setItem(K, JSON.stringify(notes)); journal(c); return; } const i = +b.dataset.open, n = notes[i], key = await jkey(f.elements.p.value, bytes(n.salt)), pl = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: bytes(n.iv) }, key, bytes(n.ct)); const p = c.querySelector('#zp' + i); p.textContent = new TextDecoder().decode(pl); p.hidden = false; } catch { toastFn.f('Check your passphrase.', true); } };
  }

  /* published house rules, filtered for the viewer */
  async function rules(host, role) {
    const r = await fetch('/api/tenant', { headers: { 'x-demo-role': role } }); const j = await r.json();
    host.innerHTML = (j.rules.length ? j.rules.map(x => '<article class="zm-rec"><header><b>' + esc(x.title) + '</b><span class="zm-pill">' + esc(x.audience) + '</span></header><p>' + esc(x.body) + '</p></article>').join('') : '<p class="zm-empty">No rules have been published yet.</p>');
  }
  window.ZModules = { rules, PLACE, ICON, WHERE, ROLE_NAME, ensure, refresh, list, placesOf, grid, mount, icon: ic, setToast: f => { toastFn.f = f; }, get data() { return data; }, get scope() { return scope; } };
})();
