# Website content audit — 15 November 2026

Reviewed the October 2026 pre-brand blueprint (26 pages), scope v2.1 (20 pages), authoritative scope v2.2 (24 pages, existing extraction), two KISS draft proposals (13 and 17 pages), independent proposal-review brief, supplied development instructions, recoverable relevant local user messages, current source and tests.

History search found 16 candidate local records. Many were duplicated context, unrelated education work or automatic approval-review records; they are not 16 independent product conversations. The recoverable directly relevant history includes the 28 October Residence OS continuation and this development chat. Earlier ChatGPT discussions are not guaranteed complete. No private chat transcript or prospect proposal was published.

| Source area | Public destination |
|---|---|
| Original buyer, operating thesis, value and business model | /owners, /pilot, /about |
| Full M01–M32 catalogue | /product, /platform-guide.json |
| All 255 tracked requirements | /scope-guide |
| Student, staff, public, owner and security roles | /solutions |
| Verification, branding and owner provisioning | /, /owners, /product, existing demo |
| Visitor lifecycle, replay, checkout, expiry and presence | /, /product#M06, /product#M07, /security |
| Wellbeing, journals, optional check-ins and safeguards | /wellbeing, /product#M20 |
| SOS, human acknowledgement, duty and wearable roadmap | /wellbeing, /product#M25 |
| Doors, biometrics, GPS and approved integrations | /product#M24, /product#M26, /product#M29 |
| Evidence-based owner metrics and public aggregates | /owners, /product#M12, /product#M27, /product#M32 |
| Commercial boundaries, onboarding and data exit | /pilot, /security |
| Independent primary research | /sources |

No customer endorsement, adoption metric, guaranteed saving, accreditation, production certification or fixed price was invented. Sample calculator inputs are disclosed as assumptions. No legal-compliance conclusion is made.

## Module traceability
- M01 Multi-tenant organisation & subscription control → /product#M01 → /explore#M01
- M02 Property, buildings, rooms & beds → /product#M02 → /explore#M02
- M03 Identity, onboarding and directory → /product#M03 → /explore#M03
- M04 Resident home and self-service → /product#M04 → /explore#M04
- M05 Official communications → /product#M05 → /explore#M05
- M06 Visitor pre-approval → /product#M06 → /explore#M06
- M07 Reception visitor & gate registry → /product#M07 → /explore#M07
- M08 Routine incident management → /product#M08 → /explore#M08
- M09 House parent / resident support → /product#M09 → /explore#M09
- M10 Maintenance and work orders → /product#M10 → /explore#M10
- M11 Shift handover and duty roster → /product#M11 → /explore#M11
- M12 Operations dashboard → /product#M12 → /explore#M12
- M13 Public property discovery → /product#M13 → /explore#M13
- M14 Applications, eligibility and waiting lists → /product#M14 → /explore#M14
- M15 Room selection and placement → /product#M15 → /explore#M15
- M16 Leases, inspections & move in/out → /product#M16 → /explore#M16
- M17 Utilities and disruptions → /product#M17 → /explore#M17
- M18 Facilities, laundry, study rooms & parcels → /product#M18 → /explore#M18
- M19 Roommate, transfer & dispute resolution → /product#M19 → /explore#M19
- M20 Student wellbeing, private reflections & confidential referrals → /product#M20 → /explore#M20
- M21 Residence communities, polls & events → /product#M21 → /explore#M21
- M22 Finance, invoices and reconciliation → /product#M22 → /explore#M22
- M23 Compliance and inspection evidence → /product#M23 → /explore#M23
- M24 Transport and shuttle → /product#M24 → /explore#M24
- M25 Emergency workflows and verified SOS → /product#M25 → /explore#M25
- M26 Door controller & biometric adapters → /product#M26 → /explore#M26
- M27 Portfolio intelligence → /product#M27 → /explore#M27
- M28 Platform support and configuration → /product#M28 → /explore#M28
- M29 Integration and developer gateway → /product#M29 → /explore#M29
- M30 Marketplace and partner ecosystem → /product#M30 → /explore#M30
- M31 Low-data PWA and accessible mobile experience → /product#M31 → /explore#M31
- M32 Feedback, service pulse & satisfaction → /product#M32 → /explore#M32
Revision: restored the seven original marketing layouts and five shared design/interaction files from ZRES-All-Features-and-Residence-Dashboard. Added paired residence/student benefits to the homepage, all 32 feature descriptions and the roles page. Original pilot and contact flows are restored; the pilot brief builder is not included in this revision.

Role information revision: expanded residents, reception/security, support, maintenance, management, finance/compliance, portfolio owners and platform administration. Includes 7 standalone student benefits and 8 residence benefits. Corrected obsolete unrestricted-management-access copy. Browser verified all 32 module references and mobile layout at 390 x 844.
