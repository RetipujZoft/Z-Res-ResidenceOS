# Z’RES — Website and interactive demo
 
Multi-residence update: choose `/residences` for residence branding, pending student requests, management approval and audience-specific rules. `/owner` lets the local Z’RES owner load residences using the private key printed in the server terminal. See RESIDENCE_SETUP.md. Branding persists locally; fictional accounts and rules remain session-only. This is not production authentication.
15 November 2026

Open START-WINDOWS.bat with Node.js 24.22.1 or newer installed. The launcher opens the website automatically on an available local port. No login is required for this fictional sales sandbox. Keep the terminal open.

The website includes Home, Owners, Full Platform, Student Wellbeing, Roles, Trust and Readiness, Pilot, About, Research Sources, Complete Scope and Contact. The previous website design is restored, including the laptop-and-phone preview and original typography. Six paired benefit stories explain value to residences and students. All 32 modules have detailed residence and student benefits, capabilities, operating controls and demo boundaries. All 255 scope records remain searchable. The owner page includes an illustrative capacity calculator; the original pilot page explains the evaluation process. See WEBSITE_CONTENT_AUDIT.md for source coverage and recovered-history limitations.
Live walkthrough: /demo. Explore all 32 module demonstrations: /explore.
Resident phone: /phone. Staff desk: /app.

The live walkthrough restores the original SOS, visitor photo/pass, ID check, entry/checkout, repairs, incidents, notices, rooms and staff presentations. Its resident and staff panels share the current browser session and receive update events.
The explorer adds grouped sample workflows for every M01–M32 module and retains all 255 requirement records. A demonstration entry is NOT evidence that the whole production requirement is complete.

Each browser session has its own in-memory sandbox. Reset affects that session only. Records are lost when the server stops or the session expires. Export demo records to keep a copy; sensitive-category records are excluded from the general export.
Private journal notes are separately encrypted in browser session storage and never sent to this demo server. Their export is also encrypted. A sandbox reset does not delete journal notes.

No real emergency responder, door controller, bank, GPS feed, identity provider, document-signature provider or messaging provider is connected. Use fictional data only. The server binds loopback and is not a public production deployment.

The earlier authenticated SQLite development implementation is retained under engineering/secured-workspace in the delivered package. Its separate setup and production restrictions still apply; the website sales demo does not bypass or replace its authentication.

Run npm test for the demo regression suite. See DEMO_COVERAGE.md, TEST_RESULTS.md and KNOWN_LIMITATIONS.md.


Role information update: open Solutions (/solutions) for eight detailed audience sections, links covering all 32 modules, and separate Benefits for students and Benefits for the residence sections. The original blue-and-white design is retained.
