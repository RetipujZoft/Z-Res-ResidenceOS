'use strict';
const catalog=require('./public/catalog.json');
const crypto=require('node:crypto');
const fail=(message,code=400)=>{throw Object.assign(new Error(message),{code});};
const clean=value=>String(value??'').trim().slice(0,1200);
function explorer(ctx,method,payload){
 ctx.explorer||={records:[],choices:[],events:[]};
 if(method==='GET')return {catalog,records:ctx.explorer.records,choices:ctx.explorer.choices,events:ctx.explorer.events};
 const b=payload;
 if(!b||typeof b!=='object'||Array.isArray(b))fail('Supply a valid action.');
 const module=catalog.find(x=>x.id===b.module);
 if(!module)fail('Unknown scope module.');
 if(b.action==='checkin'){
  if(!['answered','later','declined'].includes(b.decision))fail('Choose an optional check-in response.');
  if(b.decision!=='answered'&&b.answers)fail('Skipping does not collect answers.');
  const choice={id:crypto.randomUUID(),decision:b.decision,at:new Date().toISOString(),remindAfter:b.decision==='later'?new Date(Date.now()+86400000).toISOString():null};
  ctx.explorer.choices.unshift(choice);return choice;
 }
 if(b.action==='create'){
  const data={};
  for(const f of module.fields)data[f.key]=clean(b.fields?.[f.key]);
  if(!data.title)fail('Add a title for this fictional record.');
  if(module.id==='M22'&&(!Number.isFinite(Number(data.amount))||Number(data.amount)<=0))fail('Enter a positive fictional amount.');
  if(module.id==='M32'&&(!Number.isInteger(Number(data.rating))||Number(data.rating)<1||Number(data.rating)>5))fail('Choose a rating from 1 to 5.');
  if(module.id==='M15'&&!data.bed)fail('Enter a bed label.');
  if(module.id==='M18'&&(!data.resource||!data.date||!data.slot))fail('Choose a resource, date and slot.');
  if(ctx.explorer.records.length>=300)fail('This demo has reached its record limit. Reset to continue.',429);
  const r={id:crypto.randomUUID(),module:module.id,data,stage:0,status:module.stages[0],createdAt:new Date().toISOString(),history:[]};
  r.history.push({status:r.status,at:r.createdAt,actor:module.role});
  ctx.explorer.records.unshift(r);return r;
 }
 const r=ctx.explorer.records.find(x=>x.id===b.id&&x.module===module.id);
 if(!r)fail('Record not found in this demo session.',404);
 if(b.action==='cancel'){
  if(r.cancelled)fail('Already cancelled.',409);
  r.cancelled=true;r.status='Cancelled';r.history.push({status:r.status,at:new Date().toISOString(),actor:module.role});return r;
 }
 if(b.action!=='advance')fail('Unknown action.');
 if(r.cancelled||r.stage>=module.stages.length-1)fail('This workflow has already ended.',409);
 if(b.expectedStage!==r.stage)fail('This record changed. Refresh before continuing.',409);
 const active=x=>!x.cancelled&&x.id!==r.id&&x.module===r.module&&x.stage>0&&x.stage<module.stages.length-1;
 if(module.id==='M18'&&r.stage===0&&ctx.explorer.records.some(x=>active(x)&&x.data.resource===r.data.resource&&x.data.date===r.data.date&&x.data.slot===r.data.slot))fail('This resource and slot are already reserved.',409);
 if(module.id==='M15'&&r.stage===0&&ctx.explorer.records.some(x=>!x.cancelled&&x.id!==r.id&&x.module===r.module&&x.stage>0&&x.data.bed===r.data.bed))fail('This bed is already held or allocated.',409);
 r.stage++;r.status=module.stages[r.stage];r.history.push({status:r.status,at:new Date().toISOString(),actor:module.role});
 if(r.linkedSupport){const support=ctx.db.supportRequests.find(x=>x.id===r.linkedSupport);if(support)support.status=r.status;}
 return r;
}
module.exports={explorer};

