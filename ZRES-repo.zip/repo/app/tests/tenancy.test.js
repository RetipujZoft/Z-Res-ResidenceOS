'use strict';
process.env.ZRES_OWNER_TOKEN='local-test-owner-key-not-a-real-secret';
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'zres-tenancy-test-'));
process.env.ZRES_RESIDENCES_FILE=path.join(temp,'residences.json');
const {test,before,after}=require('node:test'),assert=require('node:assert/strict');
const {server}=require('../server');
let base,call;
async function client(){const r=await fetch(base+'/api/health');const cookie=r.headers.get('set-cookie').split(';')[0];return async(url,body,role='student',residence)=>{const r=await fetch(base+url,{headers:{Cookie:cookie,Origin:base,'Content-Type':'application/json','x-demo-role':role,...(residence?{'x-residence-id':residence}:{})},...(body?{method:'POST',body:JSON.stringify(body)}:{})});return {status:r.status,data:await r.json()};};}
before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base='http://127.0.0.1:'+server.address().port;call=await client();});
after(()=>new Promise(r=>{server.closeAllConnections();server.close(()=>{fs.rmSync(temp,{recursive:true,force:true});r();});}));
test('student begins pending; server blocks full access until management explicitly verifies',async()=>{
 const join=await call('/api/tenant/join',{name:'Demo Student',email:'student@example.test',studentNumber:'TEST123'});assert.equal(join.status,200);const a=join.data.membership;assert.equal(a.status,'pending');
 assert.equal((await call('/api/state?role=student')).status,403);assert.equal((await call('/api/explorer')).status,403);assert.equal((await call('/api/maintenance',{title:'Sample repair',description:'Sample test request'})).status,403);
 assert.equal((await call('/api/tenant/verify',{id:a.id,version:a.version,status:'approved',verified:true})).status,403);
 assert.equal((await call('/api/tenant/verify',{id:a.id,version:a.version,status:'approved'},'manager')).status,400);
 assert.equal((await call('/api/tenant/verify',{id:a.id,version:a.version,status:'approved',verified:true},'manager')).status,200);
 assert.equal((await call('/api/state?role=student')).data.resident.name,'Demo Student');assert.equal((await call('/api/explorer')).status,200);
 assert.equal((await call('/api/tenant/verify',{id:a.id,version:a.version,status:'approved',verified:true},'manager')).status,409);
});
test('residences isolate approval, rules, records and stale-screen writes',async()=>{
 const a=(await call('/api/tenant')).data.membership;
 await call('/api/tenant/rules',{title:'Quiet hours',body:'Please keep noise down after 22:00.',audience:'students'},'manager');
 await call('/api/tenant/rules',{title:'Management review',body:'Review requests every morning.',audience:'management'},'manager');
 assert.equal((await call('/api/tenant')).data.rules.length,5);
 await call('/api/tenant/select',{id:'urban-circle'});
 assert.equal((await call('/api/tenant')).data.membership,null);assert.equal((await call('/api/tenant')).data.rules.length,0);
 assert.equal((await call('/api/tenant/approvals',null,'manager')).data.accounts.length,0);
 assert.equal((await call('/api/tenant/verify',{id:a.id,version:2,status:'suspended',reason:'Demo suspension'},'manager')).status,404);
 assert.equal((await call('/api/maintenance',{title:'Wrong screen',description:'Must not write in another residence'},'student','retipuj-residence')).status,409);
 const b=(await call('/api/tenant/join',{name:'Demo Student',email:'student@example.test',studentNumber:'TEST123'})).data.membership;assert.equal(b.status,'pending');assert.equal((await call('/api/state?role=student')).status,403);
 await call('/api/reset',{},'manager');assert.equal((await call('/api/state?role=student')).status,403);
 await call('/api/tenant/select',{id:'retipuj-residence'});assert.equal((await call('/api/state?role=student')).status,200);assert.equal((await call('/api/tenant')).data.rules.length,5);
 const other=await client();assert.equal((await other('/api/tenant/approvals',null,'manager')).data.accounts.length,0);
});
test('suspension removes access and decline needs a reason',async()=>{
 const a=(await call('/api/tenant')).data.membership;
 assert.equal((await call('/api/tenant/verify',{id:a.id,version:a.version,status:'suspended'},'manager')).status,400);
 assert.equal((await call('/api/tenant/verify',{id:a.id,version:a.version,status:'suspended',reason:'Demo review needed'},'manager')).status,200);
 assert.equal((await call('/api/state?role=student')).status,403);
});
test('owner-only catalogue cannot be changed with management demo headers',async()=>{
 const body={name:'Not allowed',initials:'NA',color:'#174B8A'};
 assert.equal((await call('/api/owner/residences',body,'manager')).status,403);
 assert.equal((await call('/api/owner/login',{key:'incorrect'})).status,403);
 assert.equal((await call('/api/owner/login',{key:process.env.ZRES_OWNER_TOKEN})).status,200);
 assert.equal((await call('/api/owner/residences',{...body,color:'#ffffff'})).status,400);
 assert.equal((await call('/api/owner/residences',{...body,logo:'data:image/svg+xml;base64,ABC'})).status,400);
 const created=await call('/api/owner/residences',{name:'Demo Oak Residence',initials:'OR',color:'#174B8A',illustrative:true});assert.equal(created.status,200);
 assert.ok(JSON.parse(fs.readFileSync(process.env.ZRES_RESIDENCES_FILE,'utf8')).some(r=>r.id===created.data.residence.id));
 assert.equal((await call('/api/tenant/select',{id:created.data.residence.id})).status,200);
 assert.equal((await call('/api/tenant')).data.selected.name,'Demo Oak Residence');
 await call('/api/owner/logout',{});assert.equal((await call('/api/owner/residences',body)).status,403);
});
