'use strict';
const {test,before,after}=require('node:test'),assert=require('node:assert/strict');
const {server}=require('../server');
let base,a,b;
async function client(){
 const response=await fetch(base+'/api/health');
 const cookie=response.headers.get('set-cookie').split(';')[0];
 return async(path,body,role='manager')=>{
  const r=await fetch(base+path,{headers:{Cookie:cookie,Origin:base,'Content-Type':'application/json','x-demo-role':role},...(body?{method:'POST',body:JSON.stringify(body)}:{})});
  return {status:r.status,data:await r.json()};
 };
}
before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base='http://127.0.0.1:'+server.address().port;a=await client();b=await client();});
after(()=>new Promise(r=>server.close(r)));
test('website, walkthrough, explorer and original apps load',async()=>{
 for(const p of ['/','/owners','/wellbeing','/sources','/scope-guide','/platform-guide.json','/buyer.css','/buyer.js','/dashboard','/dashboard.js','/dashboard.css','/product','/solutions','/security','/pilot','/about','/contact','/demo','/explore','/phone','/app','/catalog.json','/scope.json']){
  const r=await fetch(base+p);assert.equal(r.status,200,p);
 }
 const scope=await (await fetch(base+'/scope.json')).json();assert.equal(scope.length,255);
});
test('all 32 module demos accept records and valid stage transitions',async()=>{
 const state=await a('/api/explorer');assert.equal(state.data.catalog.length,32);
 for(const m of state.data.catalog){
  const fields=Object.fromEntries(m.fields.map(f=>[f.key,f.key==='amount'?'1250':f.key==='rating'?'4':f.key==='date'?'2026-12-10':f.key==='slot'?'14:00':m.id+' fictional '+f.key]));
  let r=await a('/api/explorer',{module:m.id,action:'create',fields});assert.equal(r.status,200,m.id);
  for(let stage=0;stage<m.stages.length-1;stage++){r=await a('/api/explorer',{module:m.id,action:'advance',id:r.data.id,expectedStage:stage});assert.equal(r.status,200,m.id+' stage '+stage);}
  assert.equal(r.data.status,m.stages.at(-1));
  assert.equal((await a('/api/explorer',{module:m.id,action:'advance',id:r.data.id,expectedStage:r.data.stage})).status,409);
 }
});
test('independent sessions and reset do not expose or erase another sandbox',async()=>{
 assert.equal((await b('/api/explorer')).data.records.length,0);
 await b('/api/reset',{},'manager');
 assert.equal((await a('/api/explorer')).data.records.length,32);
 const id=(await a('/api/explorer')).data.records[0].id;
 assert.equal((await b('/api/explorer',{module:'M32',action:'cancel',id})).status,404);
});
test('SOS is received, then explicitly acknowledged in the same demo desk',async()=>{
 const r=await a('/api/incidents',{category:'SOS / Immediate danger',location:'Fictional lobby',description:'Test only'},'student');assert.equal(r.status,200);
 let state=(await a('/api/state?role=reception')).data;
 assert.equal(state.incidents.find(x=>x.id===r.data.id).status,'Awaiting acknowledgement');
 assert.ok(!(await b('/api/state?role=reception')).data.incidents.some(x=>x.id===r.data.id));
 assert.equal((await a('/api/incidents/'+r.data.id+'/status',{status:'Acknowledged'},'reception')).status,200);
 state=(await a('/api/state?role=student')).data;
 assert.equal(state.incidents.find(x=>x.id===r.data.id).status,'Acknowledged');
});
test('visitor concurrent entry grants once; checkout permanently rejects re-entry',async()=>{
 const r=await a('/api/visitors',{name:'Fictional Visitor',idSuffix:'1234',photo:'data:image/png;base64,'+'A'.repeat(120),purpose:'Test visit',startAt:new Date(Date.now()-1000).toISOString(),endAt:new Date(Date.now()+3600000).toISOString()},'student');assert.equal(r.status,200);
 const v=(await a('/api/state?role=reception')).data.visitors.find(x=>x.name==='Fictional Visitor');
 assert.equal((await a('/api/visitors/'+v.id+'/approve',{},'reception')).status,200);
 const results=await Promise.all([a('/api/visitors/'+v.id+'/entry',{idSuffix:'1234'},'reception'),a('/api/visitors/'+v.id+'/entry',{idSuffix:'1234'},'reception')]);
 assert.deepEqual(results.map(x=>x.status).sort(),[200,409]);
 assert.equal((await a('/api/visitors/'+v.id+'/checkout',{idSuffix:'1234'},'reception')).status,200);
 assert.equal((await a('/api/visitors/'+v.id+'/entry',{idSuffix:'1234'},'reception')).status,409);
});
test('demo care details are redacted from general management',async()=>{
 await a('/api/support',{subject:'Fictional care',message:'Fictional confidential detail'},'student');
 assert.equal((await a('/api/state?role=manager')).data.supportRequests.length,0);
 assert.ok((await a('/api/state?role=houseparent')).data.supportRequests.length>0);
 await a('/api/incidents',{category:'Medical',description:'PRIVATE TEST DETAIL',location:'Room test'},'student');
 const manager=(await a('/api/state?role=manager')).data.incidents.find(x=>x.category==='Medical');
 assert.ok(!manager.description.includes('PRIVATE TEST DETAIL'));
});
test('facility and bed conflicts plus stale progression are rejected',async()=>{
 for(const module of ['M18','M15']){
  const fields={title:'Conflict test',resource:'Shared facility',date:'2026-12-11',slot:'10:00',bed:'B-CONFLICT'};
  const x=(await a('/api/explorer',{module,action:'create',fields})).data;
  const y=(await a('/api/explorer',{module,action:'create',fields})).data;
  assert.equal((await a('/api/explorer',{module,action:'advance',id:x.id,expectedStage:0})).status,200);
  assert.equal((await a('/api/explorer',{module,action:'advance',id:x.id,expectedStage:0})).status,409);
  assert.equal((await a('/api/explorer',{module,action:'advance',id:y.id,expectedStage:0})).status,409);
 }
});
test('optional check-in choices do not block essentials and decline collects no answers',async()=>{
 for(const decision of ['answered','later','declined']){
  assert.equal((await a('/api/explorer',{module:'M20',action:'checkin',decision})).status,200);
  assert.equal((await a('/api/maintenance',{title:'Essential repair',description:'Fictional repair after check-in'},'student')).status,200);
  assert.equal((await a('/api/state?role=student')).status,200);
 }
 assert.equal((await a('/api/explorer',{module:'M20',action:'checkin',decision:'declined',answers:'should not collect'})).status,400);
});
test('finance and rating validation; origin and path isolation',async()=>{
 assert.equal((await a('/api/explorer',{module:'M22',action:'create',fields:{title:'Invoice',amount:'-1'}})).status,400);
 assert.equal((await a('/api/explorer',{module:'M32',action:'create',fields:{title:'Feedback',rating:'9'}})).status,400);
 const r=await fetch(base+'/api/reset',{method:'POST',headers:{Origin:'http://other.invalid','Content-Type':'application/json'},body:'{}'});assert.equal(r.status,403);
 assert.notEqual((await fetch(base+'/server.js')).status,200);
});
test('closing a live event stream does not crash the demo server',async()=>{
 const abort=new AbortController();const r=await fetch(base+'/api/events',{signal:abort.signal});
 const reader=r.body.getReader();assert.ok((await reader.read()).value.length>0);abort.abort();
 await new Promise(resolve=>setTimeout(resolve,25));assert.equal((await a('/api/health')).status,200);
});
test('confidential request connects to a care workflow and its acknowledgement',async()=>{
 await a('/api/support',{subject:'Linked care request',message:'Fictional follow-up request'},'student');
 const care=(await a('/api/explorer')).data.records.find(r=>r.module==='M09'&&r.data.title==='Linked care request');
 assert.ok(care.linkedSupport);
 assert.equal((await a('/api/explorer',{module:'M09',action:'advance',id:care.id,expectedStage:0})).status,200);
 assert.equal((await a('/api/state?role=student')).data.supportRequests.find(x=>x.id===care.linkedSupport).status,'Acknowledged');
});

