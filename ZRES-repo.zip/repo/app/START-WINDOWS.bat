@echo off
title ZRES Website and Demo
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
 echo Install Node.js 24.22.1 or newer, then open this file again.
 pause
 exit /b 1
)
set "PORT=0"
set "ZRES_OPEN=1"
node server.js
if errorlevel 1 pause
