# Premium layer

Visual and interaction upgrade only. No page content or colours were changed.

- `public/premium.css` and `public/premium.js` are loaded last on every page.
- To switch it off, delete the two tags (`premium.css`, `premium.js`) from a page's `<head>`.
- Adds: glass header, scroll progress, reveal animations, card spotlight/hover depth, animated hero,
  count-up dashboard numbers, button micro-interactions, Ctrl/Cmd+K quick jump (pages + all 32 modules),
  a 7-step guided tour pill, back-to-top ring. Respects reduced-motion; skipped inside demo iframes.

## Demo brief changes
- Demo residence is Retipuj Residence (was Nova Heights); initials RR.
- Accounts are information-only in the demo (no sign-up, approval or rule editing). See /residences.
- Feature module demos run pre-filled examples; no typing needed.
- Dashboard removed from resident navigation; reachable only via the "Management dashboard" button on the live walkthrough and by direct link.
- Typeface: Roboto (loaded from Google Fonts; falls back to Helvetica/Arial offline).

## Red and white theme + management dashboard
- Palette converted to red (#c11128 family), white and warm charcoal; status greens/ambers kept for meaning.
- /dashboard rebuilt as a management console (hero, KPI tiles, occupancy donut, workload bars, attention list, notices, on-site today, activity feed, feature directory).
- FAQ accordion icon fixed.
