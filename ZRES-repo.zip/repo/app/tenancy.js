'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {seed}=require('./seed');
const file=process.env.ZRES_RESIDENCES_FILE||path.join(__dirname,'data','residences.json');
const defaults=[
 {id:'retipuj-residence',name:'Retipuj Residence',color:'#be1128',initials:'RR',logo:'',illustrative:true},
 {id:'urban-circle',name:'Urban Circle',color:'#753B26',initials:'UC',logo:'',illustrative:true},
 {id:'campus-house',name:'Campus House',color:'#20584B',initials:'CH',logo:'',illustrative:true}
];
let residences=fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):defaults;
let ownerToken=process.env.ZRES_OWNER_TOKEN||crypto.randomBytes(24).toString('hex');
function fail(message,code=400){throw Object.assign(new Error(message),{code});}
function text(v,max=200){return String(v||'').trim().slice(0,max);}
function residenceId0(id){return id;}
function defaultRules(id){const now=new Date().toISOString(),r=(title,body,audience)=>({id:crypto.randomUUID(),residenceId:id,title,body,audience,version:1,updatedAt:now});
 return [r('Quiet hours','Quiet hours run from 22:00 to 06:00 on weeknights and 23:00 to 07:00 on weekends. Please keep music, calls and gatherings low so everyone can rest and study.','students'),
 r('Visitors','Visitors must be invited in the app and show ID at reception. Visiting hours end at 22:00. Hosts are responsible for their guests at all times.','students'),
 r('Shared spaces','Leave kitchens, laundry and study rooms clean for the next person. Report anything broken from the Repairs tab.','students'),
 r('Handover standard','Every shift ends with a written handover covering open incidents, expected visitors and outstanding repairs.','staff'),
 r('Fire safety','Never block corridors or fire exits. Alarms are tested on the first Monday of each month.','everyone')];}
function context(root,id=root.activeResidence||residences[0].id){
 const residence=residences.find(x=>x.id===id);if(!residence)fail('Residence not found.',404);
 root.spaces??=new Map();root.activeResidence=id;
 if(!root.spaces.has(id)){const db=seed();db.meta.residence=residence.name;root.spaces.set(id,{root,residenceId:id,db,listeners:new Set(),accounts:[],membership:null,rules:id==='retipuj-residence'?defaultRules(id):[],ruleHistory:[]});}
 return root.spaces.get(id);
}
function profile(c){return residences.find(x=>x.id===c.residenceId);}
function studentGate(c){if(c.membership&&c.membership.status!=='approved')fail('Your account is '+c.membership.status+'. Residence management must verify you before full access.',403);}
function manager(role){if(role!=='manager')fail('Only this residence’s management can do that.',403);}
function persist(){fs.mkdirSync(path.dirname(file),{recursive:true});const tmp=file+'.tmp';fs.writeFileSync(tmp,JSON.stringify(residences,null,2));fs.renameSync(tmp,file);}
function owner(c){if(!c.root.owner)fail('Sign in with the Z’RES owner key shown in the local server window.',403);}
function handle(c,url,method,b,role){
 if(url==='/api/tenant'&&method==='GET')return {residences,selected:profile(c),membership:c.membership,rules:c.rules.filter(r=>role==='manager'||r.audience==='everyone'||r.audience===(role==='student'?'students':'staff')),mode:'Fictional sandbox',owner:!!c.root.owner};
 if(url==='/api/tenant/select'&&method==='POST'){
  const next=context(c.root,b.id);for(const s of c.root.spaces.values())for(const r of s.listeners){r.end();s.listeners.delete(r);}return {selected:profile(next)};
 }
 if(url==='/api/tenant/join'&&method==='POST'){
  if(c.membership)fail('An account already exists for this residence in your demo session.',409);
  const name=text(b.name,100),email=text(b.email,200).toLowerCase(),studentNumber=text(b.studentNumber,60);
  if(name.length<2||!/^\S+@\S+\.\S+$/.test(email)||studentNumber.length<3)fail('Enter your name, email and student number.');
  const account={id:crypto.randomUUID(),residenceId:c.residenceId,name,email,studentNumber,status:'pending',version:1,submittedAt:new Date().toISOString(),history:[{status:'pending',at:new Date().toISOString()}]};
  c.accounts.push(account);c.membership=account;return {membership:account};
 }
 if(url==='/api/tenant/approvals'&&method==='GET'){manager(role);return {accounts:c.accounts};}
 if(url==='/api/tenant/verify'&&method==='POST'){
  manager(role);const a=c.accounts.find(x=>x.id===b.id);if(!a)fail('Account not found in this residence.',404);
  if(a.version!==b.version)fail('This account changed. Refresh before reviewing it.',409);
  if(!['approved','rejected','suspended'].includes(b.status))fail('Choose a valid decision.');
  if(b.status==='suspended'&&a.status!=='approved'||b.status==='rejected'&&a.status!=='pending'||b.status==='approved'&&!['pending','suspended','rejected'].includes(a.status))fail('That status change is not available.',409);
  const reason=text(b.reason,500);if(b.status!=='approved'&&reason.length<4)fail('Explain this decision to the student.');
  if(b.status==='approved'&&b.verified!==true)fail('Confirm you checked the student against residence records.');
  a.status=b.status;a.version++;a.reason=reason;a.history.push({status:a.status,at:new Date().toISOString(),actor:'Residence management (demo)',reason});
  if(a===c.membership&&a.status==='approved'){c.db.resident.name=a.name;c.db.resident.id=a.id;}
  return {membership:a};
 }
 if(url==='/api/tenant/rules'&&method==='POST'){
  manager(role);if(!['students','staff','management','everyone'].includes(b.audience))fail('Choose who this rule applies to.');
  const title=text(b.title,120),body=text(b.body,3000);if(title.length<3||body.length<8)fail('Add a rule title and clear instructions.');
  let rule=b.id?c.rules.find(x=>x.id===b.id):null;if(b.id&&!rule)fail('Rule not found in this residence.',404);
  if(rule&&rule.version!==b.version)fail('This rule changed. Refresh before saving.',409);
  if(rule)c.ruleHistory.push({...rule});else{rule={id:crypto.randomUUID(),residenceId:c.residenceId,version:0};c.rules.push(rule);}
  Object.assign(rule,{title,body,audience:b.audience,version:rule.version+1,updatedAt:new Date().toISOString()});return {rule};
 }
 if(url==='/api/owner/login'&&method==='POST'){
  const candidate=Buffer.from(String(b.key||'')),expected=Buffer.from(ownerToken);
  if(candidate.length!==expected.length||!crypto.timingSafeEqual(candidate,expected))fail('Owner key is incorrect.',403);
  c.root.owner=true;return {ok:true};
 }
 if(url==='/api/owner/logout'&&method==='POST'){c.root.owner=false;return {ok:true};}
 if(url==='/api/owner/residences'&&method==='POST'){
  owner(c);const name=text(b.name,100),color=text(b.color,7),initials=text(b.initials,3).toUpperCase(),logo=String(b.logo||'');
  if(name.length<2||!/^#[0-9a-f]{6}$/i.test(color)||!initials)fail('Provide a residence name, initials and six-digit brand colour.');
  if(logo&&(!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(logo)||logo.length>400000))fail('Use a PNG, JPEG or WebP logo smaller than 290 KB.');
  // Keep white text legible on brand-coloured actions.
  const rgb=[1,3,5].map(i=>parseInt(color.slice(i,i+2),16)/255).map(v=>v<=0.04045?v/12.92:((v+0.055)/1.055)**2.4);
  if(1.05/(0.2126*rgb[0]+0.7152*rgb[1]+0.0722*rgb[2]+0.05)<4.5)fail('Choose a darker brand colour so white button text remains readable.');
  let r=b.id?residences.find(x=>x.id===b.id):null;if(b.id&&!r)fail('Residence not found.',404);
  if(residences.some(x=>x.id!==b.id&&x.name.toLowerCase()===name.toLowerCase()))fail('That residence name is already loaded.',409);
  const previous=JSON.parse(JSON.stringify(residences));
  if(!r){r={id:crypto.randomUUID()};residences.push(r);}
  Object.assign(r,{name,color,initials,logo,illustrative:b.illustrative===true});
  try{persist();}catch(e){residences=previous;throw e;}return {residence:r};
 }
 return undefined;
}
module.exports={context,profile,studentGate,handle,ownerKey:()=>ownerToken};
