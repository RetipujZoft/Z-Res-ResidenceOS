# Verification — 15 November 2026

Demo regression suite: 15 passed, 0 failed, 0 skipped.
Command: node --test tests/*.test.js

Covers routes and 255-row scope register; all 32 sample workflow stage sequences; sandbox isolation/reset; SOS receipt and explicit acknowledgement; visitor entry/checkout replay; confidential core-view filtering; facility and bed conflicts; stale transitions; optional check-in choices; finance/rating validation; hostile origins; source-file exposure; SSE disconnect regression; support-request linkage.

Additional coverage: pending-account service gates, management verification, stale approval decisions, residence isolation, audience-specific rules, stale-screen writes, suspension, owner-only catalogue controls, persisted owner-created branding and invalid logos/colours.

Browser checks: website and demo navigation; SOS submission and matching live staff receipt; fictional invoice creation and advancement; 390 x 844 wellbeing layout, postponement confirmation and resident/staff screen switching. Multi-residence update: Urban Circle selection, pending student request, management approval, rule publication and approved account at 390 x 844.

Owner website verification: all 11 pages, local links and anchors; all 32 detailed capability entries and 255 scope records. Browser-checked restored homepage, paired benefits at 390 x 844, capability search and expanded module details. The original seven marketing pages and five shared style/interaction files were restored; six paired benefit stories and all 32 module benefit explanations were added. Research sources and recovered-history limits are recorded in WEBSITE_CONTENT_AUDIT.md and /sources.

Limits: not an independent security/accessibility audit, physical-device test, crypto audit or proof of production readiness. PWA installation/offline lifecycle and external integrations have not been end-to-end certified. Earlier authenticated-workspace tests are documented separately.
