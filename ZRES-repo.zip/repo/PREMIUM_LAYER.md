
## Round 4
- Website rebuilt in the style of Urban Circle / OKX: utility bar, mega-menu header, persona hero with live laptop and phone previews, amenity tiles, screen cards, dark feature map, brand section, closing band (`site2.css`, `home.js`).
- All 32 modules now live inside the resident app (Services tab), the staff desk (Workspace tab) and the management dashboard (workspace drawer) through `modules.js`/`modules.css`.
- Every residence can set its name, colour and logo and publish house rules from the dashboard ("Make it yours"). Rules show in the resident app and staff desk.
- Embedded previews no longer open live-update streams (avoids stalled loads).
