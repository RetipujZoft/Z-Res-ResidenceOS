@echo off
cd /d "%~dp0app"
call START-WINDOWS.bat
